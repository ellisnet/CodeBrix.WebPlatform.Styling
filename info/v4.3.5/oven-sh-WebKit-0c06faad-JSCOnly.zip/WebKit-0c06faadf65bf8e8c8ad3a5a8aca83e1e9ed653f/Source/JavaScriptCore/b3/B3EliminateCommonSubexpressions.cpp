/*
 * Copyright (C) 2016-2026 Apple Inc. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY APPLE INC. ``AS IS'' AND ANY
 * EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL APPLE INC. OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY
 * OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "config.h"
#include "B3EliminateCommonSubexpressions.h"

#if ENABLE(B3_JIT)

#include "B3BasicBlockInlines.h"
#include "B3BlockWorklist.h"
#include "B3BreakCriticalEdges.h"
#include "B3Dominators.h"
#include "B3HeapRange.h"
#include "B3InsertionSetInlines.h"
#include "B3MemoryValue.h"
#include "B3MemoryValueInlines.h"
#include "B3NaturalLoops.h"
#include "B3PhaseScope.h"
#include "B3ProcedureInlines.h"
#include "B3PureCSE.h"
#include "B3SSACalculator.h"
#include "B3UpsilonValue.h"
#include "B3ValueInlines.h"
#include "B3ValueKeyInlines.h"
#include <wtf/CommaPrinter.h>
#include <wtf/HashMap.h>
#include <wtf/IndexSet.h>
#include <wtf/ListDump.h>
#include <wtf/RangeSet.h>
#include <wtf/Scope.h>

namespace JSC { namespace B3 {

namespace {

namespace B3EliminateCommonSubexpressionsInternal {
static constexpr bool verbose = false;
}

// FIXME: We could treat Patchpoints with a non-empty set of reads as a "memory value" and somehow
// eliminate redundant ones. We would need some way of determining if two patchpoints are replacable.
// It doesn't seem right to use the reads set for this. We could use the generator, but that feels
// lame because the FTL will pretty much use a unique generator for each patchpoint even when two
// patchpoints have the same semantics as far as CSE would be concerned. We could invent something
// like a "value ID" for patchpoints. By default, each one gets a unique value ID, but FTL could force
// some patchpoints to share the same one as a signal that they will return the same value if executed
// in the same heap with the same inputs.

using MemoryMatches = Vector<MemoryValue*, 1>;

class MemoryValueMap {
public:
    MemoryValueMap() { }

    void add(MemoryValue* memory)
    {
        Matches& matches = m_map.add(memory->lastChild(), Matches()).iterator->value;
        if (matches.contains(memory))
            return;
        matches.append(memory);
    }

    template<typename Functor>
    void removeIf(NOESCAPE const Functor& functor)
    {
        m_map.removeIf(
            [&] (UncheckedKeyHashMap<Value*, Matches>::KeyValuePairType& entry) -> bool {
                entry.value.removeAllMatching(
                    [&] (Value* value) -> bool {
                        if (MemoryValue* memory = value->as<MemoryValue>())
                            return functor(memory);
                        return true;
                    });
                return entry.value.isEmpty();
            });
    }

    Matches* find(Value* ptr)
    {
        auto iter = m_map.find(ptr);
        if (iter == m_map.end())
            return nullptr;
        return &iter->value;
    }

    template<typename Functor>
    MemoryValue* find(Value* ptr, NOESCAPE const Functor& functor)
    {
        dataLogLnIf(B3EliminateCommonSubexpressionsInternal::verbose, "        Looking for ", pointerDump(ptr), " in ", *this);
        if (Matches* matches = find(ptr)) {
            dataLogLnIf(B3EliminateCommonSubexpressionsInternal::verbose, "        Matches: ", pointerListDump(*matches));
            for (Value* candidateValue : *matches) {
                dataLogLnIf(B3EliminateCommonSubexpressionsInternal::verbose, "        Having candidate: ", pointerDump(candidateValue));
                if (MemoryValue* candidateMemory = candidateValue->as<MemoryValue>()) {
                    if (functor(candidateMemory))
                        return candidateMemory;
                }
            }
        }
        return nullptr;
    }

    void dump(PrintStream& out) const
    {
        out.print("{"_s);
        CommaPrinter comma;
        for (auto& entry : m_map)
            out.print(comma, pointerDump(entry.key), "=>"_s, pointerListDump(entry.value));
        out.print("}"_s);
    }
    
private:
    // This uses Matches for two reasons:
    // - It cannot be a MemoryValue* because the key is imprecise. Many MemoryValues could have the
    //   same key while being unaliased.
    // - It can't be a MemoryMatches array because the MemoryValue*'s could be turned into Identity's.
    UncheckedKeyHashMap<Value*, Matches> m_map;
};

struct ImpureBlockData {
    void dump(PrintStream& out) const
    {
        out.print(
            "{reads = ", reads, ", writes = ", writes,
            ", memoryStoresAtHead = ", memoryStoresAtHead, ", memoryValuesAtTail = ", memoryValuesAtTail,
            "}");
    }

    RangeSet<HeapRange> reads; // This only gets used for forward store elimination.
    RangeSet<HeapRange> writes; // This gets used for both load and store elimination.
    bool fence { false };
    bool writesPinned { false };

    MemoryValueMap memoryStoresAtHead;
    MemoryValueMap memoryValuesAtTail;

    // This Maps x->y in "y = WasmAddress(@x)"
    UncheckedKeyHashMap<Value*, Value*> m_candidateWasmAddressesAtTail;
};

class CSE {
public:
    CSE(Procedure& proc)
        : m_proc(proc)
        , m_insertionSet(proc)
    {
    }

    bool run()
    {
        dataLogIf(B3EliminateCommonSubexpressionsInternal::verbose, "B3 before CSE:\n", m_proc);

        // Direct Upsilon insertion needs no critical edges.
        breakCriticalEdges(m_proc);

        m_proc.resetValueOwners();
        m_dominators = &m_proc.dominators();
        m_impureBlockData = IndexMap<BasicBlock*, ImpureBlockData>(m_proc.size());
        m_ssa = makeUnique<SSACalculator>(m_proc);

        // Summarize the impure effects of each block, and the impure values available at the end of
        // each block. This doesn't edit code yet.
        for (BasicBlock* block : m_proc) {
            ImpureBlockData& data = m_impureBlockData[block];
            for (Value* value : *block) {
                Effects effects = value->effects();
                MemoryValue* memory = value->as<MemoryValue>();

                if (memory) {
                    if (memory->isStore()
                        && !data.reads.overlaps(memory->range())
                        && !data.writes.overlaps(memory->range())
                        && (!data.fence || !memory->hasFence()))
                        data.memoryStoresAtHead.add(memory);
                }
                data.reads.add(effects.reads);

                if (HeapRange writes = effects.writes)
                    clobber(data, writes);
                data.fence |= effects.fence;

                if (memory)
                    data.memoryValuesAtTail.add(memory);
                if (WasmAddressValue* wasmAddress = value->as<WasmAddressValue>())
                    data.m_candidateWasmAddressesAtTail.add(wasmAddress->child(0), wasmAddress);

                if (effects.writesPinned) {
                    data.writesPinned = true;
                    data.m_candidateWasmAddressesAtTail.clear();
                }
            }

            dataLogLnIf(B3EliminateCommonSubexpressionsInternal::verbose, "Block ", *block, ": ", data);
        }

        // Perform CSE. This edits code.
        performCSE(nullptr);

        // Re-sweep loop blocks once to catch some additional cases. In reverse-post-order the loop body hasn't been
        // processed when we visit the header, so back-edge queries from the header miss matches that show up after the body is processed.
        NaturalLoops& loops = m_proc.naturalLoops();
        if (loops.numLoops()) {
            IndexSet<BasicBlock*> loopBlocks;
            for (unsigned i = 0; i < loops.numLoops(); ++i) {
                const auto& loop = loops.loop(i);
                loopBlocks.add(loop.header());
                for (unsigned j = 0; j < loop.size(); ++j)
                    loopBlocks.add(loop.at(j));
            }
            performCSE(&loopBlocks);
        }

        finalize();

        dataLogIf(B3EliminateCommonSubexpressionsInternal::verbose, "B3 after CSE:\n", m_proc);

        return m_changed;
    }

private:
    void performCSE(const IndexSet<BasicBlock*>* filter)
    {
        for (auto* block : m_proc.blocksInPostOrder() | std::views::reverse) {
            m_block = block;
            if (filter && !filter->contains(m_block))
                continue;
            dataLogLnIf(B3EliminateCommonSubexpressionsInternal::verbose, "Looking at ", *m_block, ":");

            m_data = ImpureBlockData();
            for (m_index = 0; m_index < m_block->size(); ++m_index) {
                m_value = m_block->at(m_index);
                process();
            }
            m_insertionSet.execute(m_block);
            m_impureBlockData[m_block] = m_data;
        }
    }

    void finalize()
    {
        if (m_pendingResolutions.isEmpty()) {
            ASSERT(m_sets.isEmpty());
            return;
        }

        m_ssa->computePhis(
            [&] (SSACalculator::Variable* var, BasicBlock*) -> Value* {
                const auto& resolution = m_pendingResolutions[var->index()];
                return m_proc.add<Value>(Phi, resolution.placeholder->type(), resolution.placeholder->origin());
            });

        for (BasicBlock* block : m_proc.blocksInPreOrder()) {
            for (SSACalculator::Def* phiDef : m_ssa->phisForBlock(block))
                m_insertionSet.insertValue(0, phiDef->value());

            if (m_blocksWithSets.contains(block)) {
                for (unsigned valueIndex = 0; valueIndex < block->size(); ++valueIndex) {
                    Value* value = block->at(valueIndex);
                    if (!m_matched.contains(value))
                        continue;
                    auto iter = m_sets.find(value);
                    if (iter == m_sets.end())
                        continue;
                    for (Value* extra : iter->value)
                        m_insertionSet.insertValue(valueIndex + 1, extra);
                }
            }

            if (block->size()) {
                unsigned upsilonIndex = block->size() - 1;
                Origin upsilonOrigin = block->last()->origin();
                for (BasicBlock* successor : block->successorBlocks()) {
                    for (SSACalculator::Def* phiDef : m_ssa->phisForBlock(successor)) {
                        SSACalculator::Variable* var = phiDef->variable();
                        SSACalculator::Def* reaching = m_ssa->reachingDefAtTail(block, var);
                        Value* upsilonChild;
                        if (reaching)
                            upsilonChild = reaching->value()->foldIdentity();
                        else {
                            // Predecessor reaches the Phi on a path with no def.
                            upsilonChild = m_insertionSet.insertBottom(upsilonIndex, upsilonOrigin, m_pendingResolutions[var->index()].placeholder->type());
                        }
                        m_insertionSet.insert<UpsilonValue>(upsilonIndex, upsilonOrigin, upsilonChild, phiDef->value());
                    }
                }
            }

            m_insertionSet.execute(block);
        }

        for (auto& resolution : m_pendingResolutions) {
            Value* reachingValue = nullptr;
            for (SSACalculator::Def* phiDef : m_ssa->phisForBlock(resolution.useBlock)) {
                if (phiDef->variable() == resolution.var) {
                    reachingValue = phiDef->value();
                    break;
                }
            }
            if (!reachingValue) {
                SSACalculator::Def* def = m_ssa->reachingDefAtHead(resolution.useBlock, resolution.var);
                ASSERT(def);
                reachingValue = def->value();
            }
            resolution.placeholder->replaceWithIdentity(reachingValue->foldIdentity());
        }
    }

    void process()
    {
        m_value->performSubstitution();

        if (m_pureCSE.process(m_value, *m_dominators)) {
            ASSERT(!m_value->effects().readsPinned || !m_data.writesPinned);
            ASSERT(!m_value->effects().writes);
            ASSERT(!m_value->effects().writesPinned);
            m_changed = true;
            return;
        }

        // If a WasmArrayLength is dominated by the same key's WasmArrayLength,
        // traps-bit does not matter since dominating WasmArrayLength already ensured that
        // traps check is already done. PureCSE already handles same-variant matches above;
        // this queries for the opposite traps-bit variant via ValueKey lookup.
        if (m_value->opcode() == WasmArrayLength) {
            Kind altKind = m_value->kind();
            altKind.setTraps(!altKind.traps());
            ValueKey altKey(altKind, m_value->type(), m_value->child(0));
            if (Value* match = m_pureCSE.findMatch(altKey, m_block, *m_dominators)) {
                m_value->replaceWithIdentity(match);
                m_changed = true;
                return;
            }
        }

        if (WasmAddressValue* wasmAddress = m_value->as<WasmAddressValue>()) {
            processWasmAddressValue(wasmAddress);
            return;
        }

        Effects effects = m_value->effects();

        if (effects.writesPinned) {
            m_data.writesPinned = true;
            m_data.m_candidateWasmAddressesAtTail.clear();
        }

        MemoryValue* memory = m_value->as<MemoryValue>();

        if (memory && processMemoryBeforeClobber(memory))
            return;

        if (HeapRange writes = effects.writes)
            clobber(m_data, writes);

        if (memory)
            processMemoryAfterClobber(memory);

        // The reads info should be updated even the block is processed
        // since the dominated store nodes may dependent on the data
        // read from the processed block. Note that there is no need to
        // update reads info if the node is deleted.
        m_data.reads.add(effects.reads);
    }

    // Return true if we got rid of the operation. If you changed IR in this function, you have to
    // set m_changed even if you also return true.
    bool processMemoryBeforeClobber(MemoryValue* memory)
    {
        Value* value = memory->child(0);
        Value* ptr = memory->lastChild();
        HeapRange range = memory->range();
        Value::OffsetType offset = memory->offset();

        switch (memory->opcode()) {
        case Store8:
            return handleStoreBeforeClobber(
                ptr, range,
                [&] (MemoryValue* candidate) -> bool {
                    return candidate->offset() == offset
                        && ((candidate->opcode() == Store8 && candidate->child(0) == value)
                            || ((candidate->opcode() == Load8Z || candidate->opcode() == Load8S)
                                && candidate == value));
                });
        case Store16:
            return handleStoreBeforeClobber(
                ptr, range,
                [&] (MemoryValue* candidate) -> bool {
                    return candidate->offset() == offset
                        && ((candidate->opcode() == Store16 && candidate->child(0) == value)
                            || ((candidate->opcode() == Load16Z || candidate->opcode() == Load16S)
                                && candidate == value));
                });
        case Store:
            return handleStoreBeforeClobber(
                ptr, range,
                [&] (MemoryValue* candidate) -> bool {
                    return candidate->offset() == offset
                        && ((candidate->opcode() == Store && candidate->child(0) == value)
                            || (candidate->opcode() == Load && candidate == value));
                });
        default:
            return false;
        }
    }

    void clobber(ImpureBlockData& data, HeapRange writes)
    {
        data.writes.add(writes);

        data.memoryValuesAtTail.removeIf(
            [&](MemoryValue* memory) {
                // If memory reads is immutable, clobbering never changes the result.
                if (memory->readsMutability() == Mutability::Immutable)
                    return false;
                return memory->range().overlaps(writes);
            });
    }

    void processMemoryAfterClobber(MemoryValue* memory)
    {
        Value* ptr = memory->lastChild();
        HeapRange range = memory->range();
        Value::OffsetType offset = memory->offset();
        Type type = memory->type();

        // FIXME: Empower this to insert more casts and shifts. For example, a Load8 could match a
        // Store and mask the result. You could even have:
        //
        // Store(@value, @ptr, offset = 0)
        // Load8Z(@ptr, offset = 2)
        //
        // Which could be turned into something like this:
        //
        // Store(@value, @ptr, offset = 0)
        // ZShr(@value, 16)
        
        switch (memory->opcode()) {
        case Load8Z: {
            handleMemoryValue(
                ptr, range,
                [&] (MemoryValue* candidate) -> bool {
                    return candidate->offset() == offset
                        && (candidate->opcode() == Load8Z || candidate->opcode() == Store8);
                },
                [&] (MemoryValue* match, Vector<Value*>& fixups) -> Value* {
                    if (match->opcode() == Store8) {
                        Value* mask = m_proc.add<Const32Value>(m_value->origin(), 0xff);
                        fixups.append(mask);
                        Value* zext = m_proc.add<Value>(
                            BitAnd, m_value->origin(), match->child(0), mask);
                        fixups.append(zext);
                        return zext;
                    }
                    return nullptr;
                });
            break;
        }

        case Load8S: {
            handleMemoryValue(
                ptr, range,
                [&] (MemoryValue* candidate) -> bool {
                    return candidate->offset() == offset
                        && (candidate->opcode() == Load8S || candidate->opcode() == Store8);
                },
                [&] (MemoryValue* match, Vector<Value*>& fixups) -> Value* {
                    if (match->opcode() == Store8) {
                        Value* sext = m_proc.add<Value>(
                            SExt8, m_value->origin(), match->child(0));
                        fixups.append(sext);
                        return sext;
                    }
                    return nullptr;
                });
            break;
        }

        case Load16Z: {
            handleMemoryValue(
                ptr, range,
                [&] (MemoryValue* candidate) -> bool {
                    return candidate->offset() == offset
                        && (candidate->opcode() == Load16Z || candidate->opcode() == Store16);
                },
                [&] (MemoryValue* match, Vector<Value*>& fixups) -> Value* {
                    if (match->opcode() == Store16) {
                        Value* mask = m_proc.add<Const32Value>(m_value->origin(), 0xffff);
                        fixups.append(mask);
                        Value* zext = m_proc.add<Value>(
                            BitAnd, m_value->origin(), match->child(0), mask);
                        fixups.append(zext);
                        return zext;
                    }
                    return nullptr;
                });
            break;
        }

        case Load16S: {
            handleMemoryValue(
                ptr, range, [&] (MemoryValue* candidate) -> bool {
                    return candidate->offset() == offset
                        && (candidate->opcode() == Load16S || candidate->opcode() == Store16);
                },
                [&] (MemoryValue* match, Vector<Value*>& fixups) -> Value* {
                    if (match->opcode() == Store16) {
                        Value* sext = m_proc.add<Value>(
                            SExt16, m_value->origin(), match->child(0));
                        fixups.append(sext);
                        return sext;
                    }
                    return nullptr;
                });
            break;
        }

        case Load: {
            handleMemoryValue(
                ptr, range,
                [&] (MemoryValue* candidate) -> bool {
                    dataLogLnIf(B3EliminateCommonSubexpressionsInternal::verbose, "        Consdering ", pointerDump(candidate));
                    if (candidate->offset() != offset)
                        return false;

                    dataLogLnIf(B3EliminateCommonSubexpressionsInternal::verbose, "            offset ok.");
                    if (candidate->opcode() == Load) {
                        if (candidate->type() == type)
                            return true;
                        if (candidate->type() == Int64 && type == Int32)
                            return true;
                    }

                    dataLogLnIf(B3EliminateCommonSubexpressionsInternal::verbose, "            not a load with ok type.");
                    if (candidate->opcode() == Store) {
                        if (candidate->child(0)->type() == type)
                            return true;
                        if (candidate->child(0)->type() == Int64 && type == Int32)
                            return true;
                    }

                    dataLogLnIf(B3EliminateCommonSubexpressionsInternal::verbose, "            not a store with ok type.");
                    return false;
                },
                [&] (MemoryValue* match, Vector<Value*>& fixups) -> Value* {
                    if (match->opcode() == Load) {
                        if (match->type() == type)
                            return nullptr;

                        if (match->type() == Int64 && type == Int32) {
                            Value* trunc = m_proc.add<Value>(Trunc, m_value->origin(), match);
                            fixups.append(trunc);
                            return trunc;
                        }
                    }

                    if (match->opcode() == Store) {
                        if (match->child(0)->type() == type)
                            return nullptr;

                        if (match->child(0)->type() == Int64 && type == Int32) {
                            Value* trunc = m_proc.add<Value>(Trunc, m_value->origin(), match->child(0));
                            fixups.append(trunc);
                            return trunc;
                        }
                    }

                    return nullptr;
                });
            break;
        }

        case Store8: {
            handleStoreAfterClobber(
                ptr, range,
                [&] (MemoryValue* candidate) -> bool {
                    return candidate->opcode() == Store8
                        && candidate->offset() == offset;
                });
            break;
        }
            
        case Store16: {
            handleStoreAfterClobber(
                ptr, range,
                [&] (MemoryValue* candidate) -> bool {
                    return candidate->opcode() == Store16
                        && candidate->offset() == offset;
                });
            break;
        }
            
        case Store: {
            auto clobberWidth = memory->accessWidth();
            handleStoreAfterClobber(
                ptr, range,
                [&] (MemoryValue* candidate) -> bool {
                    return candidate->opcode() == Store
                        && candidate->offset() == offset
                        && candidate->accessWidth() >= clobberWidth;
                });
            break;
        }

        default:
            break;
        }
    }

    template<typename Filter>
    bool handleStoreBeforeClobber(Value* ptr, HeapRange range, NOESCAPE const Filter& filter)
    {
        MemoryMatches matches = findMemoryValue(ptr, range, filter);
        if (matches.isEmpty())
            return false;

        m_value->replaceWithNop();
        m_changed = true;
        return true;
    }

    template<typename Filter>
    void handleStoreAfterClobber(Value* ptr, HeapRange range, NOESCAPE const Filter& filter)
    {
        if (!m_value->traps() && findStoreAfterClobber(ptr, range, filter)) {
            m_value->replaceWithNop();
            m_changed = true;
            return;
        }

        m_data.memoryValuesAtTail.add(m_value->as<MemoryValue>());
    }

    template<typename Filter>
    bool findStoreAfterClobber(Value* ptr, HeapRange range, NOESCAPE const Filter& filter)
    {
        if (m_value->as<MemoryValue>()->hasFence())
            return false;
        
        // We can eliminate a store if every forward path hits a store to the same location before
        // hitting any operation that observes the store. This search seems like it should be
        // expensive, but in the overwhelming majority of cases it will almost immediately hit an 
        // operation that interferes.

        dataLogLnIf(B3EliminateCommonSubexpressionsInternal::verbose, *m_value, ": looking forward for stores to ", *ptr, "...");

        // First search forward in this basic block.
        // FIXME: It would be cool to get rid of this linear search. It's not super critical since
        // we will probably bail out very quickly, but it *is* annoying.
        for (unsigned index = m_index + 1; index < m_block->size(); ++index) {
            Value* value = m_block->at(index);

            if (MemoryValue* memoryValue = value->as<MemoryValue>()) {
                if (memoryValue->lastChild() == ptr && filter(memoryValue))
                    return true;
            }

            Effects effects = value->effects();
            if (effects.reads.overlaps(range) || effects.writes.overlaps(range))
                return false;
        }

        if (!m_block->numSuccessors())
            return false;

        BlockWorklist worklist;
        worklist.pushAll(m_block->successorBlocks());

        while (BasicBlock* block = worklist.pop()) {
            ImpureBlockData& data = m_impureBlockData[block];

            MemoryValue* match = data.memoryStoresAtHead.find(ptr, filter);
            if (match && match != m_value)
                continue;

            if (data.writes.overlaps(range) || data.reads.overlaps(range))
                return false;

            if (!block->numSuccessors())
                return false;

            worklist.pushAll(block->successorBlocks());
        }

        return true;
    }

    template<typename Filter, typename Replace>
    void handleMemoryValue(
        Value* ptr, HeapRange range, NOESCAPE const Filter& filter, NOESCAPE const Replace& replace)
    {
        // FIXME: Currently we observed some performance regression in this case.
        MemoryMatches matches = findMemoryValue(ptr, range, filter /* , m_value->as<MemoryValue>()->readsMutability() */);
        if (replaceMemoryValue(matches, replace))
            return;
        m_data.memoryValuesAtTail.add(m_value->as<MemoryValue>());
    }

    template<typename Replace>
    bool replaceMemoryValue(const MemoryMatches& matches, NOESCAPE const Replace& replace)
    {
        if (matches.isEmpty())
            return false;

        dataLogLnIf(B3EliminateCommonSubexpressionsInternal::verbose, "Eliminating ", *m_value, " due to ", pointerListDump(matches));
        
        m_changed = true;

        if (matches.size() == 1) {
            MemoryValue* dominatingMatch = matches[0];
            RELEASE_ASSERT(m_dominators->dominates(dominatingMatch->owner, m_block));
            
            dataLogLnIf(B3EliminateCommonSubexpressionsInternal::verbose, "    Eliminating using ", *dominatingMatch);
            Vector<Value*> extraValues;
            if (Value* value = replace(dominatingMatch, extraValues)) {
                for (Value* extraValue : extraValues)
                    m_insertionSet.insertValue(m_index, extraValue);
                m_value->replaceWithIdentity(value);
            } else {
                if (dominatingMatch->isStore())
                    m_value->replaceWithIdentity(dominatingMatch->child(0));
                else
                    m_value->replaceWithIdentity(dominatingMatch);
            }
            return true;
        }


        // addBottom creates a fresh Const; InsertionSet::insertBottom would
        // alias placeholders of the same type within one block.
        SSACalculator::Variable* var = m_ssa->newVariable();
        Value* placeholder = m_proc.addBottom(m_value->origin(), m_value->type());
        m_insertionSet.insertValue(m_index, placeholder);
        dataLogLnIf(B3EliminateCommonSubexpressionsInternal::verbose, "    Inserting placeholder for value: ", *placeholder);
        m_value->replaceWithIdentity(placeholder);

        for (MemoryValue* match : matches) {
            m_blocksWithSets.add(match->owner);
            auto& extras = m_sets.add(match, Vector<Value*>()).iterator->value;
            m_matched.add(match);
            Value* value = replace(match, extras);
            if (!value) {
                if (match->isStore())
                    value = match->child(0);
                else
                    value = match;
            }

            m_ssa->newDef(var, match->owner, value);
        }

        m_pendingResolutions.append({ placeholder, m_block, var });
        ASSERT(var->index() == m_pendingResolutions.size() - 1);
        return true;
    }

    template<typename Filter>
    MemoryMatches findMemoryValue(Value* ptr, HeapRange range, NOESCAPE const Filter& filter, Mutability readsMutability = Mutability::Mutable)
    {
        if constexpr (B3EliminateCommonSubexpressionsInternal::verbose) {
            dataLogLn(*m_value, ": looking backward for ", *ptr, "...");
            dataLogLn("    Full value: ", deepDump(m_value));
        }
        
        if (m_value->as<MemoryValue>()->hasFence()) {
            dataLogLnIf(B3EliminateCommonSubexpressionsInternal::verbose, "    Giving up because fences.");
            return { };
        }
        
        if (MemoryValue* match = m_data.memoryValuesAtTail.find(ptr, filter)) {
            dataLogLnIf(B3EliminateCommonSubexpressionsInternal::verbose, "    Found ", *match, " locally.");
            return { match };
        }

        if (readsMutability != Mutability::Immutable && m_data.writes.overlaps(range)) {
            dataLogLnIf(B3EliminateCommonSubexpressionsInternal::verbose, "    Giving up because of writes.");
            return { };
        }

        BlockWorklist worklist;
        worklist.pushAll(m_block->predecessors());

        MemoryMatches matches;

        while (BasicBlock* block = worklist.pop()) {
            dataLogLnIf(B3EliminateCommonSubexpressionsInternal::verbose, "    Looking at ", *block);

            ImpureBlockData& data = m_impureBlockData[block];

            MemoryValue* match = data.memoryValuesAtTail.find(ptr, filter);
            dataLogLnIf(B3EliminateCommonSubexpressionsInternal::verbose, "    Consdering match: ", pointerDump(match));
            if (match && match != m_value) {
                dataLogLnIf(B3EliminateCommonSubexpressionsInternal::verbose, "    Found match: ", *match);
                matches.append(match);
                continue;
            }

            if (readsMutability != Mutability::Immutable && data.writes.overlaps(range)) {
                dataLogLnIf(B3EliminateCommonSubexpressionsInternal::verbose, "    Giving up because of writes.");
                return { };
            }

            if (!block->numPredecessors()) {
                dataLogLnIf(B3EliminateCommonSubexpressionsInternal::verbose, "    Giving up because it's live at root.");
                // This essentially proves that this is live at the prologue. That means that we
                // cannot reliably optimize this case.
                return { };
            }
            
            worklist.pushAll(block->predecessors());
        }

        dataLogLnIf(B3EliminateCommonSubexpressionsInternal::verbose, "    Got matches: ", pointerListDump(matches));
        return matches;
    }

    void processWasmAddressValue(WasmAddressValue* wasmAddress)
    {
        Value* ptr = wasmAddress->child(0);

        if (Value* replacement = m_data.m_candidateWasmAddressesAtTail.get(ptr)) {
            dataLogLnIf(B3EliminateCommonSubexpressionsInternal::verbose, "    Replacing WasmAddress: ", *wasmAddress, " with ", *replacement);
            wasmAddress->replaceWithIdentity(replacement);
            m_changed = true;
            return;
        }

        auto addPtrOnScopeExit = makeScopeExit([&] {
            m_data.m_candidateWasmAddressesAtTail.add(ptr, wasmAddress);
        });

        if (m_data.writesPinned) {
            // Someone before us in this block wrote to pinned. So we have no
            // hope of finding a match if the above search failed.
            return;
        }

        Value* candidateReplacement = nullptr;
        BasicBlock* dominator = nullptr;
        m_dominators->forAllStrictDominatorsOf(m_block, [&] (BasicBlock* block) {
            if (candidateReplacement)
                return;

            if (Value* replacement = m_impureBlockData[block].m_candidateWasmAddressesAtTail.get(ptr)) {
                candidateReplacement = replacement;
                dominator = block;
            }
        });

        if (!candidateReplacement)
            return;

        BlockWorklist worklist;
        worklist.pushAll(m_block->predecessors());
        while (BasicBlock* block = worklist.pop()) {
            if (block == dominator)
                continue;
            if (m_impureBlockData[block].writesPinned) {
                candidateReplacement = nullptr;
                break;
            }
            worklist.pushAll(block->predecessors());
        }

        if (candidateReplacement) {
            dataLogLnIf(B3EliminateCommonSubexpressionsInternal::verbose, "    Replacing WasmAddress: ", *wasmAddress, " with ", *candidateReplacement);
            wasmAddress->replaceWithIdentity(candidateReplacement);
            m_changed = true;
        }
    }

    Procedure& m_proc;

    Dominators* m_dominators { nullptr };
    PureCSE m_pureCSE;

    IndexMap<BasicBlock*, ImpureBlockData> m_impureBlockData;

    ImpureBlockData m_data;

    BasicBlock* m_block { nullptr };
    unsigned m_index { 0 };
    Value* m_value { nullptr };

    // Match -> extra fixup values (e.g. BitAnd masks for packed Wasm types),
    // flushed at match site during finalize().
    UncheckedKeyHashMap<Value*, Vector<Value*>> m_sets;
    IndexSet<Value*> m_matched;
    // Blocks that own at least one m_sets key, so finalize() can skip whole blocks.
    IndexSet<BasicBlock*> m_blocksWithSets;

    InsertionSet m_insertionSet;

    std::unique_ptr<SSACalculator> m_ssa;

    struct PendingResolution {
        Value* placeholder;
        BasicBlock* useBlock;
        SSACalculator::Variable* var;
    };
    Vector<PendingResolution> m_pendingResolutions;

    bool m_changed { false };
};

} // anonymous namespace

bool eliminateCommonSubexpressions(Procedure& proc)
{
    PhaseScope phaseScope(proc, "eliminateCommonSubexpressions"_s);

    CSE cse(proc);
    return cse.run();
}

} } // namespace JSC::B3

#endif // ENABLE(B3_JIT)

