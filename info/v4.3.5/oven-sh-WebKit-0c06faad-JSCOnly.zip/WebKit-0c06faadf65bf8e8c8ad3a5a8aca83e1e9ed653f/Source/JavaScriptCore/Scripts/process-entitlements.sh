#!/bin/bash

function plistbuddy()
{
    /usr/libexec/PlistBuddy -c "$*" "${WK_PROCESSED_XCENT_FILE}" | fgrep -vE "(File Doesn't Exist|Initializing Plist)" || true
    return ${PIPESTATUS[0]}
}

# ========================================
# Mac entitlements
# ========================================

function mac_process_jsc_entitlements()
{
    plistbuddy Add :com.apple.security.cs.allow-jit bool YES
    if [[ "${WK_USE_FATAL_EXCEPTIONS}" == YES ]]
    then
        plistbuddy Add :com.apple.security.fatal-exceptions array
        plistbuddy Add :com.apple.security.fatal-exceptions:0 string jit
    fi

    if [[ "${WK_USE_RESTRICTED_ENTITLEMENTS}" == YES ]]
    then
        if [[ "${WK_USE_FATAL_EXCEPTIONS}" == YES ]]
        then
            plistbuddy Add :com.apple.private.pac.exception bool YES
        fi

        plistbuddy Add :com.apple.security.cs.jit-write-allowlist bool YES
        plistbuddy Add :com.apple.developer.kernel.extended-virtual-addressing bool YES

        if [[ -z "${SKIP_ROSETTA_BREAKING_ENTITLEMENTS}" ]]
        then
            plistbuddy Add :com.apple.private.verified-jit bool YES
            plistbuddy Add :com.apple.security.cs.single-jit bool YES
        fi

        plistbuddy Add :com.apple.developer.hardened-process bool YES
    fi
}

function mac_process_testapi_entitlements()
{
    if [[ "${WK_USE_FATAL_EXCEPTIONS}" == YES ]]
    then
        plistbuddy Add :com.apple.security.fatal-exceptions array
        plistbuddy Add :com.apple.security.fatal-exceptions:0 string jit
    fi
    if [[ "${WK_USE_RESTRICTED_ENTITLEMENTS}" == YES ]]
    then
        if [[ "${WK_USE_FATAL_EXCEPTIONS}" == YES ]]
        then
            plistbuddy Add :com.apple.private.pac.exception bool YES
        fi

        plistbuddy Add :com.apple.security.cs.allow-jit bool YES
        plistbuddy Add :com.apple.rootless.storage.JavaScriptCore bool YES

        plistbuddy Add :com.apple.security.cs.jit-write-allowlist bool YES
        plistbuddy Add :com.apple.developer.kernel.extended-virtual-addressing bool YES

        if [[ -z "${SKIP_ROSETTA_BREAKING_ENTITLEMENTS}" ]]
        then
            plistbuddy Add :com.apple.private.verified-jit bool YES
            plistbuddy Add :com.apple.security.cs.single-jit bool YES
        fi

        plistbuddy Add :com.apple.developer.hardened-process bool YES
    fi
}

function mac_process_mya_entitlements()
{
    if [[ "${WK_USE_RESTRICTED_ENTITLEMENTS}" == YES ]]
    then
        plistbuddy Add :com.apple.private.cs.debugger bool YES

        if [[ "${WK_USE_FATAL_EXCEPTIONS}" == YES ]]
        then
            plistbuddy Add :com.apple.private.pac.exception bool YES
        fi

        plistbuddy Add :com.apple.developer.kernel.extended-virtual-addressing bool YES

        plistbuddy Add :com.apple.developer.hardened-process bool YES
    fi
}

# ========================================
# macCatalyst entitlements
# ========================================

function maccatalyst_process_jsc_entitlements()
{
    plistbuddy Add :com.apple.security.cs.allow-jit bool YES
    if [[ "${WK_USE_FATAL_EXCEPTIONS}" == YES ]]
    then
        plistbuddy Add :com.apple.security.fatal-exceptions array
        plistbuddy Add :com.apple.security.fatal-exceptions:0 string jit
    fi

    if [[ "${WK_USE_RESTRICTED_ENTITLEMENTS}" == YES ]]
    then
        if [[ "${WK_USE_FATAL_EXCEPTIONS}" == YES ]]
        then
            plistbuddy Add :com.apple.private.pac.exception bool YES
        fi

        plistbuddy Add :com.apple.security.cs.jit-write-allowlist bool YES
        plistbuddy Add :com.apple.developer.kernel.extended-virtual-addressing bool YES

        plistbuddy Add :com.apple.developer.hardened-process bool YES
    fi

    if [[ -z "${SKIP_ROSETTA_BREAKING_ENTITLEMENTS}" ]]
    then
        plistbuddy Add :com.apple.private.verified-jit bool YES
        plistbuddy Add :com.apple.security.cs.single-jit bool YES
    fi
}

function maccatalyst_process_testapi_entitlements()
{
    plistbuddy Add :com.apple.rootless.storage.JavaScriptCore bool YES
    plistbuddy Add :com.apple.security.cs.allow-jit bool YES

    if [[ "${WK_USE_FATAL_EXCEPTIONS}" == YES ]]
    then
        plistbuddy Add :com.apple.security.fatal-exceptions array
        plistbuddy Add :com.apple.security.fatal-exceptions:0 string jit
    fi

    if [[ "${WK_USE_RESTRICTED_ENTITLEMENTS}" == YES ]]
    then
        if [[ "${WK_USE_FATAL_EXCEPTIONS}" == YES ]]
        then
            plistbuddy Add :com.apple.private.pac.exception bool YES
        fi

        plistbuddy Add :com.apple.developer.hardened-process bool YES
    fi

    plistbuddy Add :com.apple.security.cs.jit-write-allowlist bool YES
    plistbuddy Add :com.apple.developer.kernel.extended-virtual-addressing bool YES

    if [[ -z "${SKIP_ROSETTA_BREAKING_ENTITLEMENTS}" ]]
    then
        plistbuddy Add :com.apple.private.verified-jit bool YES
        plistbuddy Add :com.apple.security.cs.single-jit bool YES
    fi
}

function maccatalyst_process_mya_entitlements()
{
    if [[ "${WK_USE_RESTRICTED_ENTITLEMENTS}" == YES ]]
    then
        plistbuddy Add :com.apple.private.cs.debugger bool YES

        if [[ "${WK_USE_FATAL_EXCEPTIONS}" == YES ]]
        then
            plistbuddy Add :com.apple.private.pac.exception bool YES
        fi

        plistbuddy Add :com.apple.developer.kernel.extended-virtual-addressing bool YES

        plistbuddy Add :com.apple.developer.hardened-process bool YES
    fi
}

# ========================================
# iOS Family entitlements
# ========================================

function ios_family_process_jsc_entitlements()
{
    if [[ "${WK_USE_FATAL_EXCEPTIONS}" == YES ]]
    then
        plistbuddy Add :com.apple.security.fatal-exceptions array
        plistbuddy Add :com.apple.security.fatal-exceptions:0 string jit
        plistbuddy Add :com.apple.private.pac.exception bool YES
    fi

    # If you update this, make sure to update jsc.cpp:3973 (or somewhere around there) to
    # ensure that `Options::crashIfCantAllocateJITMemory` is disabled on non-JIT platforms
    if [[ "${PLATFORM_NAME}" != watchos && "${PLATFORM_NAME}" != appletvos ]]; then
        plistbuddy Add :com.apple.private.verified-jit bool YES
        if [[ "${PLATFORM_NAME}" == iphoneos ]]; then
            if (( $(( ${SDK_VERSION_ACTUAL} )) >= 170400 )); then
                plistbuddy Add :com.apple.developer.cs.allow-jit bool YES
                plistbuddy Add :com.apple.developer.web-browser-engine.webcontent bool YES
            else
                plistbuddy Add :dynamic-codesigning bool YES
            fi
        else
            plistbuddy Add :dynamic-codesigning bool YES
        fi
    fi
    plistbuddy Add :com.apple.developer.kernel.extended-virtual-addressing bool YES
    plistbuddy Add :com.apple.developer.hardened-process bool YES
}

function ios_family_process_mya_entitlements()
{
    if [[ "${WK_USE_RESTRICTED_ENTITLEMENTS}" == YES ]]
    then
        plistbuddy Add :com.apple.private.cs.debugger bool YES
    fi

    if [[ "${WK_USE_FATAL_EXCEPTIONS}" == YES ]]
    then
        plistbuddy Add :com.apple.private.pac.exception bool YES
    fi

    plistbuddy Add :com.apple.developer.kernel.extended-virtual-addressing bool YES
    plistbuddy Add :com.apple.developer.hardened-process bool YES
}

rm -f "${WK_PROCESSED_XCENT_FILE}"
plistbuddy Clear dict

if [[ "${WK_PLATFORM_NAME}" =~ .*simulator ]]
then
    [[ "${RC_XBS}" != YES ]] && plistbuddy Add :com.apple.security.get-task-allow bool YES
elif [[ "${WK_PLATFORM_NAME}" == macosx ]]
then
    [[ "${RC_XBS}" != YES ]] && [[ "${WK_USE_RESTRICTED_ENTITLEMENTS}" == YES ]] && plistbuddy Add :com.apple.security.get-task-allow bool YES

    if [[ "${PRODUCT_NAME}" == jsc ||
          "${PRODUCT_NAME}" == dynbench ||
          "${PRODUCT_NAME}" == minidom ||
          "${PRODUCT_NAME}" == testair ||
          "${PRODUCT_NAME}" == testb3 ||
          "${PRODUCT_NAME}" == testdfg ||
          "${PRODUCT_NAME}" == testmasm ||
          "${PRODUCT_NAME}" == testmem ||
          "${PRODUCT_NAME}" == testRegExp ]]; then mac_process_jsc_entitlements
    elif [[ "${PRODUCT_NAME}" == testapi ]]; then mac_process_testapi_entitlements
    elif [[ "${PRODUCT_NAME}" == mya ]]; then mac_process_mya_entitlements
    # testLibJSCTools only ever snapshots its own process, which needs no entitlement.
    elif [[ "${PRODUCT_NAME}" == testLibJSCTools ]]; then true
    else echo "Unsupported/unknown product: ${PRODUCT_NAME}"
    fi
elif [[ "${WK_PLATFORM_NAME}" == maccatalyst || "${WK_PLATFORM_NAME}" == iosmac ]]
then
    [[ "${RC_XBS}" != YES && "${PRODUCT_NAME}" == jsc ]] && plistbuddy Add :com.apple.security.get-task-allow bool YES

    if [[ "${PRODUCT_NAME}" == jsc ||
          "${PRODUCT_NAME}" == dynbench ||
          "${PRODUCT_NAME}" == minidom ||
          "${PRODUCT_NAME}" == testair ||
          "${PRODUCT_NAME}" == testb3 ||
          "${PRODUCT_NAME}" == testdfg ||
          "${PRODUCT_NAME}" == testmasm ||
          "${PRODUCT_NAME}" == testmem ||
          "${PRODUCT_NAME}" == testRegExp ]]; then maccatalyst_process_jsc_entitlements
    elif [[ "${PRODUCT_NAME}" == testapi ]]; then maccatalyst_process_testapi_entitlements
    elif [[ "${PRODUCT_NAME}" == mya ]]; then maccatalyst_process_mya_entitlements
    # testLibJSCTools only ever snapshots its own process, which needs no entitlement.
    elif [[ "${PRODUCT_NAME}" == testLibJSCTools ]]; then true
    else echo "Unsupported/unknown product: ${PRODUCT_NAME}"
    fi
elif [[ "${WK_PLATFORM_NAME}" == iphoneos ||
        "${WK_PLATFORM_NAME}" == appletvos ||
        "${WK_PLATFORM_NAME}" == watchos ||
        "${WK_PLATFORM_NAME}" == xros ]]
then
    if [[ "${PRODUCT_NAME}" == jsc ||
          "${PRODUCT_NAME}" == dynbench ||
          "${PRODUCT_NAME}" == minidom ||
          "${PRODUCT_NAME}" == testapi ||
          "${PRODUCT_NAME}" == testair ||
          "${PRODUCT_NAME}" == testb3 ||
          "${PRODUCT_NAME}" == testdfg ||
          "${PRODUCT_NAME}" == testmasm ||
          "${PRODUCT_NAME}" == testmem ||
          "${PRODUCT_NAME}" == testRegExp ]]; then ios_family_process_jsc_entitlements
    elif [[ "${PRODUCT_NAME}" == mya ]]; then ios_family_process_mya_entitlements
    # testLibJSCTools only ever snapshots its own process, which needs no entitlement.
    elif [[ "${PRODUCT_NAME}" == testLibJSCTools ]]; then true
    else echo "Unsupported/unknown product: ${PRODUCT_NAME}"
    fi
else
    echo "Unsupported/unknown platform: ${WK_PLATFORM_NAME}"
fi

exit 0
