Math.max = undefined;
