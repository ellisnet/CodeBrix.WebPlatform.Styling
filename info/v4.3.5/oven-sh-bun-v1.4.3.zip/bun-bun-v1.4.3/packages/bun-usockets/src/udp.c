/*
 * Authored by Alex Hultman, 2018-2021.
 * Intellectual property of third-party.

 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at

 *     http://www.apache.org/licenses/LICENSE-2.0

 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#include "libusockets.h"
#include "internal/internal.h"

#include <string.h>

char *us_udp_packet_buffer_peer(struct us_udp_packet_buffer_t *buf, int index) {
    return bsd_udp_packet_buffer_peer((struct udp_recvbuf *)buf, index);
}

char *us_udp_packet_buffer_payload(struct us_udp_packet_buffer_t *buf, int index) {
    return bsd_udp_packet_buffer_payload((struct udp_recvbuf *)buf, index);
}

int us_udp_packet_buffer_payload_length(struct us_udp_packet_buffer_t *buf, int index) {
    return bsd_udp_packet_buffer_payload_length((struct udp_recvbuf *)buf, index);
}

int us_udp_packet_buffer_truncated(struct us_udp_packet_buffer_t *buf, int index) {
    return bsd_udp_packet_buffer_truncated((struct udp_recvbuf *)buf, index);
}

int us_udp_socket_send(struct us_udp_socket_t *s, void** payloads, size_t* lengths, void** addresses, int num) {
    if (num == 0) return 0;
    int fd = us_poll_fd((struct us_poll_t *) s);

    struct udp_sendbuf *buf = (struct udp_sendbuf *)s->loop->data.send_buf;

    int total_sent = 0;
    while (num > 0) {
        int count = bsd_udp_setup_sendbuf(buf, LIBUS_SEND_BUFFER_LENGTH, payloads, lengths, addresses, num);
        payloads += count;
        lengths += count;
        addresses += count;
        num -= count;
        // TODO nohang flag?
        int sent = bsd_sendmmsg(fd, buf, MSG_DONTWAIT);
        if (sent < 0) {
            /* Linux sendmmsg reports EAGAIN as -1 (per-msg-loop platforms
             * report it as sent==0): re-arm writable so on_drain fires and
             * report how many earlier batches went out. */
            if (bsd_would_block()) {
                us_poll_change((struct us_poll_t *) s, s->loop, LIBUS_SOCKET_READABLE | LIBUS_SOCKET_WRITABLE);
                return total_sent;
            }
            return total_sent > 0 ? total_sent : sent;
        }
        total_sent += sent;
        if (sent < count) {
            /* Partial batch: kernel send buffer is full. Re-arm writable so
             * on_drain fires and stop — retrying now would just spin on EAGAIN. */
            us_poll_change((struct us_poll_t *) s, s->loop, LIBUS_SOCKET_READABLE | LIBUS_SOCKET_WRITABLE);
            return total_sent;
        }
    }
    return total_sent;
}

int us_udp_socket_bound_port(struct us_udp_socket_t *s) {
    /* An adopted-but-unbound descriptor cached port 0 at creation; the kernel
     * auto-binds on the first sendto(), so re-query then. */
    if (s->port == 0) {
        struct bsd_addr_t tmp = {0};
        if (bsd_local_addr(us_poll_fd(&s->p), &tmp) == 0) {
            s->port = (uint16_t) bsd_addr_get_port(&tmp);
        }
    }
    return s->port;
}

void us_udp_socket_bound_ip(struct us_udp_socket_t *s, char *buf, int *length) {
  struct bsd_addr_t addr;
  if (bsd_local_addr(us_poll_fd((struct us_poll_t *)s), &addr) || *length < bsd_addr_get_ip_length(&addr)) {
    *length = 0;
  } else {
    *length = bsd_addr_get_ip_length(&addr);
    memcpy(buf, bsd_addr_get_ip(&addr), *length);
  }
}

void us_udp_socket_remote_ip(struct us_udp_socket_t *s, char *buf, int *length) {
  struct bsd_addr_t addr;
  if (bsd_remote_addr(us_poll_fd((struct us_poll_t *)s), &addr) || *length < bsd_addr_get_ip_length(&addr)) {
    *length = 0;
  } else {
    *length = bsd_addr_get_ip_length(&addr);
    memcpy(buf, bsd_addr_get_ip(&addr), *length);
  }
}

__attribute__((always_inline)) void *us_udp_socket_user(struct us_udp_socket_t *udp) {
    return udp->user;
}

void us_udp_socket_close(struct us_udp_socket_t *s) {
    struct us_loop_t *loop = s->loop;
    struct us_poll_t *p = (struct us_poll_t *) s;
    us_poll_stop(p, loop);
    bsd_close_socket(us_poll_fd(p));
    s->closed = 1;
    s->next = loop->data.closed_udp_head;
    loop->data.closed_udp_head = s;
    s->on_close(s);
}

int us_udp_socket_set_broadcast(struct us_udp_socket_t *s, int enabled) {
    return bsd_socket_broadcast(us_poll_fd(&s->p), enabled);
}

int us_udp_socket_buffer_size(struct us_udp_socket_t *s, int is_recv, int size, int *out) {
    return bsd_socket_buffer_size(us_poll_fd(&s->p), is_recv, size, out);
}

LIBUS_SOCKET_DESCRIPTOR us_udp_socket_fd(struct us_udp_socket_t *s) {
    return us_poll_fd(&s->p);
}

int us_udp_socket_set_ttl_unicast(struct us_udp_socket_t *s, int ttl) {
    return bsd_socket_ttl_unicast(us_poll_fd(&s->p), ttl);
}

int us_udp_socket_set_ttl_multicast(struct us_udp_socket_t *s, int ttl) {
    return bsd_socket_ttl_multicast(us_poll_fd(&s->p), ttl);
}

int us_udp_socket_connect(struct us_udp_socket_t *s, const char* host, unsigned short port) {
    return bsd_connect_udp_socket(us_poll_fd((struct us_poll_t *)s), host, port);
}

int us_udp_socket_disconnect(struct us_udp_socket_t *s) {
    return bsd_disconnect_udp_socket(us_poll_fd((struct us_poll_t *)s));
}

int us_udp_socket_set_multicast_loopback(struct us_udp_socket_t *s, int enabled) {
    return bsd_socket_multicast_loopback(us_poll_fd(&s->p), enabled);
}

int us_udp_socket_set_multicast_interface(struct us_udp_socket_t *s, const struct sockaddr_storage *addr) {
    return bsd_socket_multicast_interface(us_poll_fd(&s->p), addr);
}

int us_udp_socket_set_membership(struct us_udp_socket_t *s, const struct sockaddr_storage *addr, const struct sockaddr_storage *iface, int drop) {
    return bsd_socket_set_membership(us_poll_fd(&s->p), addr, iface, drop);
}

int us_udp_socket_set_source_specific_membership(struct us_udp_socket_t *s, const struct sockaddr_storage *source, const struct sockaddr_storage *group, const struct sockaddr_storage *iface, int drop) {
    return bsd_socket_set_source_specific_membership(us_poll_fd(&s->p), source, group, iface, drop);
}


struct us_udp_socket_t *us_create_udp_socket_from_fd(
    struct us_loop_t *loop,
    void (*data_cb)(struct us_udp_socket_t *, void *, int),
    void (*drain_cb)(struct us_udp_socket_t *),
    void (*close_cb)(struct us_udp_socket_t *),
    void (*recv_error_cb)(struct us_udp_socket_t *, int, int),
    LIBUS_SOCKET_DESCRIPTOR fd,
    int shared,
    int *err,
    void *user
) {
    if (bsd_prepare_adopted_udp_socket(fd)) {
        if (err != NULL) {
#ifdef _WIN32
            *err = WSAGetLastError();
#else
            *err = errno;
#endif
        }
        return 0;
    }

    int ext_size = 0;
    int fallthrough = 0;

    struct us_poll_t *p = us_create_poll(loop, fallthrough, sizeof(struct us_udp_socket_t) + ext_size);
    us_poll_init(p, fd, POLL_TYPE_UDP);

    struct us_udp_socket_t *udp = (struct us_udp_socket_t *)p;

    struct bsd_addr_t tmp = {0};
    bsd_local_addr(fd, &tmp);
    udp->port = bsd_addr_get_port(&tmp);
    udp->loop = loop;

    udp->user = user;

    udp->closed = 0;
    udp->shared_fd = shared ? 1 : 0;
    udp->on_data = data_cb;
    udp->on_drain = drain_cb;
    udp->on_close = close_cb;
    udp->on_recv_error = recv_error_cb;
    udp->next = NULL;

    if (us_poll_start_rc((struct us_poll_t *) udp, udp->loop, LIBUS_SOCKET_READABLE | LIBUS_SOCKET_WRITABLE) != 0) {
        int saved_errno = errno;
        us_poll_free(p, loop);
        if (err) *err = saved_errno;
        errno = saved_errno;
        return 0;
    }

    return (struct us_udp_socket_t *) udp;
}

struct us_udp_socket_t *us_create_udp_socket(
    struct us_loop_t *loop,
    void (*data_cb)(struct us_udp_socket_t *, void *, int),
    void (*drain_cb)(struct us_udp_socket_t *),
    void (*close_cb)(struct us_udp_socket_t *),
    void (*recv_error_cb)(struct us_udp_socket_t *, int, int),
    const char *host,
    unsigned short port,
    int flags,
    int *err,
    void *user
) {

    /* IP_RECVERR is only useful when there is an on_recv_error handler to
     * drain the error queue; without one it only poisons subsequent sends. */
    if (recv_error_cb) flags |= LIBUS_UDP_LINUX_RECVERR;
    else flags &= ~LIBUS_UDP_LINUX_RECVERR;
    LIBUS_SOCKET_DESCRIPTOR fd = bsd_create_udp_socket(host, port, flags, err);
    if (fd == LIBUS_SOCKET_ERROR) {
        return 0;
    }

    int ext_size = 0;
    int fallthrough = 0;

    struct us_poll_t *p = us_create_poll(loop, fallthrough, sizeof(struct us_udp_socket_t) + ext_size);
    us_poll_init(p, fd, POLL_TYPE_UDP);
    if (us_poll_start_rc(p, loop, LIBUS_SOCKET_READABLE | LIBUS_SOCKET_WRITABLE) != 0) {
        int saved_errno = errno;
        bsd_close_socket(fd);
        us_poll_free(p, loop);
        if (err) *err = saved_errno;
        errno = saved_errno;
        return 0;
    }

    struct us_udp_socket_t *udp = (struct us_udp_socket_t *)p;

    /* Get and store the port once */
    struct bsd_addr_t tmp = {0};
    bsd_local_addr(fd, &tmp);
    udp->port = bsd_addr_get_port(&tmp);
    udp->loop = loop;

    /* There is no udp socket context, only user data */
    /* This should really be ext like everything else */
    udp->user = user;

    udp->closed = 0;
    udp->shared_fd = 0;
    udp->on_data = data_cb;
    udp->on_drain = drain_cb;
    udp->on_close = close_cb;
    udp->on_recv_error = recv_error_cb;
    udp->next = NULL;

    return (struct us_udp_socket_t *) udp;
}
