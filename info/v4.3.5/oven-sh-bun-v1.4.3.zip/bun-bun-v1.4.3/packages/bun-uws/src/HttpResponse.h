/*
 * Authored by Alex Hultman, 2018-2020.
 * Intellectual property of third-party.

 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at

 *     http://www.apache.org/licenses/LICENSE-2.0

 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
// clang-format off
#ifndef UWS_HTTPRESPONSE_H
#define UWS_HTTPRESPONSE_H

/* An HttpResponse is the channel on which you send back a response */

#include "AsyncSocket.h"
#include "HttpResponseData.h"
#include "HttpContext.h"
#include "HttpContextData.h"
#include "Utilities.h"

#include "WebSocketExtensions.h"
#include "WebSocketHandshake.h"
#include "WebSocket.h"
#include "WebSocketContextData.h"

#include "MoveOnlyFunction.h"

/* todo: tryWrite is missing currently, only send smaller segments with write */

namespace uWS {

template <bool, bool, typename> struct WebSocketContext;

/* Some pre-defined status constants to use with writeStatus */
inline constexpr const char* HTTP_200_OK = "200 OK";

template <bool SSL>
struct HttpResponse : public AsyncSocket<SSL> {
    /* Solely used for getHttpResponseData() */
    template <bool> friend struct TemplatedApp;
    typedef AsyncSocket<SSL> Super;
public:

    HttpResponseData<SSL> *getHttpResponseData() {
        return (HttpResponseData<SSL> *) Super::getAsyncSocketData();
    }

    void setTimeout(uint8_t seconds) {
        auto* data = getHttpResponseData();
        data->idleTimeout = seconds;
        Super::timeout(data->idleTimeout);
    }

    void resetTimeout() {
        auto* data = getHttpResponseData();

        Super::timeout(data->idleTimeout);
    }
    /* The chunk-size line of a chunk. Returns its length. */
    static constexpr size_t CHUNK_HEAD_MAX = 10;
    static size_t chunkHead(char (&buf)[CHUNK_HEAD_MAX], unsigned int chunkLength) {
        int length = utils::u32toaHex(chunkLength, buf);
        buf[length++] = '\r';
        buf[length++] = '\n';
        return (size_t) length;
    }

    /* Write an unsigned 64-bit integer */
    void writeUnsigned64(uint64_t value) {
        char buf[utils::U64_MAX_DIGITS];
        int length = utils::u64toa(value, buf);

        /* For now we do this copy */
        Super::write(buf, length);
    }

    /* Called only once per request */
    void writeMark() {
        if (getHttpResponseData()->state & HttpResponseData<SSL>::HTTP_WROTE_DATE_HEADER) {
            return;
        }
        /* Date is always written */
        writeHeader("Date", std::string_view(((LoopData *) us_loop_ext(us_socket_group_loop(us_socket_group((us_socket_t *) this))))->date, 29));
        getHttpResponseData()->state |= HttpResponseData<SSL>::HTTP_WROTE_DATE_HEADER;
    }

    /* Shutdown+close when the connection is marked to close (Connection:
     * close, peer FIN, close-when-idle), the response is complete and every
     * outgoing byte has been flushed. Returns true when the socket was closed. */
    bool closeIfDoneAndMarked(HttpResponseData<SSL> *httpResponseData) {
        if (httpResponseData->shouldCloseConnection()) {
            if ((httpResponseData->state & HttpResponseData<SSL>::HTTP_RESPONSE_PENDING) == 0) {
                if (((AsyncSocket<SSL> *) this)->hasFullyDrained()) {
                    ((AsyncSocket<SSL> *) this)->shutdown();
                    /* We need to force close after sending FIN since we want to hinder
                     * clients from keeping to send their huge data */
                    ((AsyncSocket<SSL> *) this)->close();
                    return true;
                }
            }
        }
        return false;
    }

    /* Called when a response completes. Returns true when the
     * caller has to run the close gate now, false when onData runs it.
     *
     * The socket onData is parsing gets onData's uncork and close gate once the
     * read is consumed: false. A Bun.serve response that needed no JavaScript
     * (a static route) leaves the cork to onData, so such responses to requests
     * pipelined in one read share one send(). Bun sends them earlier, with
     * sendCorked(), when the handler of a later request is about to run
     * JavaScript. A response that JavaScript produced (sendWhenComplete()) is
     * sent now, and so is a node:http response: its 'finish' event and end()
     * callback run before onData gets control back and expect the bytes to be
     * out.
     *
     * Any other socket (an async handler completing, possibly inside another
     * socket's parse window via a drained microtask) is uncorked here and gets
     * no later uncork or gate: true. */
    bool uncorkCompletedResponse() {
        HttpContext<SSL> *httpContext = HttpContext<SSL>::fromSocket((us_socket_t *) this);
        const bool parsingThis = httpContext->getSocketContextData()->parsingSocket == (us_socket_t *) this;
        if (!Super::isCorked()) {
            /* A write larger than the cork buffer released the cork. The rest of this read can hold the body of a node:http request. */
            return !(parsingThis && httpContext->isNodeHttp());
        }
        if (!parsingThis) {
            this->uncork();
            return true;
        }
        if (httpContext->isNodeHttp() || (getHttpResponseData()->state & HttpResponseData<SSL>::HTTP_SEND_WHEN_COMPLETE)) {
            this->uncork();
        }
        return false;
    }

    /* node:http socket.destroy() during this socket's parse: onData closes it after the current message. False when the caller must close it now. */
    bool closeAfterMessageIfParsing() {
        if (!HttpContext<SSL>::getSocketContextDataS((us_socket_t *) this)->isParsing((us_socket_t *) this)) {
            return false;
        }
        HttpResponseData<SSL> *httpResponseData = getHttpResponseData();
        if (httpResponseData->isConnectRequest) {
            return false;
        }
        httpResponseData->state |= HttpResponseData<SSL>::HTTP_NODE_CLOSE_AFTER_MESSAGE;
        return true;
    }

    /* Closes this connection if it is idle: no request is being received, and no response is in flight or queued. Returns whether it closed it. */
    bool closeIfIdle() {
        HttpResponseData<SSL> *data = getHttpResponseData();
        bool idle = data->isIdle;
        if (idle && HttpContext<SSL>::fromSocket((us_socket_t *) this)->isNodeHttp()) {
            /* node:http: a connection that still receives a request (a body, or the head of the next one) is not idle, also after its
             * response ended (Node.js: last_message_start_). In the request handler the parser has not entered a chunked body yet, so the armed body handler tells. */
            const bool messageOpen = ((HttpResponseData<SSL, true> *) data)->lastMessageStartMs != 0;
            idle = !(messageOpen && data->inStream != nullptr) && !data->hasIncompleteRequestBody() && !data->hasBufferedPartialRequestHeaders();
            if (idle && messageOpen && !Super::hasFullyDrained()) {
                /* The handler of this request still runs and its response has unsent bytes: close when they are out. */
                data->state |= HttpResponseData<SSL>::HTTP_CLOSE_WHEN_IDLE;
                idle = false;
            }
        }
        if (!idle) {
            return false;
        }
        /* A socket is idle from the moment its response completes. When
         * that happens inside onData's parse loop the response can still
         * sit in the cork buffer, and JS that runs before the loop ends
         * (a graceful stop() from a microtask) gets here. close() sends
         * it first. */
        Super::close();
        return true;
    }

    /* node:http: an idle tunnel is at read EOF and has nothing left to send. Like a libuv handle in that state, it does not hold
     * the event loop. The filter hears -3 when a tunnel becomes idle and +3 when it has bytes to send again. */
    void setNodeHttpTunnelIdle(bool idle) {
        HttpResponseData<SSL> *httpResponseData = getHttpResponseData();
        if (!httpResponseData->filteredAccept || httpResponseData->filteredIdleTunnel == idle) {
            return;
        }
        httpResponseData->filteredIdleTunnel = idle;
        for (auto &f : HttpContext<SSL>::getSocketContextDataS((us_socket_t *) this)->filterHandlers) {
            f(this, idle ? -3 : 3);
        }
    }

    /* Marks the response in flight as one that user JavaScript produces. See
     * HTTP_SEND_WHEN_COMPLETE. */
    void sendWhenComplete() {
        getHttpResponseData()->state |= HttpResponseData<SSL>::HTTP_SEND_WHEN_COMPLETE;
    }

    /* Ends the 101 of upgrade(): terminates the header section and marks the
     * response done. Not internalEnd(), because the socket leaves HTTP right
     * after: the connection close gate does not apply (Connection: close,
     * HTTP/1.0 and close-when-idle describe the HTTP connection, not the
     * WebSocket that takes over the socket), and the cork stays so the
     * handshake batches with the first frames written from open(). */
    void endUpgradeHandshake() {
        HttpResponseData<SSL> *httpResponseData = getHttpResponseData();
        writeMark();
        Super::write("\r\n", 2);
        httpResponseData->state |= HttpResponseData<SSL>::HTTP_END_CALLED;
        httpResponseData->markDone(this);
    }

    /* Returns true on success, indicating that it might be feasible to write more data.
     * Will start timeout if stream reaches totalSize or write failure. */
    bool internalEnd(std::string_view data, uint64_t totalSize, bool optional, bool allowContentLength = true, bool closeConnection = false) {
        /* Write status if not already done */
        writeStatus(HTTP_200_OK);

        /* If no total size given then assume this chunk is everything */
        if (!totalSize) {
            totalSize = data.length();
        }

        HttpResponseData<SSL> *httpResponseData = getHttpResponseData();

        /* A no-body status carries no Content-Length (RFC 9110 8.6) and no body
         * bytes (RFC 9112 6.3 terminates it at the blank line). end() already
         * short-circuits on HTTP_NO_BODY_STATUS; tryEnd() reaches here directly. */
        if (httpResponseData->state & HttpResponseData<SSL>::HTTP_NO_BODY_STATUS) {
            allowContentLength = false;
            data = {};
            totalSize = 0;
        }

        /* In some cases, such as when refusing huge data we want to close the connection when drained */
        if (closeConnection) {
            /* We can only write the header once */
            if (!(httpResponseData->state & (HttpResponseData<SSL>::HTTP_END_CALLED))) {

                /* HTTP 1.1 must send this back unless the client already sent it to us.
                * It is a connection close when either of the two parties say so but the
                * one party must tell the other one so.
                *
                * This check also serves to limit writing the header only once. */
                if ((httpResponseData->state & HttpResponseData<SSL>::HTTP_CONNECTION_CLOSE) == 0 && !(httpResponseData->state & (HttpResponseData<SSL>::HTTP_WRITE_CALLED))) {
                    writeHeader("Connection", "close");
                }

                httpResponseData->state |= HttpResponseData<SSL>::HTTP_CONNECTION_CLOSE;
            }
        }

        /* if write was called and there was previously no Content-Length header set.
         * node:http compat: pending response trailers (addTrailers) also force chunked
         * framing, since trailer fields can only be sent on a chunked body. */
        if ((httpResponseData->state & (HttpResponseData<SSL>::HTTP_WRITE_CALLED | HttpResponseData<SSL>::HTTP_NODE_HAS_RESPONSE_TRAILERS))
            && !(httpResponseData->state & (HttpResponseData<SSL>::HTTP_WROTE_CONTENT_LENGTH_HEADER | HttpResponseData<SSL>::HTTP_ANCIENT_REQUEST | HttpResponseData<SSL>::HTTP_CLOSE_DELIMITED | HttpResponseData<SSL>::HTTP_NO_BODY_STATUS))) {

            /* We do not have tryWrite-like functionalities, so ignore optional in this path */

            /* Trailers-only end with no body chunk: write() below would early-return on
             * empty data, so terminate the header section and enter chunked mode here. */
            if (!(httpResponseData->state & HttpResponseData<SSL>::HTTP_WRITE_CALLED) && data.empty()) [[unlikely]] {
                writeMark();
                if (!(httpResponseData->state & HttpResponseData<SSL>::HTTP_WROTE_TRANSFER_ENCODING_HEADER)) {
                    writeHeader("Transfer-Encoding", "chunked");
                }
                Super::write("\r\n", 2);
                httpResponseData->state |= HttpResponseData<SSL>::HTTP_WRITE_CALLED;
            }

            /* Write the chunked data if there is any (this will not send zero chunks) */
            const bool terminated = !data.empty() && !(httpResponseData->state & HttpResponseData<SSL>::HTTP_NODE_HAS_RESPONSE_TRAILERS);
            this->write(data, nullptr, terminated);


            /* Terminating 0 chunk; node:http response trailers (RFC 9112 7.1.2) sit
             * between it and the final CRLF. */
            if (httpResponseData->state & HttpResponseData<SSL>::HTTP_NODE_HAS_RESPONSE_TRAILERS) [[unlikely]] {
                /* Only a node:http compat connection can set the flag, so the
                 * downcast to the bigger IsNodeHttp=true block is safe.
                 * (HttpResponse<SSL> is not templated on IsNodeHttp - it is the
                 * type the C API casts to from a runtime `int ssl` - so this
                 * one shared read stays a runtime bit test.) */
                auto *nodeHttpResponseData = (HttpResponseData<SSL, true> *) httpResponseData;
                /* Emit the terminating chunk, the trailer section and the final CRLF as
                 * ONE write: when the response is not corked (cork slots are contended
                 * under high connection counts), separate writes become separate tiny
                 * TCP segments on the tail of every response. The buffer is about to be
                 * cleared anyway, so build the frame in place. */
                std::string &trailers = nodeHttpResponseData->nodeHttpResponseTrailers;
                trailers.insert(0, "0\r\n", 3);
                trailers.append("\r\n", 2);
                Super::write(trailers.data(), (int) trailers.length());
                trailers.clear();
                httpResponseData->state &= ~HttpResponseData<SSL>::HTTP_NODE_HAS_RESPONSE_TRAILERS;
            } else if (!terminated) {
                Super::write("0\r\n\r\n", 5);
            }
            httpResponseData->markDone(this);

            /* We need to check if we should close this socket here now */
            if (uncorkCompletedResponse()) {
                if (closeIfDoneAndMarked(httpResponseData)) {
                    return true;
                }
            }

            /* tryEnd can never fail when in chunked mode, since we do not have tryWrite (yet), only write */
            this->resetTimeout();
            return true;
        } else {
            /* Write content-length on first call */
            if (!(httpResponseData->state & (HttpResponseData<SSL>::HTTP_END_CALLED))) {
                /* Once write() has sent raw body bytes (close-delimited or
                 * HTTP/1.0 streaming), the header section is already
                 * terminated: writing a Content-Length here would inject
                 * header bytes into the body. The connection close delimits
                 * the message instead. */
                if (!(httpResponseData->state & (HttpResponseData<SSL>::HTTP_WRITE_CALLED))) {
                    /* Write mark, this propagates to WebSockets too */
                    writeMark();

                    /* WebSocket upgrades does not allow content-length */
                    if (allowContentLength) {
                        /* Even zero is a valid content-length */
                        Super::write("Content-Length: ", 16);
                        writeUnsigned64(totalSize);
                        Super::write("\r\n\r\n", 4);
                        httpResponseData->state |= HttpResponseData<SSL>::HTTP_WROTE_CONTENT_LENGTH_HEADER;
                    } else {
                        Super::write("\r\n", 2);
                    }
                }

                /* Mark end called */
                httpResponseData->state |= HttpResponseData<SSL>::HTTP_END_CALLED;
            }

            /* Even if we supply no new data to write, its failed boolean is useful to know
             * if it failed to drain any prior failed header writes */

            /* Write as much as possible without causing backpressure */
            size_t written = 0;
            bool failed = false;
            while (written < data.length() && !failed) {
                /* uSockets only deals with int sizes, so pass chunks of max signed int size */
                auto writtenFailed = Super::write(data.data() + written, (int) std::min<size_t>(data.length() - written, INT_MAX), optional);

                written += (size_t) writtenFailed.first;
                failed = writtenFailed.second;
            }

            httpResponseData->offset += written;

            /* Success is when we wrote the entire thing without any failures */
            bool success = written == data.length() && !failed;
            /* Reset the timeout on each tryEnd */
            this->resetTimeout();

            /* Remove onAborted function if we reach the end */
            if (httpResponseData->offset == totalSize) {
                httpResponseData->markDone(this);

                /* We need to check if we should close this socket here now */
                if (uncorkCompletedResponse()) {
                    closeIfDoneAndMarked(httpResponseData);
                }
            }

            return success;
        }
    }

    /* Manually upgrade to WebSocket. Typically called in upgrade handler. Immediately calls open handler.
     * NOTE: Will invalidate 'this' as socket might change location in memory. Throw away after use. */
    template <typename UserData>
    us_socket_t *upgrade(UserData&& userData, std::string_view secWebSocketKey, std::string_view secWebSocketProtocol,
            std::string_view secWebSocketExtensions,
            WebSocketContext<SSL, true, UserData> *webSocketContext) {

        /* Extract needed parameters from WebSocketContextData */
        WebSocketContextData<SSL, UserData> *webSocketContextData = webSocketContext->getExt();

        /* Note: OpenSSL can be used here to speed this up somewhat */
        char secWebSocketAccept[29] = {};
        char secWebSocketKeyBuffer[24] = {};
        secWebSocketKey.copy(secWebSocketKeyBuffer, 24);
        WebSocketHandshake::generate(secWebSocketKeyBuffer, secWebSocketAccept);

        writeStatus("101 Switching Protocols")
            ->writeHeader("Upgrade", "websocket")
            ->writeHeader("Connection", "Upgrade")
            ->writeHeader("Sec-WebSocket-Accept", secWebSocketAccept);

        /* Select first subprotocol if present */
        if (secWebSocketProtocol.length()) {
            writeHeader("Sec-WebSocket-Protocol", secWebSocketProtocol.substr(0, secWebSocketProtocol.find(',')));
        }

        /* Negotiate compression */
        bool perMessageDeflate = false;
        CompressOptions compressOptions = CompressOptions::DISABLED;
        if (secWebSocketExtensions.length() && webSocketContextData->compression != DISABLED) {

            /* Make sure to map SHARED_DECOMPRESSOR to windowBits = 0, not 1  */
            int wantedInflationWindow = 0;
            if ((webSocketContextData->compression & CompressOptions::_DECOMPRESSOR_MASK) != CompressOptions::SHARED_DECOMPRESSOR) {
                wantedInflationWindow = (webSocketContextData->compression & CompressOptions::_DECOMPRESSOR_MASK) >> 8;
            }

            /* Map from selected compressor (this automatically maps SHARED_COMPRESSOR to windowBits 0, not 1) */
            int wantedCompressionWindow = (webSocketContextData->compression & CompressOptions::_COMPRESSOR_MASK) >> 4;

            auto [negCompression, negCompressionWindow, negInflationWindow, negResponse] =
            negotiateCompression(true, wantedCompressionWindow, wantedInflationWindow,
                                        secWebSocketExtensions);

            if (negCompression) {
                perMessageDeflate = true;

                /* Map from negotiated windowBits to compressor and decompressor */
                if (negCompressionWindow == 0) {
                    compressOptions = CompressOptions::SHARED_COMPRESSOR;
                } else {
                    compressOptions = (CompressOptions) ((uint32_t) (negCompressionWindow << 4)
                                                        | (uint32_t) (negCompressionWindow - 7));

                    /* If we are dedicated and have the 3kb then correct any 4kb to 3kb,
                     * (they both share the windowBits = 9) */
                    if (webSocketContextData->compression & DEDICATED_COMPRESSOR_3KB) {
                        compressOptions = DEDICATED_COMPRESSOR_3KB;
                    }
                }

                /* Here we modify the above compression with negotiated decompressor */
                if (negInflationWindow == 0) {
                    compressOptions = CompressOptions(compressOptions | CompressOptions::SHARED_DECOMPRESSOR);
                } else {
                    compressOptions = CompressOptions(compressOptions | (negInflationWindow << 8));
                }

                writeHeader("Sec-WebSocket-Extensions", negResponse);
            }
        }

        endUpgradeHandshake();

        /* Grab the httpContext from res */
        HttpContext<SSL> *httpContext = HttpContext<SSL>::fromSocket((struct us_socket_t *) this);

        /* Move any backpressure out of HttpResponse */
        auto* responseData = getHttpResponseData();
        BackPressure backpressure(std::move(((AsyncSocketData<SSL> *) responseData)->buffer));

        auto* socketData = responseData->socketData;
        HttpContextData<SSL> *httpContextData = httpContext->getSocketContextData();

        /* The socket is leaving this context; its onClose (and so filter -1)
         * will never fire once adopted. Fire it now so a filter that counts
         * live HTTP connections stays balanced across every upgrade path.
         * Read filteredOpen before responseData is destructed below. */
        if (((AsyncSocketData<SSL> *) responseData)->filteredOpen) {
            for (auto &f : httpContextData->filterHandlers) {
                f((HttpResponse<SSL> *) this, -1);
            }
        }
        if (((AsyncSocketData<SSL> *) responseData)->filteredAccept) {
            for (auto &f : httpContextData->filterHandlers) {
                f((HttpResponse<SSL> *) this, ((AsyncSocketData<SSL> *) responseData)->filteredIdleTunnel ? -4 : -2);
            }
        }

        /* Destroy HttpResponseData (the IsNodeHttp=true type on node:http
         * compat contexts; upgrade() is not on a templated handler path, so it
         * selects at runtime like socketExtSize()). */
        if (httpContext->isNodeHttp()) {
            ((HttpResponseData<SSL, true> *) responseData)->~HttpResponseData();
        } else {
            responseData->~HttpResponseData();
        }

        /* Before we adopt and potentially change socket, check which cork slot
         * we occupy so we can transfer it to the new WebSocket. */
        LoopData *loopData = Super::getLoopData();
        int corkedSlot = loopData->findCorkSlot(this);

        /* Read before the adoption below, which can move this socket. An upgrade of another connection must leave the parsed socket alone. */
        const bool upgradingParsedSocket = httpContextData->isParsing((us_socket_t *) this);

        /* Adopting a socket invalidates it, do not rely on it directly to carry any data */
        /* The old ext size is only used as an upper bound to keep the block in
         * place (and as the copy length when it cannot be). The base size is
         * always correct here: a node:http compat socket's block is bigger, so
         * under-stating it is an in-bounds under-copy of an already-destructed
         * ext, while over-stating it for a Bun.serve socket would read out of
         * bounds. */
        us_socket_t *usSocket = us_socket_adopt((us_socket_t *) this, webSocketContext->getSocketGroup(),
            WebSocketContext<SSL, true, UserData>::socketKind(),
            sizeof(HttpResponseData<SSL>), sizeof(WebSocketData) + sizeof(UserData));
        WebSocket<SSL, true, UserData> *webSocket = (WebSocket<SSL, true, UserData> *) usSocket;

        /* For whatever reason we were corked, update cork to the new socket */
        if (corkedSlot != LoopData::INVALID_CORK_SLOT) {
            loopData->transferCorkSlot(corkedSlot, webSocket, SSL);
        }

        /* Initialize websocket with any moved backpressure intact */
        webSocket->init(perMessageDeflate, compressOptions, std::move(backpressure), socketData, httpContextData->onSocketClosed);
        if (httpContextData->onSocketUpgraded) {
            httpContextData->onSocketUpgraded(socketData, SSL, usSocket);
        }

        /* We should only mark this if inside the parser; if upgrading "async" we cannot set this */
        if (upgradingParsedSocket) {
            /* We need to tell the Http parser that we changed socket */
            httpContextData->upgradedWebSocket = webSocket;
        }

        /* Arm maxLifetime timeout */
        us_socket_long_timeout((us_socket_t *) webSocket, webSocketContextData->maxLifetime);

        /* Arm idleTimeout */
        us_socket_timeout((us_socket_t *) webSocket, webSocketContextData->idleTimeoutComponents.first);

        /* Move construct the UserData right before calling open handler */
        new (webSocket->getUserData()) UserData(std::forward<UserData>(userData));

        /* Emit open event and start the timeout */
        if (webSocketContextData->openHandler) {
            webSocketContextData->openHandler(webSocket);
        }

        return usSocket;
    }

    /* Immediately terminate this Http response */
    using Super::close;

    /* See AsyncSocket */
    using Super::getRemoteAddress;
    using Super::getRemoteAddressAsText;
    using Super::getNativeHandle;

    /* Throttle reads and writes */
    HttpResponse *pause() {
        Super::pause();
        Super::timeout(0);
        return this;
    }

    HttpResponse *resume() {
        Super::resume();
        this->resetTimeout();
        return this;
    }

    /* Note: Headers are not checked in regards to timeout.
     * We only check when you actively push data or end the request */

    /* Write 100 Continue, can be done any amount of times */
    HttpResponse *writeContinue() {
        Super::write("HTTP/1.1 100 Continue\r\n\r\n", 25);
        return this;
    }

    /* Write a caller-built 1xx informational response line + headers. Shares
     * the AsyncSocket write path (and buffer) writeStatus/end use, so a
     * pipelined replay stays ordered ahead of the final response bytes. */
    HttpResponse *writeRawInformational(std::string_view data) {
        Super::write(data.data(), (int) data.length());
        return this;
    }

    /* Write the HTTP status */
    HttpResponse *writeStatus(std::string_view status) {
        HttpResponseData<SSL> *httpResponseData = getHttpResponseData();

        /* Do not allow writing more than one status */
        if (httpResponseData->state & HttpResponseData<SSL>::HTTP_STATUS_CALLED) {
            return this;
        }

        /* RFC 9110 8.6: a 1xx/204 MUST NOT carry Content-Length and has no
         * body; record that at the one point every response passes through.
         * 304 MAY carry one, so node:http sets the bit for it itself. */
        if (status.length() >= 3 && (status.length() == 3 || status[3] == ' ')
            && (status[0] == '1' || (status[0] == '2' && status[1] == '0' && status[2] == '4'))) {
            httpResponseData->state |= HttpResponseData<SSL>::HTTP_NO_BODY_STATUS;
        }

        /* Update status */
        httpResponseData->state |= HttpResponseData<SSL>::HTTP_STATUS_CALLED;

        Super::write("HTTP/1.1 ", 9);
        Super::write(status.data(), (int) status.length());
        Super::write("\r\n", 2);
        return this;
    }

    /* Write an HTTP header with string value */
    HttpResponse *writeHeader(std::string_view key, std::string_view value) {
        writeStatus(HTTP_200_OK);

        Super::write(key.data(), (int) key.length());
        Super::write(": ", 2);
        Super::write(value.data(), (int) value.length());
        Super::write("\r\n", 2);
        return this;
    }

    /* Write an HTTP header with unsigned int value */
    HttpResponse *writeHeader(std::string_view key, uint64_t value) {
        writeStatus(HTTP_200_OK);

        /* Every integer Content-Length write funnels through this overload;
         * a 1xx / 204 response must not carry one (RFC 9110 8.6). */
        if ((getHttpResponseData()->state & HttpResponseData<SSL>::HTTP_NO_BODY_STATUS) && key.length() == 14 && !strncasecmp(key.data(), "content-length", 14)) {
            return this;
        }

        Super::write(key.data(), (int) key.length());
        Super::write(": ", 2);
        writeUnsigned64(value);
        Super::write("\r\n", 2);
        return this;
    }

    /* End the response with an optional data chunk. Always starts a timeout. */
    void end(std::string_view data = {}, bool closeConnection = false) {
        HttpResponseData<SSL> *httpResponseData = getHttpResponseData();

        /* 204/304 responses carry no body framing at all: no Content-Length,
         * no chunked framing and no terminating chunk, even when an explicit
         * Transfer-Encoding header was written (RFC 9110 6.4.1). */
        if (httpResponseData->state & HttpResponseData<SSL>::HTTP_NO_BODY_STATUS) {
            internalEnd({nullptr, 0}, 0, false, false, closeConnection);
            return;
        }

        /* Close-delimited responses (the user removed the framing headers):
         * raw body bytes after the headers, no Content-Length, no chunked
         * framing, and the connection closes to delimit the message. The
         * CONNECTION_CLOSE state is set directly so internalEnd() closes the
         * socket without adding a Connection: close header the user removed. */
        if (httpResponseData->state & HttpResponseData<SSL>::HTTP_CLOSE_DELIMITED) {
            httpResponseData->state |= HttpResponseData<SSL>::HTTP_CONNECTION_CLOSE;
            internalEnd(data, data.length(), false, false, false);
            return;
        }

        /* When the user wrote an explicit Transfer-Encoding header but never started
         * streaming writes (a one-shot end), the body must still be chunk-framed.
         * Terminate the headers and enter chunked mode so internalEnd() takes the
         * chunked path instead of writing the raw body after the headers. */
        if ((httpResponseData->state & HttpResponseData<SSL>::HTTP_WROTE_TRANSFER_ENCODING_HEADER) &&
            !(httpResponseData->state & (HttpResponseData<SSL>::HTTP_WRITE_CALLED | HttpResponseData<SSL>::HTTP_WROTE_CONTENT_LENGTH_HEADER
                | HttpResponseData<SSL>::HTTP_ANCIENT_REQUEST | HttpResponseData<SSL>::HTTP_NO_BODY_STATUS))) {
            writeStatus(HTTP_200_OK);
            writeMark();
            Super::write("\r\n", 2);
            httpResponseData->state |= HttpResponseData<SSL>::HTTP_WRITE_CALLED;
        }

        /* Do not auto-write a Content-Length header when the user already wrote
         * a Content-Length or an explicit Transfer-Encoding header (a message
         * must not carry both, see RFC 9112 §6.2). */
        internalEnd(data, data.length(), false, !(httpResponseData->state & (HttpResponseData<SSL>::HTTP_WROTE_CONTENT_LENGTH_HEADER | HttpResponseData<SSL>::HTTP_WROTE_TRANSFER_ENCODING_HEADER)), closeConnection);
    }

    /* Try and end the response. Returns [true, true] on success.
     * Starts a timeout in some cases. Returns [ok, hasResponded] */
    std::pair<bool, bool> tryEnd(std::string_view data, uintmax_t totalSize = 0, bool closeConnection = false) {
        bool ok = internalEnd(data, totalSize, true, true, closeConnection);
        /* internalEnd's close gate may have closed the socket (destructing the
         * ext hasResponded() reads); that only happens once the response has
         * completed, so report responded without touching it. */
        if (us_socket_is_closed((us_socket_t *) this)) {
            return {ok, true};
        }
        return {ok, hasResponded()};
    }

    /* Write the end of chunked encoded stream */
    bool sendTerminatingChunk(bool closeConnection = false) {
        writeStatus(HTTP_200_OK);
        HttpResponseData<SSL> *httpResponseData = getHttpResponseData();
        if (!(httpResponseData->state & (HttpResponseData<SSL>::HTTP_WRITE_CALLED | HttpResponseData<SSL>::HTTP_WROTE_CONTENT_LENGTH_HEADER))) {
            /* Write mark on first call to write */
            writeMark();

            if (!(httpResponseData->state & HttpResponseData<SSL>::HTTP_WROTE_TRANSFER_ENCODING_HEADER)) {
                writeHeader("Transfer-Encoding", "chunked");
            }
            Super::write("\r\n", 2);
            httpResponseData->state |= HttpResponseData<SSL>::HTTP_WRITE_CALLED;
        }

        /* This will be sent always when state is HTTP_WRITE_CALLED inside internalEnd, so no need to write the terminating 0 chunk here */
        /* Super::write("\r\n0\r\n\r\n", 7); */

        /* As in end(): the close is what terminates a close-delimited body. */
        if (httpResponseData->state & HttpResponseData<SSL>::HTTP_CLOSE_DELIMITED) {
            httpResponseData->state |= HttpResponseData<SSL>::HTTP_CONNECTION_CLOSE;
        }

        return internalEnd({nullptr, 0}, 0, false, false, closeConnection);
    }

    void flushHeaders(bool flushImmediately = false) {

        writeStatus(HTTP_200_OK);

        HttpResponseData<SSL> *httpResponseData = getHttpResponseData();

        /* Close-delimited responses must not re-add the Transfer-Encoding
         * header the user removed; their body is raw, so take the else path. */
        if (!(httpResponseData->state & (HttpResponseData<SSL>::HTTP_WROTE_CONTENT_LENGTH_HEADER | HttpResponseData<SSL>::HTTP_ANCIENT_REQUEST | HttpResponseData<SSL>::HTTP_CLOSE_DELIMITED | HttpResponseData<SSL>::HTTP_NO_BODY_STATUS))) {
            if (!(httpResponseData->state & HttpResponseData<SSL>::HTTP_WRITE_CALLED)) {
                /* Write mark on first call to write */
                writeMark();

                if (!(httpResponseData->state & HttpResponseData<SSL>::HTTP_WROTE_TRANSFER_ENCODING_HEADER)) {
                    writeHeader("Transfer-Encoding", "chunked");
                }
                Super::write("\r\n", 2);
                httpResponseData->state |= HttpResponseData<SSL>::HTTP_WRITE_CALLED;
            }

         } else if (!(httpResponseData->state & HttpResponseData<SSL>::HTTP_WRITE_CALLED)) {
            writeMark();
            Super::write("\r\n", 2);
            httpResponseData->state |= HttpResponseData<SSL>::HTTP_WRITE_CALLED;
        }
        if (flushImmediately) {
            /* Uncork the socket to send data to the client immediately */
            this->uncork();
        }
    }
    /* Write parts of the response in chunking fashion. Starts timeout if failed. */
    /* isLast: the terminating chunk of a chunked body goes out with this one. */
    bool write(std::string_view data, size_t *writtenPtr = nullptr, bool isLast = false) {
        writeStatus(HTTP_200_OK);

        /* Do not allow sending 0 chunks, they mark end of response */
        if (data.empty()) {
            if (writtenPtr) {
                *writtenPtr = 0;
            }
            /* If you called us, then according to you it was fine to call us so it's fine to still call us */
            return true;
        }

        size_t length = data.length();

        // Special handling for extremely large data (greater than UINT_MAX bytes)
        // most clients expect a max of UINT_MAX, so we need to split the write into multiple writes
        if (length > UINT_MAX) {
            bool has_failed = false;
            size_t total_written = 0;
            // Process full-sized chunks until remaining data is less than UINT_MAX
            while (length > UINT_MAX) {
                size_t written = 0;
                // Write a UINT_MAX-sized chunk and check for failure
                // even after failure we continue writing because the data will be buffered
                if(!this->write(data.substr(0, UINT_MAX), &written)) {
                    has_failed = true;
                }
                total_written += written;
                length -= UINT_MAX;
                data = data.substr(UINT_MAX);
            }
            // Handle the final chunk (less than UINT_MAX bytes)
            if (length > 0) {
                size_t written = 0;
                if(!this->write(data, &written, isLast)) {
                    has_failed = true;
                }
                total_written += written;
            }
            if (writtenPtr) {
                *writtenPtr = total_written;
            }
            return !has_failed;
        }


        HttpResponseData<SSL> *httpResponseData = getHttpResponseData();
        char chunkHeadBuffer[CHUNK_HEAD_MAX];
        size_t chunkHeadLength = 0;
        std::string_view chunkTail;

        /* Close-delimited responses (the user removed the framing headers)
         * write raw bytes with no chunk framing, like the else path. */
        if (!(httpResponseData->state & (HttpResponseData<SSL>::HTTP_WROTE_CONTENT_LENGTH_HEADER | HttpResponseData<SSL>::HTTP_ANCIENT_REQUEST | HttpResponseData<SSL>::HTTP_CLOSE_DELIMITED))) {
            if (!(httpResponseData->state & HttpResponseData<SSL>::HTTP_WRITE_CALLED)) {
                /* Write mark on first call to write */
                writeMark();

                if (!(httpResponseData->state & HttpResponseData<SSL>::HTTP_WROTE_TRANSFER_ENCODING_HEADER)) {
                    writeHeader("Transfer-Encoding", "chunked");
                }
                Super::write("\r\n", 2);
                httpResponseData->state |= HttpResponseData<SSL>::HTTP_WRITE_CALLED;
            }

            chunkHeadLength = chunkHead(chunkHeadBuffer, (unsigned int) data.length());
            chunkTail = isLast ? "\r\n0\r\n\r\n" : "\r\n";
        } else if (!(httpResponseData->state & HttpResponseData<SSL>::HTTP_WRITE_CALLED)) {
            writeMark();
            Super::write("\r\n", 2);
            httpResponseData->state |= HttpResponseData<SSL>::HTTP_WRITE_CALLED;
        }
        size_t total_written = 0;
        bool has_failed = false;

        if (length <= INT_MAX) {
            auto [written, failed] = Super::writeFramed({chunkHeadBuffer, chunkHeadLength}, data.data(), (int) length, chunkTail);
            this->resetTimeout();
            if (writtenPtr) {
                *writtenPtr = (size_t) written;
            }
            return !failed;
        }
        Super::write(chunkHeadBuffer, (int) chunkHeadLength);

        // Handle data larger than INT_MAX by writing it in chunks of INT_MAX bytes
        while (length > INT_MAX) {
            // Write the maximum allowed chunk size (INT_MAX)
            auto [written, failed] = Super::write(data.data(), INT_MAX);
            // If the write failed, set the has_failed flag we continue writting because the data will be buffered
            has_failed = has_failed || failed;
            total_written += written;
            length -= INT_MAX;
            data = data.substr(INT_MAX);
        }
        // Handle the remaining data (less than INT_MAX bytes)
        if (length > 0) {
            // Write the final chunk with exact remaining length
            auto [written, failed] = Super::write(data.data(), (int) length);
            has_failed = has_failed || failed;
            total_written += written;
        }

        /* Empty for a close-delimited body, which is raw. */
        Super::write(chunkTail.data(), (int) chunkTail.length());

        /* Reset timeout on each sended chunk */
        this->resetTimeout();

        if (writtenPtr) {
            *writtenPtr = total_written;
        }
        /* If we did not fail the write, accept more */
        return !has_failed;
    }

    /* Like write(), but the body payload is written with optionally=true so the
     * unwritten tail is NOT copied into the backpressure buffer. The caller keeps
     * the bytes alive and retries the remainder on onWritable. Framing (chunk-size
     * line, trailing CRLF) is still written non-optionally.
     * isFirst=false skips framing and is used for continuation writes.
     * Returns the number of body bytes accepted. */
    size_t tryWriteBody(std::string_view data, bool isFirst) {
        HttpResponseData<SSL> *httpResponseData = getHttpResponseData();
        bool chunked = !(httpResponseData->state & (HttpResponseData<SSL>::HTTP_WROTE_CONTENT_LENGTH_HEADER | HttpResponseData<SSL>::HTTP_ANCIENT_REQUEST | HttpResponseData<SSL>::HTTP_CLOSE_DELIMITED));
        char chunkHeadBuffer[CHUNK_HEAD_MAX];
        size_t chunkHeadLength = 0;

        if (isFirst) {
            writeStatus(HTTP_200_OK);
            if (chunked) {
                if (!(httpResponseData->state & HttpResponseData<SSL>::HTTP_WRITE_CALLED)) {
                    writeMark();
                    if (!(httpResponseData->state & HttpResponseData<SSL>::HTTP_WROTE_TRANSFER_ENCODING_HEADER)) {
                        writeHeader("Transfer-Encoding", "chunked");
                    }
                    Super::write("\r\n", 2);
                    httpResponseData->state |= HttpResponseData<SSL>::HTTP_WRITE_CALLED;
                }
                chunkHeadLength = chunkHead(chunkHeadBuffer, (unsigned int) data.length());
            } else if (!(httpResponseData->state & HttpResponseData<SSL>::HTTP_WRITE_CALLED)) {
                writeMark();
                Super::write("\r\n", 2);
                httpResponseData->state |= HttpResponseData<SSL>::HTTP_WRITE_CALLED;
            }
        }

        size_t consumed = 0;
        size_t length = data.length();
        if (length <= INT_MAX) {
            consumed = (size_t) Super::writeFramed({chunkHeadBuffer, chunkHeadLength}, data.data(), (int) length, chunked ? "\r\n" : "", true).first;
            this->resetTimeout();
            return consumed;
        }
        Super::write(chunkHeadBuffer, (int) chunkHeadLength);
        while (consumed < length) {
            int chunk = (int) std::min(length - consumed, (size_t) INT_MAX);
            auto [written, failed] = Super::write(data.data() + consumed, chunk, true);
            consumed += (size_t) written;
            if (written < chunk || failed) break;
        }

        if (consumed == length && chunked) {
            Super::write("\r\n", 2);
        }

        this->resetTimeout();
        return consumed;
    }

    /* Copy the remaining body tail into the backpressure buffer (non-optional),
     * then the trailing chunk CRLF. Used when a new write arrives while a
     * tryWriteBody() tail is still held externally. */
    void spillBodyTail(std::string_view data) {
        HttpResponseData<SSL> *httpResponseData = getHttpResponseData();
        bool chunked = !(httpResponseData->state & (HttpResponseData<SSL>::HTTP_WROTE_CONTENT_LENGTH_HEADER | HttpResponseData<SSL>::HTTP_ANCIENT_REQUEST | HttpResponseData<SSL>::HTTP_CLOSE_DELIMITED));

        size_t length = data.length();
        size_t done = 0;
        while (done < length) {
            int chunk = (int) std::min(length - done, (size_t) INT_MAX);
            Super::write(data.data() + done, chunk);
            done += (size_t) chunk;
        }
        if (chunked) {
            Super::write("\r\n", 2);
        }
    }

    /* Get the current byte write offset for this Http response */
    uint64_t getWriteOffset() {
        HttpResponseData<SSL> *httpResponseData = getHttpResponseData();

        return httpResponseData->offset;
    }

    /* Checking if we have fully responded and are ready for another request */
    bool hasResponded() {
        HttpResponseData<SSL> *httpResponseData = getHttpResponseData();

        return !(httpResponseData->state & HttpResponseData<SSL>::HTTP_RESPONSE_PENDING);
    }

    /* node:http: the response is complete and its request body is still being parsed out of this read. A shutdown now would drop that body; the after-parse gate closes instead. */
    bool isDeliveringBodyAfterResponse() {
        HttpResponseData<SSL> *httpResponseData = getHttpResponseData();

        return hasResponded()
            && !httpResponseData->isConnectRequest
            && httpResponseData->inStream != nullptr
            && HttpContext<SSL>::getSocketContextDataS((us_socket_t *) this)->isParsing((us_socket_t *) this);
    }

     /* Corks the response if possible. Leaves already corked socket be. */
    HttpResponse *cork(MoveOnlyFunction<void()> &&handler) {
        if (!Super::isCorked()) {
            LoopData *loopData = Super::getLoopData();
            Super::cork();
            handler();

            /* If we're no longer in a cork slot, either: (a) the handler wrote
             * large data that triggered an internal uncork, (b) our empty slot
             * was stolen by another request during an await, or (c) we were
             * upgraded to a WebSocket (upgrade path transferred the slot). In
             * all cases our data (if any) was already flushed; nothing to do.
             * The upgrade case is handled by HttpContext's uncork or the drain
             * loop. */
            if (loopData->findCorkSlot(this) == LoopData::INVALID_CORK_SLOT) {
                return this;
            }

            /* Timeout on uncork failure, since most writes will succeed while corked */
            auto [written, failed] = Super::uncork();

            if (written > 0 || failed) {
                /* For now we only have one single timeout so let's use it */
                /* This behavior should equal the behavior in HttpContext when uncorking fails */
                this->resetTimeout();
            }

            /* If we have no backbuffer and we are connection close and we responded fully then close */
            HttpResponseData<SSL> *httpResponseData = getHttpResponseData();
            if (httpResponseData->shouldCloseConnection()) {
                if ((httpResponseData->state & HttpResponseData<SSL>::HTTP_RESPONSE_PENDING) == 0) {
                    if (((AsyncSocket<SSL> *) this)->hasFullyDrained()) {
                        ((AsyncSocket<SSL> *) this)->shutdown();
                        /* We need to force close after sending FIN since we want to hinder
                        * clients from keeping to send their huge data */
                        ((AsyncSocket<SSL> *) this)->close();
                    }
                }
            }
        } else {
            /* We are already corked, or can't cork so let's just call the handler */
            handler();
        }

        return this;
    }

    /* Attach handler for writable HTTP response */
    HttpResponse *onWritable(void* userData, HttpResponseData<SSL>::OnWritableCallback handler) {
        HttpResponseData<SSL> *httpResponseData = getHttpResponseData();

        httpResponseData->writableUserData = userData;
        httpResponseData->onWritable = handler;
        return this;
    }

    /* Remove handler for writable HTTP response */
    HttpResponse *clearOnWritable() {
        HttpResponseData<SSL> *httpResponseData = getHttpResponseData();

        httpResponseData->onWritable = nullptr;
        httpResponseData->writableUserData = nullptr;
        return this;
    }

    /* Attach handler for aborted HTTP request */
    HttpResponse *onAborted(void* userData,  HttpResponseData<SSL>::OnAbortedCallback handler) {
        HttpResponseData<SSL> *httpResponseData = getHttpResponseData();

        httpResponseData->userData = userData;
        httpResponseData->onAborted = handler;
        return this;
    }

    HttpResponse *onTimeout(void* userData,  HttpResponseData<SSL>::OnTimeoutCallback handler) {
        HttpResponseData<SSL> *httpResponseData = getHttpResponseData();

        httpResponseData->userData = userData;
        httpResponseData->onTimeout = handler;
        return this;
    }

    HttpResponse* clearOnWritableAndAborted() {
        HttpResponseData<SSL> *httpResponseData = getHttpResponseData();

        httpResponseData->onWritable = nullptr;
        httpResponseData->writableUserData = nullptr;
        httpResponseData->onAborted = nullptr;
        httpResponseData->onTimeout = nullptr;

        return this;
    }

    HttpResponse* clearOnAborted() {
        HttpResponseData<SSL> *httpResponseData = getHttpResponseData();

        httpResponseData->onAborted = nullptr;
        return this;
    }

    HttpResponse* clearOnTimeout() {
        HttpResponseData<SSL> *httpResponseData = getHttpResponseData();

        httpResponseData->onTimeout = nullptr;
        return this;
    }

    /* Remove the handlers that were attached with this user data. A handler that another owner attached since stays. */
    void clearHandlersOf(void* userData) {
        HttpResponseData<SSL> *httpResponseData = getHttpResponseData();

        if (httpResponseData->writableUserData == userData) {
            httpResponseData->onWritable = nullptr;
            httpResponseData->writableUserData = nullptr;
        }
        if (httpResponseData->userData == userData) {
            httpResponseData->onAborted = nullptr;
            httpResponseData->onTimeout = nullptr;
            httpResponseData->inStream = nullptr;
            httpResponseData->userData = nullptr;
        }
    }
    /* Attach a read handler for data sent. Will be called with FIN set true if last segment. */
    void onData(void* userData, HttpResponseData<SSL>::OnDataCallback handler) {
        HttpResponseData<SSL> *data = getHttpResponseData();
        data->userData = userData;
        data->inStream = handler;

        /* Always reset this counter here */
        data->received_bytes_per_timeout = 0;
    }

    void* getSocketData() {
        HttpResponseData<SSL> *httpResponseData = getHttpResponseData();

        return httpResponseData->socketData;
    }
    bool isConnectRequest() {
        HttpResponseData<SSL> *httpResponseData = getHttpResponseData();
        return httpResponseData->isConnectRequest;
    }

    void setWriteOffset(uint64_t offset) {
        HttpResponseData<SSL> *httpResponseData = getHttpResponseData();

        httpResponseData->offset = offset;
    }

};

}

#endif // UWS_HTTPRESPONSE_H