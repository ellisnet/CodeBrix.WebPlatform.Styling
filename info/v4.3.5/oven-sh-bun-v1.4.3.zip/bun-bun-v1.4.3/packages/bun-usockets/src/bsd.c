/*
 * Authored by Alex Hultman, 2018-2021.
 * Intellectual property of third-party.

 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at

 *     http://www.apache.org/licenses/LICENSE-2.0

 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/* Todo: this file should lie in networking/bsd.c */

#define __APPLE_USE_RFC_3542

#include "libusockets.h"
#include "internal/internal.h"
#include "internal/fault_inject.h"

#include <limits.h>
#include <stdio.h>
#include <stdlib.h>

#if BUN_DEBUG
// Debug network traffic logging
static FILE *debug_recv_file = NULL;
static FILE *debug_send_file = NULL;
static int debug_logging_initialized = 0;

static void init_debug_logging() {
    if (debug_logging_initialized) return;
    debug_logging_initialized = 1;

    const char *recv_path = getenv("BUN_RECV");
    const char *send_path = getenv("BUN_SEND");
    if (recv_path) if (!debug_recv_file) debug_recv_file = fopen(recv_path, "w");
    if (send_path) if (!debug_send_file) debug_send_file = fopen(send_path, "w");
}
#endif

#ifndef _WIN32
// Necessary for the stdint include
#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#else /* _WIN32 */
#include <mstcpip.h>
#endif

#if defined(__APPLE__)
extern int Bun__doesMacOSVersionSupportSendRecvMsgX();
/* XNU's sosend() only skips waiting for buffer space for MSG_NBIO (private, 0x20000); MSG_DONTWAIT alone still blocks there. */
#define LIBUS_SEND_DONTWAIT (MSG_DONTWAIT | 0x20000)
#elif defined(_WIN32)
#define LIBUS_SEND_DONTWAIT 0
#else
#define LIBUS_SEND_DONTWAIT MSG_DONTWAIT
#endif

#if defined(_WIN32)
/* libuv initializes Winsock on first use; every entry point below that creates
 * a socket or resolves an address makes sure that has happened first. */
extern void uv__winsock_ensure(void);
#define bsd_winsock_ensure() uv__winsock_ensure()
#else
#define bsd_winsock_ensure() ((void)0)
#endif


/* We need to emulate sendmmsg, recvmmsg on platform who don't have it */
int bsd_sendmmsg(LIBUS_SOCKET_DESCRIPTOR fd, struct udp_sendbuf* sendbuf, int flags) {
#if defined(_WIN32)// || defined(__APPLE__)
    for (int i = 0; i < sendbuf->num; i++) {
        while (1) {
            int ret = 0;
            struct sockaddr *addr = (struct sockaddr *)sendbuf->addresses[i];
            if (!addr || addr->sa_family == AF_UNSPEC) {
                ret = send(fd, sendbuf->payloads[i], sendbuf->lengths[i], flags);
            } else if (addr->sa_family == AF_INET) {
                socklen_t len = sizeof(struct sockaddr_in);
                ret = sendto(fd, sendbuf->payloads[i], sendbuf->lengths[i], flags, addr, len);
            } else if (addr->sa_family == AF_INET6) {
                socklen_t len = sizeof(struct sockaddr_in6);
                ret = sendto(fd, sendbuf->payloads[i], sendbuf->lengths[i], flags, addr, len);
            } else {
                errno = EAFNOSUPPORT;
                return -1;
            }
            int err = WSAGetLastError();
            if (ret < 0) {
                if (err == WSAEINTR) continue;
                switch (err) {
                    case WSAEWOULDBLOCK:  errno = EAGAIN; break;
                    case WSAEMSGSIZE:     errno = EMSGSIZE; break;
                    case WSAECONNREFUSED: errno = ECONNREFUSED; break;
                    case WSAENETUNREACH:  errno = ENETUNREACH; break;
                    case WSAEHOSTUNREACH: errno = EHOSTUNREACH; break;
                    default:              errno = EIO; break;
                }
                if (err == WSAEWOULDBLOCK || i > 0) return i;
                return ret;
            }
            break;
        }
    }
    return sendbuf->num;
#elif defined(__APPLE__)
    // sendmsg_x does not support addresses.
    if (!sendbuf->has_empty && !sendbuf->has_addresses && Bun__doesMacOSVersionSupportSendRecvMsgX()) {
        while (1) {
            int ret = sendmsg_x(fd, sendbuf->msgvec, sendbuf->num, flags);
            if (ret >= 0) return ret;
            // If we receive EMSGSIZE, we should use the fallback code.
            if (errno == EMSGSIZE) break;
            if (errno != EINTR) return ret;
        }
    }

    for (size_t i = 0, count = sendbuf->num; i < count; i++) {
        while (1) {
            ssize_t ret = sendmsg(fd, &sendbuf->msgvec[i].msg_hdr, flags);
            if (ret < 0) {
                if (errno == EINTR) continue;
                if (errno == EAGAIN || errno == EWOULDBLOCK || i > 0) return i;
                return ret;
            }
            break;
        }
    }

    return sendbuf->num;
#else
    while (1) {
        int ret = sendmmsg(fd, sendbuf->msgvec, sendbuf->num, flags | MSG_NOSIGNAL);
        if (ret >= 0 || errno != EINTR) return ret;
    }
#endif
}

int bsd_recvmmsg(LIBUS_SOCKET_DESCRIPTOR fd, struct udp_recvbuf *recvbuf, int flags, int max_packets) {
    if (max_packets > LIBUS_UDP_RECV_COUNT) max_packets = LIBUS_UDP_RECV_COUNT;
#if defined(_WIN32)
    for (int i = 0; i < LIBUS_UDP_RECV_COUNT; i++) {
        while (1) {
            socklen_t addr_len = sizeof(struct sockaddr_storage);
            ssize_t ret = recvfrom(fd, recvbuf->buf + (size_t) i * LIBUS_UDP_MAX_SIZE,
                LIBUS_UDP_MAX_SIZE, flags, (struct sockaddr *)&recvbuf->addr[i], &addr_len);
            if (ret < 0) {
                int err = WSAGetLastError();
                if (err == WSAEINTR) continue;
                /* Winsock surfaces ICMP "port/host unreachable" from a previous
                 * sendto as WSAECONNRESET (or WSAENETRESET for TTL-expired) on the
                 * next recv. That's per-destination, not per-socket, so treat it as
                 * "no packet" and retry — bubbling it up makes loop.c close the
                 * socket and tear down every conn that shares it (e.g. the QUIC
                 * client endpoint). Mirrors libuv's uv__udp_recv handling. */
                if (err == WSAECONNRESET || err == WSAENETRESET) continue;
                return i > 0 ? i : (int) ret;
            }
            recvbuf->recvlen[i] = (size_t) ret;
            break;
        }
    }
    return LIBUS_UDP_RECV_COUNT;
#elif defined(__APPLE__)
    if (Bun__doesMacOSVersionSupportSendRecvMsgX()) {
        while (1) {
            int ret = recvmsg_x(fd, recvbuf->msgvec, max_packets, flags);
            if (ret >= 0 || errno != EINTR) return ret;
        }
    }

    for (int i = 0; i < max_packets; ++i) {
        while (1) {
            ssize_t ret = recvmsg(fd, &recvbuf->msgvec[i].msg_hdr, flags);
            if (ret < 0) {
                if (errno == EINTR) continue;
                if (errno == EAGAIN || errno == EWOULDBLOCK) return i;
                return ret;
            }
            recvbuf->msgvec[i].msg_len = ret;
            break;
        }
    }
    return max_packets;
#else
    while (1) {
        int ret = recvmmsg(fd, (struct mmsghdr *)&recvbuf->msgvec, max_packets, flags, 0);
        if (ret >= 0 || errno != EINTR) return ret;
    }
#endif
}

void bsd_udp_setup_recvbuf(struct udp_recvbuf *recvbuf, void *databuf, size_t databuflen) {
#if defined(_WIN32)
    recvbuf->buf = databuf;
    recvbuf->buflen = databuflen;
#else
    // assert(databuflen > LIBUS_UDP_MAX_SIZE * LIBUS_UDP_RECV_COUNT);
    memset(recvbuf, 0, sizeof(struct udp_recvbuf));
    for (size_t i = 0; i < LIBUS_UDP_RECV_COUNT; i++) {
        recvbuf->iov[i].iov_base = (char*)databuf + i * LIBUS_UDP_MAX_SIZE;
        recvbuf->iov[i].iov_len = LIBUS_UDP_MAX_SIZE;

        struct msghdr mh = {};
        memset(&mh, 0, sizeof(struct msghdr));
        mh.msg_name = &recvbuf->addr[i];
        mh.msg_namelen = sizeof(struct sockaddr_storage);
        mh.msg_iov = &recvbuf->iov[i];
        mh.msg_iovlen = 1;
        mh.msg_control = recvbuf->control[i];
        mh.msg_controllen = sizeof(recvbuf->control[i]);
        recvbuf->msgvec[i].msg_hdr = mh;
    }
#endif
}

int bsd_udp_setup_sendbuf(struct udp_sendbuf *buf, size_t bufsize, void** payloads, size_t* lengths, void** addresses, int num) {
#if defined(_WIN32)
    buf->payloads = payloads;
    buf->lengths = lengths;
    buf->addresses = addresses;
    buf->num = num;
    return num;
#else
    // TODO: can we skip empty messages altogether? Do we really need to send 0-length messages?
    buf->has_empty = 0;

    // sendmsg_x docs states it does not support addresses.
    buf->has_addresses = 0;

    struct mmsghdr *msgvec = buf->msgvec;
    // todo check this math
    size_t count = (bufsize - sizeof(struct udp_sendbuf)) / (sizeof(struct mmsghdr) + sizeof(struct iovec));
    if (count > num) {
        count = num;
    }
    struct iovec *iov = (struct iovec *) (msgvec + count);
    for (int i = 0; i < count; i++) {
        struct sockaddr *addr = (struct sockaddr *)addresses[i];
        socklen_t addr_len = 0;
        if (addr) {
            addr_len = addr->sa_family == AF_INET ? sizeof(struct sockaddr_in)
                     : addr->sa_family == AF_INET6 ? sizeof(struct sockaddr_in6)
                     : 0;
            if (addr_len > 0) {
                buf->has_addresses = 1;
            }
        }
        iov[i].iov_base = payloads[i];
        iov[i].iov_len = lengths[i];
        msgvec[i].msg_hdr.msg_name = addresses[i];
        msgvec[i].msg_hdr.msg_namelen = addr_len;
        msgvec[i].msg_hdr.msg_control = NULL;
        msgvec[i].msg_hdr.msg_controllen = 0;
        msgvec[i].msg_hdr.msg_iov = iov + i;
        msgvec[i].msg_hdr.msg_iovlen = 1;
        msgvec[i].msg_hdr.msg_flags = 0;
        msgvec[i].msg_len = 0;


        if (lengths[i] == 0) {
            buf->has_empty = 1;
        }
    }
    buf->num = count;
    return count;
#endif
}

char *bsd_udp_packet_buffer_peer(struct udp_recvbuf *msgvec, int index) {
#if defined(_WIN32)
    return (char *)&msgvec->addr[index];
#else
    return ((struct mmsghdr *) msgvec)[index].msg_hdr.msg_name;
#endif
}

char *bsd_udp_packet_buffer_payload(struct udp_recvbuf *msgvec, int index) {
#if defined(_WIN32)
    return msgvec->buf + (size_t) index * LIBUS_UDP_MAX_SIZE;
#else
    return ((struct mmsghdr *) msgvec)[index].msg_hdr.msg_iov[0].iov_base;
#endif
}

int bsd_udp_packet_buffer_payload_length(struct udp_recvbuf *msgvec, int index) {
#if defined(_WIN32)
    return (int) msgvec->recvlen[index];
#else
    /* Clamp to the per-datagram buffer capacity so a truncated datagram can
     * never report more bytes than we actually copied, even if the underlying
     * kernel (e.g. Darwin's recvmsg_x) reports the original datagram length. */
    int len = ((struct mmsghdr *) msgvec)[index].msg_len;
    return len > (int)LIBUS_UDP_MAX_SIZE ? (int)LIBUS_UDP_MAX_SIZE : len;
#endif
}

int bsd_udp_packet_buffer_truncated(struct udp_recvbuf *msgvec, int index) {
#if defined(_WIN32)
    /* On Windows, WSARecvFrom signals truncation via WSAEMSGSIZE on recv,
     * which we don't currently surface here. */
    return 0;
#else
    return (((struct mmsghdr *) msgvec)[index].msg_hdr.msg_flags & MSG_TRUNC) ? 1 : 0;
#endif
}

LIBUS_SOCKET_DESCRIPTOR apple_no_sigpipe(LIBUS_SOCKET_DESCRIPTOR fd) {
#ifdef __APPLE__
    if (fd != LIBUS_SOCKET_ERROR) {
        int no_sigpipe = 1;
        setsockopt(fd, SOL_SOCKET, SO_NOSIGPIPE, &no_sigpipe, sizeof(int));
    }
#endif
    return fd;
}

static LIBUS_SOCKET_DESCRIPTOR win32_set_nonblocking(LIBUS_SOCKET_DESCRIPTOR fd) {
#if _WIN32
    if (fd != LIBUS_SOCKET_ERROR) {
        // libuv will set non-blocking, but only on poll init!
        // we need it to be set on connect as well
        DWORD yes = 1;
        ioctlsocket(fd, FIONBIO, &yes);
    }
    return fd;
#else
    return fd;
#endif
}

LIBUS_SOCKET_DESCRIPTOR bsd_set_nonblocking(LIBUS_SOCKET_DESCRIPTOR fd) {
/* Libuv will set windows sockets as non-blocking */
#ifndef _WIN32
    if (LIKELY(fd != LIBUS_SOCKET_ERROR)) {
        int flags = fcntl(fd, F_GETFL, 0);

        // F_GETFL supports O_NONBLOCK
        fcntl(fd, F_SETFL, flags | O_NONBLOCK);

        flags = fcntl(fd, F_GETFD, 0);

        // F_GETFD supports FD_CLOEXEC
        fcntl(fd, F_SETFD, flags | FD_CLOEXEC);
    }
#endif

    return fd;
}

static int setsockopt_6_or_4(LIBUS_SOCKET_DESCRIPTOR fd, int option4, int option6, const void *option_value, socklen_t option_len) {
    int res = setsockopt(fd, IPPROTO_IPV6, option6, option_value, option_len);

    if (res == 0) {
        return 0;
    }

#ifdef _WIN32
    const int err = WSAGetLastError();
    if (err == WSAENOPROTOOPT || err == WSAEINVAL) {
#else
    if (errno == ENOPROTOOPT || errno == EINVAL) {
#endif
        return setsockopt(fd, IPPROTO_IP, option4, option_value, option_len);
    }

    return res;
}

void bsd_socket_nodelay(LIBUS_SOCKET_DESCRIPTOR fd, int enabled) {
    setsockopt(fd, IPPROTO_TCP, TCP_NODELAY, &enabled, sizeof(enabled));
}

int bsd_socket_broadcast(LIBUS_SOCKET_DESCRIPTOR fd, int enabled) {
    return setsockopt(fd, SOL_SOCKET, SO_BROADCAST, &enabled, sizeof(enabled));
}

int bsd_socket_multicast_loopback(LIBUS_SOCKET_DESCRIPTOR fd, int enabled) {
    return setsockopt_6_or_4(fd, IP_MULTICAST_LOOP, IPV6_MULTICAST_LOOP, &enabled, sizeof(enabled));
}

int bsd_socket_multicast_interface(LIBUS_SOCKET_DESCRIPTOR fd, const struct sockaddr_storage *addr) {
#ifdef _WIN32
    if (fd == SOCKET_ERROR){
        WSASetLastError(WSAEBADF);
        errno = EBADF;
        return -1;
    }
#endif

    if (addr->ss_family == AF_INET) {
        const struct sockaddr_in *addr4 = (const struct sockaddr_in*) addr;
        int first_octet = ntohl(addr4->sin_addr.s_addr) >> 24;
        // 224.0.0.0 through 239.255.255.255 (224.0.0.0/4) are multicast addresses
        // and thus not valid interface addresses.
        if (!(224 <= first_octet && first_octet <= 239)) {
            return setsockopt(fd, IPPROTO_IP, IP_MULTICAST_IF, &addr4->sin_addr, sizeof(addr4->sin_addr));
        }
    }

    if (addr->ss_family == AF_INET6) {
        const struct sockaddr_in6 *addr6 = (const struct sockaddr_in6*) addr;
        return setsockopt(fd, IPPROTO_IPV6, IPV6_MULTICAST_IF, &addr6->sin6_scope_id, sizeof(addr6->sin6_scope_id));
    }

#ifdef _WIN32
    WSASetLastError(WSAEINVAL);
#endif
    errno = EINVAL;
    return -1;
}

static int bsd_socket_set_membership4(LIBUS_SOCKET_DESCRIPTOR fd, const struct sockaddr_in *addr, const struct sockaddr_in *iface, int drop) {
    struct ip_mreq mreq;
    memset(&mreq, 0, sizeof(mreq));

    mreq.imr_multiaddr.s_addr = addr->sin_addr.s_addr;

    if (iface != NULL) {
        mreq.imr_interface.s_addr = iface->sin_addr.s_addr;
    } else {
        mreq.imr_interface.s_addr = htonl(INADDR_ANY);
    }

    int option = drop ? IP_DROP_MEMBERSHIP : IP_ADD_MEMBERSHIP;
    return setsockopt(fd, IPPROTO_IP, option, &mreq, sizeof(mreq));
}

static int bsd_socket_set_membership6(LIBUS_SOCKET_DESCRIPTOR fd, const struct sockaddr_in6 *addr, const struct sockaddr_in6 *iface, int drop) {
    struct ipv6_mreq mreq;
    memset(&mreq, 0, sizeof(mreq));
    mreq.ipv6mr_multiaddr = addr->sin6_addr;
    if (iface != NULL) {
        mreq.ipv6mr_interface = iface->sin6_scope_id;
    }
    int option = drop ? IPV6_LEAVE_GROUP : IPV6_JOIN_GROUP;
    return setsockopt(fd, IPPROTO_IPV6, option, &mreq, sizeof(mreq));
}

int bsd_socket_set_membership(LIBUS_SOCKET_DESCRIPTOR fd, const struct sockaddr_storage *addr, const struct sockaddr_storage *iface, int drop) {
    if (iface != NULL && addr->ss_family != iface->ss_family) {
        errno = EINVAL;
        return -1;
    }

    if (addr->ss_family == AF_INET6) {
        return bsd_socket_set_membership6(fd, (const struct sockaddr_in6*) addr, (const struct sockaddr_in6*) iface, drop);
    } else {
        return bsd_socket_set_membership4(fd, (const struct sockaddr_in*) addr, (const struct sockaddr_in*) iface, drop);
    }
}

static int bsd_socket_set_source_specific_membership4(LIBUS_SOCKET_DESCRIPTOR fd, const struct sockaddr_in *source, const struct sockaddr_in *group, const struct sockaddr_in *iface, int drop) {
    struct ip_mreq_source mreq;
    memset(&mreq, 0, sizeof(mreq));

    if (iface != NULL) {
        mreq.imr_interface.s_addr = iface->sin_addr.s_addr;
    } else {
        mreq.imr_interface.s_addr = htonl(INADDR_ANY);
    }

    mreq.imr_sourceaddr.s_addr = source->sin_addr.s_addr;
    mreq.imr_multiaddr.s_addr = group->sin_addr.s_addr;

    int option = drop? IP_DROP_SOURCE_MEMBERSHIP : IP_ADD_SOURCE_MEMBERSHIP;

    return setsockopt(fd, IPPROTO_IP, option, &mreq, sizeof(mreq));
}

static int bsd_socket_set_source_specific_membership6(LIBUS_SOCKET_DESCRIPTOR fd, const struct sockaddr_in6 *source, const struct sockaddr_in6 *group, const struct sockaddr_in6 *iface, int drop) {
    struct group_source_req mreq;
    memset(&mreq, 0, sizeof(mreq));

    if (iface != NULL) {
        mreq.gsr_interface = iface->sin6_scope_id;
    }

    memcpy(&mreq.gsr_source, source, sizeof(mreq.gsr_source));
    memcpy(&mreq.gsr_group, group, sizeof(mreq.gsr_group));

    int option = drop? MCAST_LEAVE_SOURCE_GROUP : MCAST_JOIN_SOURCE_GROUP;

    return setsockopt(fd, IPPROTO_IPV6, option, &mreq, sizeof(mreq));
}

int bsd_socket_set_source_specific_membership(LIBUS_SOCKET_DESCRIPTOR fd, const struct sockaddr_storage *source, const struct sockaddr_storage *group, const struct sockaddr_storage *iface, int drop) {
    if (source->ss_family == group->ss_family && (iface == NULL || group->ss_family == iface->ss_family)) {
        if (source->ss_family == AF_INET) {
            return bsd_socket_set_source_specific_membership4(fd, (const struct sockaddr_in*) source, (const struct sockaddr_in*) group, (const struct sockaddr_in*) iface, drop);
        } else if (source->ss_family == AF_INET6) {
            return bsd_socket_set_source_specific_membership6(fd, (const struct sockaddr_in6*) source, (const struct sockaddr_in6*) group, (const struct sockaddr_in6*) iface, drop);
        }
    }

#ifdef _WIN32
    WSASetLastError(WSAEINVAL);
#endif
    errno = EINVAL;
    return -1;
}

static int bsd_socket_ttl_any(LIBUS_SOCKET_DESCRIPTOR fd, int ttl, int ipv4, int ipv6) {
    if (ttl < 1 || ttl > 255) {
#ifdef _WIN32
        WSASetLastError(WSAEINVAL);
#endif
        errno = EINVAL;
        return -1;
    }

    return setsockopt_6_or_4(fd, ipv4, ipv6, &ttl, sizeof(ttl));
}

int bsd_socket_ttl_unicast(LIBUS_SOCKET_DESCRIPTOR fd, int ttl) {
    return bsd_socket_ttl_any(fd, ttl, IP_TTL, IPV6_UNICAST_HOPS);
}

int bsd_socket_ttl_multicast(LIBUS_SOCKET_DESCRIPTOR fd, int ttl) {
    return bsd_socket_ttl_any(fd, ttl, IP_MULTICAST_TTL, IPV6_MULTICAST_HOPS);
}

int bsd_socket_keepalive(LIBUS_SOCKET_DESCRIPTOR fd, int on, unsigned int delay) {

#ifndef _WIN32
    if(setsockopt(fd, SOL_SOCKET, SO_KEEPALIVE, &on, sizeof(on))) {
        return errno;
    }

    if (!on)
        return 0;

    /* delay == 0 means "enable SO_KEEPALIVE, keep the kernel-default idle". */
    if (delay == 0)
        return 0;


#ifdef TCP_KEEPIDLE
  if (setsockopt(fd, IPPROTO_TCP, TCP_KEEPIDLE, &delay, sizeof(delay)))
    return errno;
#elif defined(TCP_KEEPALIVE)
  /* Darwin/macOS uses TCP_KEEPALIVE in place of TCP_KEEPIDLE. */
  if (setsockopt(fd, IPPROTO_TCP, TCP_KEEPALIVE, &delay, sizeof(delay)))
    return errno;
#endif

#ifdef TCP_KEEPINTVL
  int intvl = 1;  /*  1 second; same as default on Win32 */
  if (setsockopt(fd, IPPROTO_TCP, TCP_KEEPINTVL, &intvl, sizeof(intvl)))
    return errno;
#endif

#ifdef TCP_KEEPCNT
  int cnt = 10;  /* 10 retries; same as hardcoded on Win32 */
  if (setsockopt(fd, IPPROTO_TCP, TCP_KEEPCNT, &cnt, sizeof(cnt)))
    return errno;
#endif

    return 0;
    #else
    if (setsockopt(fd,
                    SOL_SOCKET,
                    SO_KEEPALIVE,
                    (const char*)&on,
                    sizeof on) == -1) {
        return WSAGetLastError();
    }

    if (!on)
        return 0;

    if (delay == 0)
        return 0;

    if (setsockopt(fd,
                    IPPROTO_TCP,
                    TCP_KEEPALIVE,
                    (const char*)&delay,
                    sizeof delay) == -1) {
        return WSAGetLastError();
    }

    return 0;
    #endif
}

/* IP type-of-service / traffic-class. The option level depends on the socket
 * family (IP_TOS for IPv4, IPV6_TCLASS for IPv6), detected via getsockname.
 * Returns 0 on success or a negative platform errno on failure (the negative
 * convention matches what node:net's ErrnoException expects). */
static int bsd_socket_tos_level(LIBUS_SOCKET_DESCRIPTOR fd, int *level, int *option) {
    struct sockaddr_storage storage;
    socklen_t addrlen = sizeof(storage);
    if (getsockname(fd, (struct sockaddr *) &storage, &addrlen)) {
#ifdef _WIN32
        return -WSAGetLastError();
#else
        return -errno;
#endif
    }
    if (storage.ss_family == AF_INET) {
        *level = IPPROTO_IP;
        *option = IP_TOS;
    } else if (storage.ss_family == AF_INET6) {
        *level = IPPROTO_IPV6;
        *option = IPV6_TCLASS;
    } else {
        return -EINVAL;
    }
    return 0;
}

int bsd_socket_set_tos(LIBUS_SOCKET_DESCRIPTOR fd, int tos) {
    int level, option;
    int err = bsd_socket_tos_level(fd, &level, &option);
    if (err) return err;
#ifdef _WIN32
    if (setsockopt(fd, level, option, (const char *) &tos, sizeof(tos))) {
        return -WSAGetLastError();
    }
#else
    if (setsockopt(fd, level, option, &tos, sizeof(tos))) {
        return -errno;
    }
#endif
    return 0;
}

int bsd_socket_get_tos(LIBUS_SOCKET_DESCRIPTOR fd) {
    int level, option;
    int err = bsd_socket_tos_level(fd, &level, &option);
    if (err) return err;
    int tos = 0;
    socklen_t len = sizeof(tos);
#ifdef _WIN32
    if (getsockopt(fd, level, option, (char *) &tos, (int *) &len)) {
        return -WSAGetLastError();
    }
#else
    if (getsockopt(fd, level, option, &tos, &len)) {
        return -errno;
    }
#endif
    return tos;
}

int bsd_socket_buffer_size(LIBUS_SOCKET_DESCRIPTOR fd, int is_recv, int size, int *out) {
    int option = is_recv ? SO_RCVBUF : SO_SNDBUF;
    if (size != 0) {
#ifdef _WIN32
        int err = setsockopt(fd, SOL_SOCKET, option, (const char *) &size, sizeof(size));
#else
        int err = setsockopt(fd, SOL_SOCKET, option, &size, sizeof(size));
#endif
        if (err) {
            return err;
        }
        *out = size;
        return 0;
    }
    int value = 0;
    socklen_t len = sizeof(value);
#ifdef _WIN32
    int err = getsockopt(fd, SOL_SOCKET, option, (char *) &value, (int *) &len);
#else
    int err = getsockopt(fd, SOL_SOCKET, option, &value, &len);
#endif
    if (err) {
        return err;
    }
    *out = value;
    return 0;
}

void bsd_socket_flush(LIBUS_SOCKET_DESCRIPTOR fd) {
    // Linux TCP_CORK has the same underlying corking mechanism as with MSG_MORE
#ifdef TCP_CORK
    int enabled = 0;
    setsockopt(fd, IPPROTO_TCP, TCP_CORK, &enabled, sizeof(int));
#endif
}

LIBUS_SOCKET_DESCRIPTOR bsd_create_socket(int domain, int type, int protocol, int *err) {
    bsd_winsock_ensure();
    if (err != NULL) {
        *err = 0;
    }

    LIBUS_SOCKET_DESCRIPTOR created_fd;
#if defined(SOCK_CLOEXEC) && defined(SOCK_NONBLOCK)
    const int flags = SOCK_CLOEXEC | SOCK_NONBLOCK;
    do {
        created_fd = socket(domain, type | flags, protocol);
    } while (IS_EINTR(created_fd));

    if (UNLIKELY(created_fd == -1)) {
        if (err != NULL) {
            *err = errno;
        }
        return LIBUS_SOCKET_ERROR;
    }

    return apple_no_sigpipe(created_fd);
#elif defined(_WIN32)
    /* Plain socket() returns an inheritable handle, so any child spawned with
     * bInheritHandles=TRUE (e.g. node:child_process stdio) would duplicate it
     * and keep listen sockets alive after the parent exits. */
    created_fd = WSASocketW(domain, type, protocol, NULL, 0,
                            WSA_FLAG_OVERLAPPED | WSA_FLAG_NO_HANDLE_INHERIT);

    if (UNLIKELY(created_fd == INVALID_SOCKET)) {
        if (err != NULL) {
            *err = WSAGetLastError();
        }
        return LIBUS_SOCKET_ERROR;
    }

    return bsd_set_nonblocking(created_fd);
#else
    do {
        created_fd = socket(domain, type, protocol);
    } while (IS_EINTR(created_fd));

    if (UNLIKELY(created_fd == -1)) {
        if (err != NULL) {
            *err = errno;
        }
        return LIBUS_SOCKET_ERROR;
    }

    return bsd_set_nonblocking(apple_no_sigpipe(created_fd));
#endif
}

void bsd_close_socket(LIBUS_SOCKET_DESCRIPTOR fd) {
#ifdef _WIN32
    closesocket(fd);
#else
    close(fd);
#endif
}

void bsd_shutdown_socket(LIBUS_SOCKET_DESCRIPTOR fd) {
#ifdef _WIN32
    shutdown(fd, SD_SEND);
#else
    shutdown(fd, SHUT_WR);
#endif
}

void bsd_shutdown_socket_read(LIBUS_SOCKET_DESCRIPTOR fd) {
#ifdef _WIN32
    shutdown(fd, SD_RECEIVE);
#else
    shutdown(fd, SHUT_RD);
#endif
}

void internal_finalize_bsd_addr(struct bsd_addr_t *addr) {
    // parse, so to speak, the address
    if (addr->mem.ss_family == AF_INET6) {
        addr->ip = (char *) &((struct sockaddr_in6 *) addr)->sin6_addr;
        addr->ip_length = sizeof(struct in6_addr);
        addr->port = ntohs(((struct sockaddr_in6 *) addr)->sin6_port);
    } else if (addr->mem.ss_family == AF_INET) {
        addr->ip = (char *) &((struct sockaddr_in *) addr)->sin_addr;
        addr->ip_length = sizeof(struct in_addr);
        addr->port = ntohs(((struct sockaddr_in *) addr)->sin_port);
    } else {
        addr->ip_length = 0;
        addr->port = -1;
    }
}

int bsd_local_addr(LIBUS_SOCKET_DESCRIPTOR fd, struct bsd_addr_t *addr) {
    addr->len = sizeof(addr->mem);
    if (getsockname(fd, (struct sockaddr *) &addr->mem, &addr->len)) {
        return -1;
    }
    internal_finalize_bsd_addr(addr);
    return 0;
}

int bsd_remote_addr(LIBUS_SOCKET_DESCRIPTOR fd, struct bsd_addr_t *addr) {
    addr->len = sizeof(addr->mem);
    if (getpeername(fd, (struct sockaddr *) &addr->mem, &addr->len)) {
        return -1;
    }
    internal_finalize_bsd_addr(addr);
    return 0;
}

char *bsd_addr_get_ip(struct bsd_addr_t *addr) {
    return addr->ip;
}

int bsd_addr_get_ip_length(struct bsd_addr_t *addr) {
    return addr->ip_length;
}

int bsd_addr_get_port(struct bsd_addr_t *addr) {
    return addr->port;
}

// called by dispatch_ready_poll
LIBUS_SOCKET_DESCRIPTOR bsd_accept_socket(LIBUS_SOCKET_DESCRIPTOR fd, struct bsd_addr_t *addr) {
    LIBUS_SOCKET_DESCRIPTOR accepted_fd;

    ssize_t injected = 0; int unused = 0;
    if (US_FAULT_CHECK(US_FAULT_ACCEPT, fd, injected, unused)) return LIBUS_SOCKET_ERROR;
    (void)injected; (void)unused;

    while (1) {
        addr->len = sizeof(addr->mem);

#if defined(SOCK_CLOEXEC) && defined(SOCK_NONBLOCK)
    // Linux, FreeBSD
    accepted_fd = accept4(fd, (struct sockaddr *) addr, &addr->len, SOCK_CLOEXEC | SOCK_NONBLOCK);
#else
    // Windows, OS X
    accepted_fd = accept(fd, (struct sockaddr *) addr, &addr->len);
#endif

        if (UNLIKELY(IS_EINTR(accepted_fd))) {
            continue;
        }

        /* We cannot rely on addr since it is not initialized if failed */
        if (accepted_fd == LIBUS_SOCKET_ERROR) {
            return LIBUS_SOCKET_ERROR;
        }

#ifdef __APPLE__
        /* A bug in XNU (the macOS kernel) can cause accept() to return a socket but addrlen=0.
         * This happens when an IPv4 connection is made to an IPv6 dual-stack listener
         * and the connection is immediately aborted (sends RST packet).
         * However, there might be buffered data from connectx() before the abort. */
        if (addr->len == 0) {
            /* Check if there's any pending data before discarding the socket */
            char peek_buf[1];
            ssize_t has_data = recv(accepted_fd, peek_buf, 1, MSG_PEEK | MSG_DONTWAIT);
            
            if (has_data <= 0) {
                /* No data available, socket is truly dead - discard it */
                bsd_close_socket(accepted_fd);
                continue; /* Try to accept the next connection */
            }
            /* If has_data > 0, let the socket through - there's buffered data to read */
        }
#endif

        break;
    }

#ifdef _WIN32
    /* accept() returns an inheritable handle regardless of the listening
     * socket's flags; keep it out of spawned children. */
    SetHandleInformation((HANDLE) accepted_fd, HANDLE_FLAG_INHERIT, 0);
#endif

    internal_finalize_bsd_addr(addr);

#if defined(SOCK_CLOEXEC) && defined(SOCK_NONBLOCK)
// skip the extra fcntl calls.
    return accepted_fd;
#else
    return bsd_set_nonblocking(apple_no_sigpipe(accepted_fd));
#endif
}

ssize_t bsd_recv(LIBUS_SOCKET_DESCRIPTOR fd, void *buf, int length, int flags) {
    ssize_t injected = 0;
    if (US_FAULT_CHECK(US_FAULT_RECV, fd, injected, length)) return injected;
    while (1) {
        ssize_t ret = recv(fd, buf, length, flags);

        if (UNLIKELY(IS_EINTR(ret))) {
            continue;
        }

#if BUN_DEBUG
        // Debug logging for received data
        if (ret > 0) {
            init_debug_logging();
            if (debug_recv_file) {
                fwrite(buf, 1, ret, debug_recv_file);
                fflush(debug_recv_file);
            }
        }
#endif

        return ret;
    }
}

int bsd_queued_input(LIBUS_SOCKET_DESCRIPTOR fd) {
    /* Windows has no MSG_DONTWAIT. Every socket uSockets owns there is already
     * non-blocking, which is what bsd_recv relies on too. */
#ifdef _WIN32
    const int peek_flags = MSG_PEEK;
#else
    const int peek_flags = MSG_PEEK | MSG_DONTWAIT;
#endif
    char byte;
    ssize_t ret;
    do {
        ret = recv(fd, &byte, 1, peek_flags);
    } while (UNLIKELY(IS_EINTR(ret)));

    if (ret > 0) {
        return LIBUS_QUEUED_INPUT_DATA;
    }
    if (ret == 0) {
        return LIBUS_QUEUED_INPUT_EOF;
    }
    return bsd_would_block() ? LIBUS_QUEUED_INPUT_NONE : LIBUS_QUEUED_INPUT_ERROR;
}

#if !defined(_WIN32)
ssize_t bsd_recvmsg(LIBUS_SOCKET_DESCRIPTOR fd, struct msghdr *msg, int flags) {
    ssize_t injected = 0; int unused = 0;
    if (US_FAULT_CHECK(US_FAULT_RECVMSG, fd, injected, unused)) return injected;
    (void)unused;
    while (1) {
        ssize_t ret = recvmsg(fd, msg, flags);

        if (UNLIKELY(IS_EINTR(ret))) {
            continue;
        }

        return ret;
    }
}
#endif

#ifndef MSG_NOSIGNAL
#define MSG_NOSIGNAL 0
#endif
/* Every write to a stream socket uses these, vectored or not. */
#define BSD_SEND_FLAGS (MSG_NOSIGNAL | LIBUS_SEND_DONTWAIT)

#if !defined(_WIN32)
#include <sys/uio.h>

/* sendmsg, not writev: writev takes no flags, so a reset peer would raise SIGPIPE on Linux. */
ssize_t bsd_writev(LIBUS_SOCKET_DESCRIPTOR fd, const struct us_iovec_t *iov, int count) {
    /* sendmsg fails with EMSGSIZE above IOV_MAX (1024 on Linux/macOS); cap and
     * let the caller's partial-write handling carry the remainder. */
    if (count > 1024) {
        count = 1024;
    }
    struct msghdr msg = {0};
    msg.msg_iov = (struct iovec *)iov;
    msg.msg_iovlen = count;

#if defined(LIBUS_SOCKET_FAULT_INJECTION) && LIBUS_SOCKET_FAULT_INJECTION
    /* A "short" rule keeps the first `clamp` bytes of the list. */
    struct iovec clamped[1024];
    ssize_t injected = 0; int clamp = INT_MAX;
    if (US_FAULT_CHECK(US_FAULT_WRITEV, fd, injected, clamp)) return injected;
    if (clamp != INT_MAX) {
        size_t left = (size_t)clamp;
        int kept = 0;
        for (; kept < count && left; kept++) {
            clamped[kept].iov_base = iov[kept].iov_base;
            clamped[kept].iov_len = iov[kept].iov_len < left ? iov[kept].iov_len : left;
            left -= clamped[kept].iov_len;
        }
        msg.msg_iov = clamped;
        msg.msg_iovlen = kept;
    }
#endif

    while (1) {
        ssize_t written = sendmsg(fd, &msg, BSD_SEND_FLAGS);
        if (UNLIKELY(IS_EINTR(written))) {
            continue;
        }
        return written;
    }
}

ssize_t bsd_write2(LIBUS_SOCKET_DESCRIPTOR fd, const char *header, int header_length, const char *payload, int payload_length) {
    struct us_iovec_t chunks[2] = {{(void *)header, (size_t)header_length}, {(void *)payload, (size_t)payload_length}};
    return bsd_writev(fd, chunks, 2);
}
#else
ssize_t bsd_writev(LIBUS_SOCKET_DESCRIPTOR fd, const struct us_iovec_t *iov, int count) {
    ssize_t total = 0;
    for (int i = 0; i < count; i++) {
        ssize_t written = bsd_send(fd, (const char *)iov[i].iov_base, (int)iov[i].iov_len);
        if (written > 0) total += written;
        if (written != (ssize_t)iov[i].iov_len) break;
    }
    return total > 0 ? total : -1;
}

ssize_t bsd_write2(LIBUS_SOCKET_DESCRIPTOR fd, const char *header, int header_length, const char *payload, int payload_length) {
    ssize_t written = bsd_send(fd, header, header_length);
    if (written == header_length) {
        ssize_t second_write = bsd_send(fd, payload, payload_length);
        if (second_write > 0) {
            written += second_write;
        }
    }
    return written;
}
#endif

ssize_t bsd_send(LIBUS_SOCKET_DESCRIPTOR fd, const char *buf, int length) {
    ssize_t injected = 0;
    if (US_FAULT_CHECK(US_FAULT_SEND, fd, injected, length)) return injected;
    while (1) {
        ssize_t rc = send(fd, buf, length, BSD_SEND_FLAGS);

        if (UNLIKELY(IS_EINTR(rc))) {
            continue;
        }

#if BUN_DEBUG
        // Debug logging for sent data
        if (rc > 0) {
            init_debug_logging();
            if (debug_send_file) {
                fwrite(buf, 1, rc, debug_send_file);
                fflush(debug_send_file);
            }
        }
#endif

        return rc;
    }
}

#if !defined(_WIN32)
ssize_t bsd_sendmsg(LIBUS_SOCKET_DESCRIPTOR fd, const struct msghdr *msg, int flags) {
    ssize_t injected = 0; int unused = 0;
    if (US_FAULT_CHECK(US_FAULT_SENDMSG, fd, injected, unused)) return injected;
    (void)unused;
    while (1) {
        ssize_t rc = sendmsg(fd, msg, flags | MSG_NOSIGNAL | LIBUS_SEND_DONTWAIT);

        if (UNLIKELY(IS_EINTR(rc))) {
            continue;
        }

        return rc;
    }
}
#endif

int bsd_would_block() {
#ifdef _WIN32
    return WSAGetLastError() == WSAEWOULDBLOCK;
#else
    return errno == EWOULDBLOCK;// || errno == EAGAIN;
#endif
}

/* Transient kernel resource exhaustion from send(): the connection is still
 * healthy and a later retry can succeed. Kept distinct from bsd_would_block()
 * so recv() callers that use that to mean EOF-vs-error do not start spinning
 * on ENOBUFS. */
int bsd_send_is_transient_error() {
#ifdef _WIN32
    return WSAGetLastError() == WSAENOBUFS;
#else
    return errno == ENOBUFS || errno == ENOMEM;
#endif
}

static int us_internal_bind_and_listen(LIBUS_SOCKET_DESCRIPTOR listenFd, struct sockaddr *listenAddr, socklen_t listenAddrLength, int backlog, int* error) {
    int result;
    do
        result = bind(listenFd, listenAddr, listenAddrLength);
    while (IS_EINTR(result));

    if (result == -1) {
        *error = LIBUS_ERR;
        return -1;
    }

    do
        result = listen(listenFd, backlog);
    while (IS_EINTR(result));
    *error = LIBUS_ERR;

    return result;
}

/* libuv's uv__sock_reuseaddr: SO_REUSEPORT on the BSDs where that is what
 * actually allows a second bind of the same address, SO_REUSEADDR elsewhere. */
int bsd_set_reuseaddr(LIBUS_SOCKET_DESCRIPTOR listenFd) {
    const int one = 1;
#if defined(SO_REUSEPORT) && !defined(__linux__) && !defined(__GNU__)
    return setsockopt(listenFd, SOL_SOCKET, SO_REUSEPORT, &one, sizeof(one));
#else
    return setsockopt(listenFd, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one));
#endif
}

static int bsd_set_reuseport(LIBUS_SOCKET_DESCRIPTOR listenFd) {
#if defined(SO_REUSEPORT) && !defined(_WIN32)
    const int one = 1;
    return setsockopt(listenFd, SOL_SOCKET, SO_REUSEPORT, &one, sizeof(one));
#else
#if _WIN32
    WSASetLastError(WSAEOPNOTSUPP);
#endif
    errno = ENOTSUP;
    return -1;
#endif
}

static int bsd_set_reuse(LIBUS_SOCKET_DESCRIPTOR listenFd, int options) {
    int result = 0;

    if ((options & LIBUS_LISTEN_EXCLUSIVE_PORT)) {
#if _WIN32
        const int one = 1;
        result = setsockopt(listenFd, SOL_SOCKET, SO_EXCLUSIVEADDRUSE, &one, sizeof(one));
        if (result != 0) {
            return result;
        }
#endif
    }

    if ((options & LIBUS_LISTEN_REUSE_ADDR)) {
        result = bsd_set_reuseaddr(listenFd);
        if (result != 0) {
            return result;
        }
    }

    if ((options & LIBUS_LISTEN_REUSE_PORT)) {
        result = bsd_set_reuseport(listenFd);
        if (result != 0) {
            if (errno == ENOTSUP) {
                if ((options & LIBUS_LISTEN_DISALLOW_REUSE_PORT_FAILURE) == 0) {
                    errno = 0;
                    return 0;
                }
            }

            return result;
        }
    }

    return 0;
}

inline __attribute__((always_inline)) LIBUS_SOCKET_DESCRIPTOR bsd_bind_listen_fd(
    LIBUS_SOCKET_DESCRIPTOR listenFd,
    struct addrinfo *listenAddr,
    int port,
    int options,
    int* error
) {

    if (bsd_set_reuse(listenFd, options) != 0) {
        return LIBUS_SOCKET_ERROR;
    }

#if defined(SO_REUSEADDR) && !_WIN32
    //  Unlike on Unix, here we don't set SO_REUSEADDR, because it doesn't just
    //  allow binding to addresses that are in use by sockets in TIME_WAIT, it
    //  effectively allows 'stealing' a port which is in use by another application.
    //  See libuv issue #1360.
    int one = 1;
    setsockopt(listenFd, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one));
#endif

#ifdef IPV6_V6ONLY
    if (listenAddr->ai_family == AF_INET6) {
        int enabled = (options & LIBUS_SOCKET_IPV6_ONLY) != 0;
        if (setsockopt(listenFd, IPPROTO_IPV6, IPV6_V6ONLY, &enabled, sizeof(enabled)) != 0) {
            return LIBUS_SOCKET_ERROR;
        }
    }
#endif

    if (us_internal_bind_and_listen(listenFd, listenAddr->ai_addr, (socklen_t) listenAddr->ai_addrlen, 512, error)) {
        return LIBUS_SOCKET_ERROR;
    }

    return listenFd;
}

int bsd_set_defer_accept(LIBUS_SOCKET_DESCRIPTOR listenFd) {
#if defined(TCP_DEFER_ACCEPT)
    /* nginx uses 1 second here: there's no way to know how long a connection sat in the
     * defer queue (or whether it bypassed it via syncookies), so a short timeout lets the
     * application's own idle timeout take over for clients that connect but never send. */
    int timeout = 1;
    return setsockopt(listenFd, IPPROTO_TCP, TCP_DEFER_ACCEPT, &timeout, sizeof(timeout)) == 0;
#elif defined(SO_ACCEPTFILTER)
    struct accept_filter_arg afa;
    memset(&afa, 0, sizeof(afa));
    strcpy(afa.af_name, "dataready");
    return setsockopt(listenFd, SOL_SOCKET, SO_ACCEPTFILTER, &afa, sizeof(afa)) == 0;
#else
    (void) listenFd;
    return 0;
#endif
}

// return LIBUS_SOCKET_ERROR or the fd that represents listen socket
// listen both on ipv6 and ipv4
int bsd_socket_export_size(void) {
#ifdef _WIN32
    return (int) sizeof(WSAPROTOCOL_INFOW);
#else
    return 0;
#endif
}

int bsd_socket_export(LIBUS_SOCKET_DESCRIPTOR fd, unsigned int target_pid, void *info_out) {
#ifdef _WIN32
    if (WSADuplicateSocketW(fd, (DWORD) target_pid, (WSAPROTOCOL_INFOW *) info_out) != 0) {
        return WSAGetLastError();
    }
    return 0;
#else
    (void) fd; (void) target_pid; (void) info_out;
    return ENOTSUP;
#endif
}

LIBUS_SOCKET_DESCRIPTOR bsd_socket_import(void *info, int *err) {
    bsd_winsock_ensure();
#ifdef _WIN32
    SOCKET s = WSASocketW(FROM_PROTOCOL_INFO, FROM_PROTOCOL_INFO, FROM_PROTOCOL_INFO,
                          (WSAPROTOCOL_INFOW *) info, 0, WSA_FLAG_OVERLAPPED);
    if (s == INVALID_SOCKET) {
        *err = WSAGetLastError();
        return LIBUS_SOCKET_ERROR;
    }
    return s;
#else
    (void) info;
    *err = ENOTSUP;
    return LIBUS_SOCKET_ERROR;
#endif
}

/* Windows rejects listen() on a duplicate of an already-listening socket, where POSIX
 * no-ops it; cluster workers each listen on their own dup of one shared fd. libuv
 * sidesteps this by listening before the xfer (UV_HANDLE_SHARED_TCP_SOCKET, win/tcp.c). */
int bsd_socket_listen_error_is_benign(LIBUS_SOCKET_DESCRIPTOR fd) {
#ifdef _WIN32
    int listening = 0;
    int optlen = (int) sizeof(listening);
    if (getsockopt(fd, SOL_SOCKET, SO_ACCEPTCONN, (char *) &listening, &optlen) != 0) {
        return 0;
    }
    return listening != 0;
#else
    (void) fd;
    return 0;
#endif
}

LIBUS_SOCKET_DESCRIPTOR bsd_create_bound_socket(const char *host, int port, int options, int *out_port, int *error) {
    bsd_winsock_ensure();
    struct addrinfo hints, *result;
    memset(&hints, 0, sizeof(struct addrinfo));
    hints.ai_flags = AI_PASSIVE;
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = SOCK_STREAM;

    char port_string[16];
    snprintf(port_string, 16, "%d", port);

    int gai = getaddrinfo(host, port_string, &hints, &result);
    if (gai != 0) {
#ifdef _WIN32
        *error = gai;
#else
        *error = EINVAL;
#endif
        return LIBUS_SOCKET_ERROR;
    }

    LIBUS_SOCKET_DESCRIPTOR fd = LIBUS_SOCKET_ERROR;
    for (int family = AF_INET6; fd == LIBUS_SOCKET_ERROR && family >= AF_INET; family -= (AF_INET6 - AF_INET)) {
        for (struct addrinfo *a = result; a != NULL; a = a->ai_next) {
            if (a->ai_family != family) {
                continue;
            }
            fd = bsd_create_socket(a->ai_family, a->ai_socktype, a->ai_protocol, NULL);
            if (fd == LIBUS_SOCKET_ERROR) {
                *error = LIBUS_ERR;
                continue;
            }
#if defined(SO_REUSEADDR) && !defined(_WIN32)
            int one = 1;
            setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one));
#endif
#ifdef IPV6_V6ONLY
            if (a->ai_family == AF_INET6) {
                int enabled = (options & LIBUS_SOCKET_IPV6_ONLY) != 0;
                setsockopt(fd, IPPROTO_IPV6, IPV6_V6ONLY, (void *) &enabled, sizeof(enabled));
            }
#endif
            int rc;
            do
                rc = bind(fd, a->ai_addr, (socklen_t) a->ai_addrlen);
            while (IS_EINTR(rc));
            if (rc != 0) {
                *error = LIBUS_ERR;
                bsd_close_socket(fd);
                fd = LIBUS_SOCKET_ERROR;
                continue;
            }
            break;
        }
    }
    freeaddrinfo(result);
    if (fd == LIBUS_SOCKET_ERROR) {
        return LIBUS_SOCKET_ERROR;
    }
#ifdef _WIN32
    /* Windows rejects listen() on a duplicate of an already-listening socket
     * only after another duplicate has listened, so two workers racing on the
     * same shared fd can observe listen() -> WSAEINVAL while SO_ACCEPTCONN
     * still reads 0 (the benign check in us_socket_group_listen_fd then
     * fails). libuv's approach (UV_HANDLE_SHARED_TCP_SOCKET, win/tcp.c) is to
     * listen in the primary before WSADuplicateSocket; every worker's
     * duplicate is then already listening and SO_ACCEPTCONN is reliably set. */
    if (listen(fd, 511) != 0) {
        *error = LIBUS_ERR;
        bsd_close_socket(fd);
        return LIBUS_SOCKET_ERROR;
    }
#endif
    struct bsd_addr_t tmp;
    if (bsd_local_addr(fd, &tmp) == 0) {
        *out_port = bsd_addr_get_port(&tmp);
    } else {
        *out_port = port;
    }
    return fd;
}

LIBUS_SOCKET_DESCRIPTOR bsd_create_listen_socket(const char *host, int port, int options, int* error) {
    bsd_winsock_ensure();
    struct addrinfo hints, *result;
    memset(&hints, 0, sizeof(struct addrinfo));

    hints.ai_flags = AI_PASSIVE;
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = SOCK_STREAM;

    char port_string[16];
    snprintf(port_string, 16, "%d", port);

    if (getaddrinfo(host, port_string, &hints, &result)) {
        return LIBUS_SOCKET_ERROR;
    }

    LIBUS_SOCKET_DESCRIPTOR listenFd = LIBUS_SOCKET_ERROR;
    struct addrinfo *listenAddr;
    for (struct addrinfo *a = result; a != NULL; a = a->ai_next) {
        if (a->ai_family == AF_INET6) {
            listenFd = bsd_create_socket(a->ai_family, a->ai_socktype, a->ai_protocol, NULL);
            if (listenFd == LIBUS_SOCKET_ERROR) {
                continue;
            }

            listenAddr = a;
            if (bsd_bind_listen_fd(listenFd, listenAddr, port, options, error) != LIBUS_SOCKET_ERROR) {
                freeaddrinfo(result);
                return listenFd;
            }

            bsd_close_socket(listenFd);
        }
    }

    for (struct addrinfo *a = result; a != NULL; a = a->ai_next) {
        if (a->ai_family == AF_INET) {
            listenFd = bsd_create_socket(a->ai_family, a->ai_socktype, a->ai_protocol, NULL);
            if (listenFd == LIBUS_SOCKET_ERROR) {
                continue;
            }

            listenAddr = a;
            if (bsd_bind_listen_fd(listenFd, listenAddr, port, options, error) != LIBUS_SOCKET_ERROR) {
                freeaddrinfo(result);
                return listenFd;
            }

            bsd_close_socket(listenFd);
        }
    }

    freeaddrinfo(result);
    return LIBUS_SOCKET_ERROR;
}

#ifndef _WIN32
#include <sys/un.h>
#else
#include <afunix.h>
#include <io.h>
#endif
#include <sys/stat.h>
#include <stddef.h>

#if defined(__APPLE__)
// Per-thread chdir. Not declared in any public header, but a stable syscall since macOS 10.5.
// Passing -1 clears the per-thread cwd override.
extern int __pthread_fchdir(int fd);
#endif

static LIBUS_SOCKET_DESCRIPTOR bsd_create_unix_socket_address(const char *path, size_t path_len, int* dirfd_workaround_for_unix_path_len, struct sockaddr_un *server_address, size_t* addrlen) {
    memset(server_address, 0, sizeof(struct sockaddr_un));
    server_address->sun_family = AF_UNIX;

    if (path_len == 0) {
        #if defined(_WIN32)
            // simulate ENOENT
            SetLastError(ERROR_PATH_NOT_FOUND);
        #else
            errno = ENOENT;
        #endif
        return LIBUS_SOCKET_ERROR;
    }

    *addrlen = sizeof(struct sockaddr_un);

    #if defined(__linux__)
        // Unix socket addresses have a maximum length of 108 bytes on Linux
        // As a workaround, we can use /proc/self/fd/ as a directory to shorten the path
        if (path_len >= sizeof(server_address->sun_path) && path[0] != '\0') {
            size_t dirname_len = path_len;
            // get the basename
            while (dirname_len > 1 && path[dirname_len - 1] != '/') {
                dirname_len--;
            }

            // if the path is just a single character, or the path is too long, we cannot use this method
            if (dirname_len < 2 || (path_len - dirname_len + 1) >= sizeof(server_address->sun_path)) {
                errno = ENAMETOOLONG;
                return LIBUS_SOCKET_ERROR;
            }

            char dirname_buf[4096];
            if (dirname_len + 1 > sizeof(dirname_buf)) {
                errno = ENAMETOOLONG;
                return LIBUS_SOCKET_ERROR;
            }

            memcpy(dirname_buf, path, dirname_len);
            dirname_buf[dirname_len] = 0;

            int socket_dir_fd = open(dirname_buf, O_CLOEXEC | O_PATH | O_DIRECTORY, 0700);
            if (socket_dir_fd == -1) {
                errno = ENAMETOOLONG;
                return LIBUS_SOCKET_ERROR;
            }

            // `path` is a ptr+len pair (not NUL-terminated), so bound the basename copy with %.*s.
            int sun_path_len = snprintf(server_address->sun_path, sizeof(server_address->sun_path), "/proc/self/fd/%d/%.*s", socket_dir_fd, (int)(path_len - dirname_len), path + dirname_len);
            if (sun_path_len >= sizeof(server_address->sun_path) || sun_path_len < 0) {
                close(socket_dir_fd);
                errno = ENAMETOOLONG;
                return LIBUS_SOCKET_ERROR;
            }

            *dirfd_workaround_for_unix_path_len = socket_dir_fd;
            return 0;
        } else if (path_len < sizeof(server_address->sun_path)) {
            memcpy(server_address->sun_path, path, path_len);

            // abstract domain sockets
            if (server_address->sun_path[0] == 0) {
                *addrlen = offsetof(struct sockaddr_un, sun_path) + path_len;
            }

            return 0;
        }
    #endif

    #if defined(__APPLE__)
        // sun_path is 104 bytes on macOS. /dev/fd/N/ is not traversable like /proc/self/fd/N/ on Linux,
        // so instead we open the parent directory and let the caller __pthread_fchdir() into it and
        // bind/connect with a relative basename.
        if (path_len >= sizeof(server_address->sun_path)) {
            size_t dirname_len = path_len;
            while (dirname_len > 1 && path[dirname_len - 1] != '/') {
                dirname_len--;
            }

            size_t basename_len = path_len - dirname_len;
            if (dirname_len < 2 || basename_len + 1 >= sizeof(server_address->sun_path)) {
                errno = ENAMETOOLONG;
                return LIBUS_SOCKET_ERROR;
            }

            char dirname_buf[4096];
            if (dirname_len + 1 > sizeof(dirname_buf)) {
                errno = ENAMETOOLONG;
                return LIBUS_SOCKET_ERROR;
            }

            memcpy(dirname_buf, path, dirname_len);
            dirname_buf[dirname_len] = 0;

            int socket_dir_fd = open(dirname_buf, O_CLOEXEC | O_RDONLY | O_DIRECTORY);
            if (socket_dir_fd == -1) {
                errno = ENAMETOOLONG;
                return LIBUS_SOCKET_ERROR;
            }

            memcpy(server_address->sun_path, path + dirname_len, basename_len);
            server_address->sun_path[basename_len] = 0;

            *dirfd_workaround_for_unix_path_len = socket_dir_fd;
            return 0;
        }
    #endif

    if (path_len >= sizeof(server_address->sun_path)) {
        #if defined(_WIN32)
            // simulate ENAMETOOLONG
            SetLastError(ERROR_FILENAME_EXCED_RANGE);
        #else
            errno = ENAMETOOLONG;
        #endif

        return LIBUS_SOCKET_ERROR;
    }

    memcpy(server_address->sun_path, path, path_len);
    return 0;
}

static LIBUS_SOCKET_DESCRIPTOR internal_bsd_create_listen_socket_unix(const char* path, int options, struct sockaddr_un* server_address, size_t addrlen, int* error) {
    LIBUS_SOCKET_DESCRIPTOR listenFd = LIBUS_SOCKET_ERROR;

    listenFd = bsd_create_socket(AF_UNIX, SOCK_STREAM, 0, NULL);

    if (listenFd == LIBUS_SOCKET_ERROR) {
        return LIBUS_SOCKET_ERROR;
    }

    if (us_internal_bind_and_listen(listenFd, (struct sockaddr *) server_address, (socklen_t) addrlen, 512, error)) {
        #if defined(_WIN32)
          int shouldSimulateENOENT = WSAGetLastError() == WSAENETDOWN;
        #endif
        bsd_close_socket(listenFd);
        #if defined(_WIN32)
            if (shouldSimulateENOENT) {
                SetLastError(ERROR_PATH_NOT_FOUND);
            }
        #endif
        return LIBUS_SOCKET_ERROR;
    }

    return listenFd;
}

LIBUS_SOCKET_DESCRIPTOR bsd_create_listen_socket_unix(const char *path, size_t len, int options, int* error) {
    int dirfd_workaround_for_unix_path_len = -1;
    struct sockaddr_un server_address;
    size_t addrlen = 0;
    if (bsd_create_unix_socket_address(path, len, &dirfd_workaround_for_unix_path_len, &server_address, &addrlen)) {
        /* The path could not be expressed as a sockaddr_un (the basename
         * exceeds sun_path even with the dirfd workaround); surface the errno
         * so the caller can report something better than a codeless failure. */
        if (error && errno) *error = errno;
        return LIBUS_SOCKET_ERROR;
    }

#if defined(__APPLE__)
    if (dirfd_workaround_for_unix_path_len != -1) {
        if (__pthread_fchdir(dirfd_workaround_for_unix_path_len) != 0) {
            close(dirfd_workaround_for_unix_path_len);
            errno = ENAMETOOLONG;
            return LIBUS_SOCKET_ERROR;
        }
    }
#endif

    LIBUS_SOCKET_DESCRIPTOR listenFd = internal_bsd_create_listen_socket_unix(path, options, &server_address, addrlen, error);

#if defined(__APPLE__)
    if (dirfd_workaround_for_unix_path_len != -1) {
        int saved_errno = errno;
        __pthread_fchdir(-1);
        close(dirfd_workaround_for_unix_path_len);
        errno = saved_errno;
    }
#elif defined(__linux__)
    if (dirfd_workaround_for_unix_path_len != -1) {
        close(dirfd_workaround_for_unix_path_len);
    }
#endif

    return listenFd;
}


/* Receive-path options every UDP socket needs, whether freshly created or
 * adopted from an existing fd: destination-address and TOS reporting for
 * recvmmsg, Windows ICMP-reset suppression, and Linux IP_RECVERR (opt-in). */
static void bsd_apply_udp_recv_options(LIBUS_SOCKET_DESCRIPTOR fd, int family, int options) {
    /* We need destination address for udp packets in both ipv6 and ipv4 */

/* On FreeBSD this option seems to be called like so */
#ifndef IPV6_RECVPKTINFO
#define IPV6_RECVPKTINFO IPV6_PKTINFO
#endif

    int enabled = 1;
    if (setsockopt(fd, IPPROTO_IPV6, IPV6_RECVPKTINFO, &enabled, sizeof(enabled)) == -1) {
        if (errno == ENOPROTOOPT || errno == EINVAL) {
#if defined(IP_PKTINFO)
            setsockopt(fd, IPPROTO_IP, IP_PKTINFO, &enabled, sizeof(enabled));
#elif defined(IP_RECVDSTADDR)
            setsockopt(fd, IPPROTO_IP, IP_RECVDSTADDR, &enabled, sizeof(enabled));
#endif
        }
    }

    /* These are used for getting the ECN */
    if (setsockopt(fd, IPPROTO_IPV6, IPV6_RECVTCLASS, &enabled, sizeof(enabled)) == -1) {
        if (errno == ENOPROTOOPT || errno == EINVAL) {
            setsockopt(fd, IPPROTO_IP, IP_RECVTOS, &enabled, sizeof(enabled));
        }
    }

#if defined(_WIN32)
    /* By default Winsock reports ICMP "port unreachable" from a previous
     * sendto as WSAECONNRESET on the next recv. bsd_recvmmsg already swallows
     * it, but disabling the report at the source means a queued ICMP can't
     * race ahead of a real packet in WSARecvFrom either. */
    {
        DWORD off = 0, br;
        WSAIoctl(fd, SIO_UDP_CONNRESET, &off, sizeof(off), NULL, 0, &br, NULL, NULL);
#ifdef SIO_UDP_NETRESET
        WSAIoctl(fd, SIO_UDP_NETRESET, &off, sizeof(off), NULL, 0, &br, NULL, NULL);
#endif
    }
#endif

#if defined(__linux__)
    /* IP_RECVERR/IPV6_RECVERR queues ICMP errors on the socket's error queue
     * for on_recv_error to drain. libuv gates this on UV_UDP_LINUX_RECVERR
     * (Node's dgram never passes it). Opt-in only: on a shared unconnected
     * socket (the HTTP/3 fetch client) it also makes a queued ICMP fail the
     * next send to a different, live peer. */
    if (options & LIBUS_UDP_LINUX_RECVERR) {
#ifdef IP_RECVERR
        setsockopt(fd, IPPROTO_IP, IP_RECVERR, &enabled, sizeof(enabled));
#endif
#ifdef IPV6_RECVERR
        if (family == AF_INET6) {
            setsockopt(fd, IPPROTO_IPV6, IPV6_RECVERR, &enabled, sizeof(enabled));
        }
#endif
    }
#else
    (void) options;
#endif
}

/* Prepares an externally created UDP fd for adoption, matching uv_udp_open:
 * nonblock + SO_REUSEADDR only. Recv-path options (IP_RECVERR, PKTINFO,
 * SIO_UDP_CONNRESET) are NOT applied — mutating the caller's fd is observable. */
int bsd_prepare_adopted_udp_socket(LIBUS_SOCKET_DESCRIPTOR fd) {
    /* Refuse to adopt anything that isn't a datagram socket. */
    int sock_type = 0;
    socklen_t type_len = sizeof(sock_type);
    if (getsockopt(fd, SOL_SOCKET, SO_TYPE, (char *) &sock_type, (socklen_t *) &type_len)) {
        return -1;
    }
    if (sock_type != SOCK_DGRAM) {
#ifdef _WIN32
        WSASetLastError(WSAEINVAL);
#endif
        errno = EINVAL;
        return -1;
    }
    struct sockaddr_storage ss;
    socklen_t len = sizeof(ss);
    if (getsockname(fd, (struct sockaddr *) &ss, (socklen_t *) &len)) {
        return -1;
    }
    /* Only INET datagram sockets: address getters and send destinations all
     * assume AF_INET/AF_INET6. */
    if (ss.ss_family != AF_INET && ss.ss_family != AF_INET6) {
#ifdef _WIN32
        WSASetLastError(WSAEINVAL);
#endif
        errno = EINVAL;
        return -1;
    }
    apple_no_sigpipe(fd);
    if (bsd_set_nonblocking(fd) == LIBUS_SOCKET_ERROR) {
        return -1;
    }
    /* uv_udp_open unconditionally sets SO_REUSEADDR (kept for backwards
     * compat, libuv#4551); best-effort here so a bound-and-already-set fd
     * doesn't fail adoption. */
    (void) bsd_set_reuseaddr(fd);
    return 0;
}

/* Binds a raw datagram descriptor. `flags` uses libuv's UV_UDP_* bits (bit 0
 * IPV6ONLY, bit 2 REUSEADDR). Shared by internal/dgram so it doesn't fork
 * bsd_set_reuseaddr's platform gate. Returns 0 or -1 with the error in errno. */
int bsd_bind_udp_fd(LIBUS_SOCKET_DESCRIPTOR fd, const struct sockaddr *addr, int addrlen, int flags) {
#ifdef IPV6_V6ONLY
    if ((flags & 1) && addr->sa_family == AF_INET6) {
        int on = 1;
        if (setsockopt(fd, IPPROTO_IPV6, IPV6_V6ONLY, (char *) &on, sizeof(on)) != 0) {
            return -1;
        }
    }
#endif
    if (flags & 4) {
        if (bsd_set_reuseaddr(fd) != 0) {
            return -1;
        }
    }
    if (bind(fd, addr, (socklen_t) addrlen) != 0) {
        return -1;
    }
    return 0;
}

LIBUS_SOCKET_DESCRIPTOR bsd_create_udp_socket(const char *host, int port, int options, int *err) {
    bsd_winsock_ensure();
    if (err != NULL) {
        *err = 0;
    }

    struct addrinfo hints, *result;
    memset(&hints, 0, sizeof(struct addrinfo));

    hints.ai_flags = AI_PASSIVE;
    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = SOCK_DGRAM;

    char port_string[16];
    snprintf(port_string, 16, "%d", port);

    int gai_result = getaddrinfo(host, port_string, &hints, &result);
    if (gai_result != 0) {
        if (err != NULL) {
            *err = -gai_result;
        }
        return LIBUS_SOCKET_ERROR;
    }

    LIBUS_SOCKET_DESCRIPTOR listenFd = LIBUS_SOCKET_ERROR;
    struct addrinfo *listenAddr = NULL;
    for (struct addrinfo *a = result; a && listenFd == LIBUS_SOCKET_ERROR; a = a->ai_next) {
        if (a->ai_family == AF_INET6) {
            listenFd = bsd_create_socket(a->ai_family, a->ai_socktype, a->ai_protocol, err);
            listenAddr = a;
        }
    }

    for (struct addrinfo *a = result; a && listenFd == LIBUS_SOCKET_ERROR; a = a->ai_next) {
        if (a->ai_family == AF_INET) {
            listenFd = bsd_create_socket(a->ai_family, a->ai_socktype, a->ai_protocol, err);
            listenAddr = a;
        }
    }

    if (listenFd == LIBUS_SOCKET_ERROR) {
        freeaddrinfo(result);
        return LIBUS_SOCKET_ERROR;
    }

    if (bsd_set_reuse(listenFd, options) != 0) {
        if (err != NULL) {
#ifdef _WIN32
            *err = WSAGetLastError();
#else
            *err = errno;
#endif
        }
        bsd_close_socket(listenFd);
        freeaddrinfo(result);
        return LIBUS_SOCKET_ERROR;
    }

#ifdef IPV6_V6ONLY
    if (listenAddr->ai_family == AF_INET6) {
        int enabled = (options & LIBUS_SOCKET_IPV6_ONLY) != 0;
        if (setsockopt(listenFd, IPPROTO_IPV6, IPV6_V6ONLY, &enabled, sizeof(enabled)) != 0) {
            return LIBUS_SOCKET_ERROR;
        }
    }
#endif

    bsd_apply_udp_recv_options(listenFd, listenAddr->ai_family, options);

    /* We bind here as well */
    if (bind(listenFd, listenAddr->ai_addr, (socklen_t) listenAddr->ai_addrlen)) {
        if (err != NULL) {
#ifdef _WIN32
            *err = WSAGetLastError();
#else
            *err = errno;
#endif
        }
        bsd_close_socket(listenFd);
        freeaddrinfo(result);
        return LIBUS_SOCKET_ERROR;
    }

    freeaddrinfo(result);
    if (err != NULL) {
        *err = 0;
    }
    return listenFd;
}

int bsd_connect_udp_socket(LIBUS_SOCKET_DESCRIPTOR fd, const char *host, int port) {
    bsd_winsock_ensure();
    struct addrinfo hints, *result;
    memset(&hints, 0, sizeof(struct addrinfo));

    hints.ai_family = AF_UNSPEC;
    hints.ai_socktype = SOCK_DGRAM;

    char port_string[16];
    snprintf(port_string, 16, "%d", port);

    int gai_error = getaddrinfo(host, port_string, &hints, &result);

    if (gai_error != 0) {
        return gai_error;
    }

    if (result == NULL) {
        return -1;
    }

    for (struct addrinfo *rp = result; rp != NULL; rp = rp->ai_next) {
        if (connect(fd, rp->ai_addr, rp->ai_addrlen) == 0) {
            freeaddrinfo(result);
            return 0;
        }
    }

    freeaddrinfo(result);
    return (int)LIBUS_SOCKET_ERROR;
}

int bsd_disconnect_udp_socket(LIBUS_SOCKET_DESCRIPTOR fd) {
    struct sockaddr addr;
    memset(&addr, 0, sizeof(addr));
    addr.sa_family = AF_UNSPEC;
    #ifdef __APPLE__
    addr.sa_len = sizeof(addr);
    #endif

    int res = connect(fd, &addr, sizeof(addr));
    // EAFNOSUPPORT is harmless in this case - we just want to disconnect
    if (res == 0 ||
#ifdef _WIN32
    WSAGetLastError() == WSAEAFNOSUPPORT
#else
    errno == EAFNOSUPPORT
#endif
    ) {
        return 0;
    } else {
        return -1;
    }
}

static int bsd_do_connect_raw(LIBUS_SOCKET_DESCRIPTOR fd, struct sockaddr *addr, size_t namelen)
{
    ssize_t injected = 0; int unused = 0;
    if (US_FAULT_CHECK(US_FAULT_CONNECT, fd, injected, unused)) return errno;
    (void)injected; (void)unused;
#ifdef _WIN32
    while (1) {
        if (connect(fd, (struct sockaddr *)addr, namelen) == 0) {
            return 0;
        }

        int err = WSAGetLastError();
        switch (err) {
            case WSAEINPROGRESS:
            case WSAEWOULDBLOCK:
            case WSAEALREADY: {
                return 0;
            }
            case WSAEINTR: {
                continue;
            }
            default: {
                return err;
            }
        }
    }


#else
    int r;
     do {
        errno = 0;
        r = connect(fd, (struct sockaddr *)addr, namelen);
    } while (IS_EINTR(r));

    // connect() can return -1 with an errno of 0.
    // the errno is the correct one in that case.
    if (r == -1 && errno != 0) {
        if (errno == EINPROGRESS) {
            return 0;
        }

        return errno;
    }

    return 0;
#endif
}

#ifdef _WIN32

static int convert_null_addr(const struct sockaddr_storage *addr, struct sockaddr_storage* result) {
    // 1. check that all addrinfo results are 0.0.0.0 or ::
    if (addr->ss_family == AF_INET) {
        struct sockaddr_in *addr4 = (struct sockaddr_in *) addr;
        if (addr4->sin_addr.s_addr == htonl(INADDR_ANY)) {
            memcpy(result, addr, sizeof(struct sockaddr_in));
            ((struct sockaddr_in *) result)->sin_addr.s_addr = htonl(INADDR_LOOPBACK);
            return 1;
        }
    } else if (addr->ss_family == AF_INET6) {
        struct sockaddr_in6 *addr6 = (struct sockaddr_in6 *) addr;
        if (memcmp(&addr6->sin6_addr, &in6addr_any, sizeof(struct in6_addr)) == 0) {
            memcpy(result, addr, sizeof(struct sockaddr_in6));
            memcpy(&((struct sockaddr_in6 *) result)->sin6_addr, &in6addr_loopback, sizeof(struct in6_addr));
            return 1;
        }
    }
    return 0;
}

static int is_loopback(struct sockaddr_storage *sockaddr) {
    if (sockaddr->ss_family == AF_INET) {
        struct sockaddr_in *addr = (struct sockaddr_in *) sockaddr;
        return addr->sin_addr.s_addr == htonl(INADDR_LOOPBACK);
    } else if (sockaddr->ss_family == AF_INET6) {
        struct sockaddr_in6 *addr = (struct sockaddr_in6 *) sockaddr;
        return memcmp(&addr->sin6_addr, &in6addr_loopback, sizeof(struct in6_addr)) == 0;
    } else {
        return 0;
    }
}
#endif

LIBUS_SOCKET_DESCRIPTOR bsd_create_connect_socket(struct sockaddr_storage *addr, struct sockaddr_storage *local_addr, int options) {
    LIBUS_SOCKET_DESCRIPTOR fd = bsd_create_socket(addr->ss_family, SOCK_STREAM, 0, NULL);
    if (fd == LIBUS_SOCKET_ERROR) {
        return LIBUS_SOCKET_ERROR;
    }

    /* Bind to the requested local address/port before connecting (the
     * `localAddress`/`localPort` connect options). A failure here - typically
     * EADDRINUSE or EADDRNOTAVAIL - fails the connect with that errno. */
    if (local_addr) {
#ifndef _WIN32
        /* Match libuv's uv__tcp_bind: set SO_REUSEADDR so binding the local
         * port succeeds when earlier connections on that port are still in
         * TIME_WAIT. Not set on Windows, where SO_REUSEADDR would allow
         * stealing a port that is actively in use (see libuv win/tcp.c). */
        int on = 1;
        setsockopt(fd, SOL_SOCKET, SO_REUSEADDR, &on, sizeof(on));
#endif
        socklen_t local_len = local_addr->ss_family == AF_INET ? sizeof(struct sockaddr_in) : sizeof(struct sockaddr_in6);
        if (bind(fd, (struct sockaddr *) local_addr, local_len)) {
#ifdef _WIN32
            int bind_err = WSAGetLastError();
            bsd_close_socket(fd);
            WSASetLastError(bind_err);
#else
            int bind_err = errno;
            bsd_close_socket(fd);
            errno = bind_err;
#endif
            return LIBUS_SOCKET_ERROR;
        }
    }

#ifdef _WIN32
    win32_set_nonblocking(fd);

    // On windows we can't connect to the null address directly.
    // To match POSIX behavior, we need to connect to localhost instead.
    struct sockaddr_storage converted;
    if (convert_null_addr(addr, &converted)) {
        addr = &converted;
    }

    // This sets the socket to fail quickly if no connection can be established to localhost,
    // instead of waiting for the default 2 seconds. This is necessary because we always try to connect
    // using IPv6 first, but it's possible that whatever we want to connect to is only listening on IPv4.
    // see https://github.com/libuv/libuv/blob/bf61390769068de603e6deec8e16623efcbe761a/src/win/tcp.c#L806
    TCP_INITIAL_RTO_PARAMETERS retransmit_ioctl;
    DWORD bytes;
    if (is_loopback(addr)) {
        memset(&retransmit_ioctl, 0, sizeof(retransmit_ioctl));
        retransmit_ioctl.Rtt = TCP_INITIAL_RTO_NO_SYN_RETRANSMISSIONS;
        retransmit_ioctl.MaxSynRetransmissions = TCP_INITIAL_RTO_NO_SYN_RETRANSMISSIONS;
        WSAIoctl(fd,
                SIO_TCP_INITIAL_RTO,
                &retransmit_ioctl,
                sizeof(retransmit_ioctl),
                NULL,
                0,
                &bytes,
                NULL,
                NULL);
    }

#endif
    int rc = bsd_do_connect_raw(fd, (struct sockaddr*) addr, addr->ss_family == AF_INET ? sizeof(struct sockaddr_in) : sizeof(struct sockaddr_in6));

    if (rc != 0) {
        bsd_close_socket(fd);
#ifdef _WIN32
        /* bsd_do_connect_raw returned the WSA error; re-arm it so the Rust
         * caller's WSAGetLastError() observes the connect failure rather than
         * whatever closesocket() left behind. */
        WSASetLastError(rc);
#endif
        return LIBUS_SOCKET_ERROR;
    }
    return fd;
}

static LIBUS_SOCKET_DESCRIPTOR internal_bsd_create_connect_socket_unix(const char *server_path, size_t len, int options, struct sockaddr_un* server_address, const size_t addrlen) {
    LIBUS_SOCKET_DESCRIPTOR fd = bsd_create_socket(AF_UNIX, SOCK_STREAM, 0, NULL);

    if (fd == LIBUS_SOCKET_ERROR) {
        return LIBUS_SOCKET_ERROR;
    }

    win32_set_nonblocking(fd);

    int rc = bsd_do_connect_raw(fd, (struct sockaddr *)server_address, addrlen);
    if (rc != 0) {
        bsd_close_socket(fd);
#ifdef _WIN32
        WSASetLastError(rc);
#endif
        return LIBUS_SOCKET_ERROR;
    }

    return fd;
}

LIBUS_SOCKET_DESCRIPTOR bsd_create_connect_socket_unix(const char *server_path, size_t len, int options) {
    struct sockaddr_un server_address;
    size_t addrlen = 0;
    int dirfd_workaround_for_unix_path_len = -1;
    if (bsd_create_unix_socket_address(server_path, len, &dirfd_workaround_for_unix_path_len, &server_address, &addrlen)) {
        return LIBUS_SOCKET_ERROR;
    }

#if defined(__APPLE__)
    if (dirfd_workaround_for_unix_path_len != -1) {
        if (__pthread_fchdir(dirfd_workaround_for_unix_path_len) != 0) {
            close(dirfd_workaround_for_unix_path_len);
            errno = ENAMETOOLONG;
            return LIBUS_SOCKET_ERROR;
        }
    }
#endif

    LIBUS_SOCKET_DESCRIPTOR fd = internal_bsd_create_connect_socket_unix(server_path, len, options, &server_address, addrlen);

#if defined(__APPLE__)
    if (dirfd_workaround_for_unix_path_len != -1) {
        int saved_errno = errno;
        __pthread_fchdir(-1);
        close(dirfd_workaround_for_unix_path_len);
        errno = saved_errno;
    }
#elif defined(__linux__)
    if (dirfd_workaround_for_unix_path_len != -1) {
        close(dirfd_workaround_for_unix_path_len);
    }
#endif

    return fd;
}
