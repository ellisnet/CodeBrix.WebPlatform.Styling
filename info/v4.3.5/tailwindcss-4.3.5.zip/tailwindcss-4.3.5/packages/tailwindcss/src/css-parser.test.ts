import { describe, expect, it } from 'vitest'
import * as CSS from './css-parser'

const css = String.raw

describe.each(['Unix', 'Windows'])('Line endings: %s', (lineEndings) => {
  function parse(string: string) {
    return CSS.parse(string.replaceAll(/\r?\n/g, lineEndings === 'Windows' ? '\r\n' : '\n'))
  }

  function parseWithLoc(string: string) {
    return CSS.parse(string.replaceAll(/\r?\n/g, lineEndings === 'Windows' ? '\r\n' : '\n'), {
      from: 'input.css',
    })
  }

  describe('comments', () => {
    it('should parse a comment and ignore it', () => {
      expect(
        parse(css`
          /*Hello, world!*/
        `),
      ).toEqual([])
    })

    it('should parse a comment with an escaped ending and ignore it', () => {
      expect(
        parse(css`
          /*Hello, \*\/ world!*/
        `),
      ).toEqual([])
    })

    it('should end a comment at `*/` even when it is preceded by a `\\`', () => {
      expect(
        parse(css`
          /* C:\temp\*/
          .foo {
            color: red;
          }
        `),
      ).toEqual([
        {
          kind: 'rule',
          selector: '.foo',
          nodes: [{ kind: 'declaration', property: 'color', value: 'red', important: false }],
        },
      ])
    })

    it('should parse a comment inside of a selector and ignore it', () => {
      expect(
        parse(css`
          .foo {
            /*Example comment*/
          }
        `),
      ).toEqual([
        {
          kind: 'rule',
          selector: '.foo',
          nodes: [],
        },
      ])
    })

    it('should remove comments in between selectors while maintaining the correct whitespace', () => {
      expect(
        parse(css`
          .foo/*.bar*/.baz {
          }
          .foo/*.bar*//*.baz*/.qux
          {
          }
          .foo/*.bar*/ /*.baz*/.qux {
            /*        ^ whitespace */
          }
          .foo /*.bar*/.baz {
            /*^ whitespace */
          }
          .foo/*.bar*/ .baz {
            /*        ^ whitespace */
          }
          .foo/*.bar*/
          .baz {
          }
        `),
      ).toEqual([
        { kind: 'rule', selector: '.foo.baz', nodes: [] },
        { kind: 'rule', selector: '.foo.qux', nodes: [] },
        { kind: 'rule', selector: '.foo .qux', nodes: [] },
        { kind: 'rule', selector: '.foo .baz', nodes: [] },
        { kind: 'rule', selector: '.foo .baz', nodes: [] },
        { kind: 'rule', selector: '.foo .baz', nodes: [] },
      ])
    })

    it('should collect license comments', () => {
      expect(
        parse(css`
          /*! License #1 */
          /*!
            * License #2
            */
        `),
      ).toEqual([
        { kind: 'comment', value: '! License #1 ' },
        {
          kind: 'comment',
          value: `!
            * License #2
            `.replaceAll(/\r?\n/g, lineEndings === 'Windows' ? '\r\n' : '\n'),
        },
      ])
    })

    it('should hoist all license comments', () => {
      expect(
        parse(css`
          /*! License #1 */
          .foo {
            color: red; /*! License #1.5 */
          }
          /*! License #2 */
          .bar {
            /*! License #2.5 */
            color: blue;
          }
          /*! License #3 */
        `),
      ).toEqual([
        { kind: 'comment', value: '! License #1 ' },
        { kind: 'comment', value: '! License #1.5 ' },
        { kind: 'comment', value: '! License #2 ' },
        { kind: 'comment', value: '! License #2.5 ' },
        { kind: 'comment', value: '! License #3 ' },
        {
          kind: 'rule',
          selector: '.foo',
          nodes: [{ kind: 'declaration', property: 'color', value: 'red', important: false }],
        },
        {
          kind: 'rule',
          selector: '.bar',
          nodes: [{ kind: 'declaration', property: 'color', value: 'blue', important: false }],
        },
      ])
    })

    it('should handle comments before element selectors', () => {
      expect(
        parse(css`
          .dark /* comment */p {
            color: black;
          }
        `),
      ).toEqual([
        {
          kind: 'rule',
          selector: '.dark p',
          nodes: [
            {
              kind: 'declaration',
              property: 'color',
              value: 'black',
              important: false,
            },
          ],
        },
      ])
    })
  })

  describe('declarations', () => {
    it('should parse a simple declaration', () => {
      expect(
        parse(css`
          color: red;
        `),
      ).toEqual([{ kind: 'declaration', property: 'color', value: 'red', important: false }])
    })

    it('should parse a declaration with a missing ending `;`', () => {
      expect(parse('color: red')).toEqual([
        { kind: 'declaration', property: 'color', value: 'red', important: false },
      ])
    })

    it('should parse a declaration with a missing ending `;` and a trailing newline', () => {
      expect(parse('color: red\n')).toEqual([
        { kind: 'declaration', property: 'color', value: 'red', important: false },
      ])
    })

    it('should parse a declaration with a missing ending `;` and `!important`', () => {
      expect(parse('color: red !important')).toEqual([
        { kind: 'declaration', property: 'color', value: 'red', important: true },
      ])
    })

    it('should parse multiple declarations where the last one has a missing ending `;`', () => {
      expect(parse('a: 1; b: 2')).toEqual([
        { kind: 'declaration', property: 'a', value: '1', important: false },
        { kind: 'declaration', property: 'b', value: '2', important: false },
      ])
    })

    it('should parse a declaration with a missing ending `;` after a custom property', () => {
      expect(parse('--a: 1;\ncolor: red')).toEqual([
        { kind: 'declaration', property: '--a', value: '1', important: false },
        { kind: 'declaration', property: 'color', value: 'red', important: false },
      ])
    })

    it('should not parse a declaration with unbalanced brackets and a missing ending `;`', () => {
      expect(parse('color: rgb(1, 2')).toEqual([])
    })

    it('should parse declarations with strings', () => {
      expect(
        parse(css`
          content: 'Hello, world!';
        `),
      ).toEqual([
        { kind: 'declaration', property: 'content', value: "'Hello, world!'", important: false },
      ])
    })

    it('should parse declarations with nested strings', () => {
      expect(
        parse(css`
          content: 'Good, "monday", morning!';
        `),
      ).toEqual([
        {
          kind: 'declaration',
          property: 'content',
          value: `'Good, "monday", morning!'`,
          important: false,
        },
      ])
    })

    it('should parse declarations with nested strings that are not balanced', () => {
      expect(
        parse(css`
          content: "It's a beautiful day!";
        `),
      ).toEqual([
        {
          kind: 'declaration',
          property: 'content',
          value: `"It's a beautiful day!"`,
          important: false,
        },
      ])
    })

    it('should parse declarations with strings and escaped string endings', () => {
      expect(
        parse(css`
          content: 'These are not the end "\' of the string';
        `),
      ).toEqual([
        {
          kind: 'declaration',
          property: 'content',
          value: `'These are not the end "\\' of the string'`,
          important: false,
        },
      ])
    })

    describe('important', () => {
      it('should parse declarations with `!important`', () => {
        expect(
          parse(css`
            width: 123px !important;
          `),
        ).toEqual([
          {
            kind: 'declaration',
            property: 'width',
            value: '123px',
            important: true,
          },
        ])
      })

      it('should parse declarations with `!important` when there is a trailing comment', () => {
        expect(
          parse(css`
            width: 123px !important /* Very important */;
          `),
        ).toEqual([
          {
            kind: 'declaration',
            property: 'width',
            value: '123px',
            important: true,
          },
        ])
      })

      it('should parse custom properties with `!important` when there is a trailing comment', () => {
        expect(
          parse(css`
            --foo: red !important /* Very important */;
            --bar: red /* not important */;
          `),
        ).toEqual([
          {
            kind: 'declaration',
            property: '--foo',
            value: 'red',
            important: true,
          },
          {
            kind: 'declaration',
            property: '--bar',
            value: 'red /* not important */',
            important: false,
          },
        ])
      })

      it('should not treat `!important` inside of a comment as the important flag', () => {
        expect(
          parse(css`
            --foo: red /* !important /* example */;
            --bar: red /* example */ !important /* example */ /* example */;
            --baz: '/* example' !important;
            --quux: red !important
              /* example */;
          `),
        ).toEqual([
          {
            kind: 'declaration',
            property: '--foo',
            value: 'red /* !important /* example */',
            important: false,
          },
          {
            kind: 'declaration',
            property: '--bar',
            // The comments after `!important` are dropped, together with the
            // flag. The value has no place to keep them, and they don't change
            // its meaning.
            value: 'red /* example */',
            important: true,
          },
          {
            kind: 'declaration',
            property: '--baz',
            value: "'/* example'",
            important: true,
          },
          {
            kind: 'declaration',
            property: '--quux',
            value: 'red',
            important: true,
          },
        ])
      })

      it('should not treat `!important` inside of a value as the important flag', () => {
        expect(
          parse(css`
            content: 'a !important b';
            background: url('x!important.png') !important;
            --foo: '!important';
          `),
        ).toEqual([
          {
            kind: 'declaration',
            property: 'content',
            value: "'a !important b'",
            important: false,
          },
          {
            kind: 'declaration',
            property: 'background',
            value: "url('x!important.png')",
            important: true,
          },
          {
            kind: 'declaration',
            property: '--foo',
            value: "'!important'",
            important: false,
          },
        ])
      })

      it('should keep an escaped whitespace at the end of the value', () => {
        expect(
          parse(
            // prettier-ignore
            css`
            content: a\ ;
            font-family: a\ !important;
            --foo: a\ ;
            --bar: a\ !important;
            --baz: a\\ !important;
          `,
          ),
        ).toEqual([
          { kind: 'declaration', property: 'content', value: 'a\\ ', important: false },
          { kind: 'declaration', property: 'font-family', value: 'a\\ ', important: true },
          { kind: 'declaration', property: '--foo', value: 'a\\ ', important: false },
          { kind: 'declaration', property: '--bar', value: 'a\\ ', important: true },
          // An escaped backslash does not escape the whitespace after it.
          { kind: 'declaration', property: '--baz', value: 'a\\\\', important: true },
        ])
      })

      it('should not treat an escaped `!` as the important flag', () => {
        expect(
          parse(
            // prettier-ignore
            css`
            content: \!important;
            --foo: red\!important;
            --bar: red\\!important;
          `,
          ),
        ).toEqual([
          { kind: 'declaration', property: 'content', value: '\\!important', important: false },
          { kind: 'declaration', property: '--foo', value: 'red\\!important', important: false },
          // An escaped backslash does not escape the `!` after it.
          { kind: 'declaration', property: '--bar', value: 'red\\\\', important: true },
        ])
      })
    })

    describe('Custom properties', () => {
      it('should parse a custom property', () => {
        expect(
          parse(css`
            --foo: bar;
          `),
        ).toEqual([{ kind: 'declaration', property: '--foo', value: 'bar', important: false }])
      })

      it('should parse a minified custom property', () => {
        expect(parse(':root{--foo:bar;}')).toEqual([
          {
            kind: 'rule',
            selector: ':root',
            nodes: [
              {
                kind: 'declaration',
                property: '--foo',
                value: 'bar',
                important: false,
              },
            ],
          },
        ])
      })

      it('should parse a minified custom property with no semicolon ', () => {
        expect(parse(':root{--foo:bar}')).toEqual([
          {
            kind: 'rule',
            selector: ':root',
            nodes: [
              {
                kind: 'declaration',
                property: '--foo',
                value: 'bar',
                important: false,
              },
            ],
          },
        ])
      })

      it('should parse a custom property with a missing ending `;`', () => {
        expect(
          parse(`
            --foo: bar
          `),
        ).toEqual([{ kind: 'declaration', property: '--foo', value: 'bar', important: false }])
      })

      it('should parse a custom property with a missing ending `;` and `!important`', () => {
        expect(
          parse(`
            --foo: bar !important
          `),
        ).toEqual([{ kind: 'declaration', property: '--foo', value: 'bar', important: true }])
      })

      it('should parse a custom property with a missing ending `;` at the end of the input', () => {
        expect(parse('--foo: bar')).toEqual([
          { kind: 'declaration', property: '--foo', value: 'bar', important: false },
        ])
        expect(parse('--foo: bar !important')).toEqual([
          { kind: 'declaration', property: '--foo', value: 'bar', important: true },
        ])
        expect(parse('--foo: var(--bar)')).toEqual([
          { kind: 'declaration', property: '--foo', value: 'var(--bar)', important: false },
        ])
        expect(parse("--foo: 'bar'")).toEqual([
          { kind: 'declaration', property: '--foo', value: "'bar'", important: false },
        ])
        expect(parse('--foo: {}')).toEqual([
          { kind: 'declaration', property: '--foo', value: '{}', important: false },
        ])
        expect(parse('--foo: bar /* baz */')).toEqual([
          { kind: 'declaration', property: '--foo', value: 'bar /* baz */', important: false },
        ])
        expect(parse('--foo: bar;\n--baz: rgb(0 0 0)')).toEqual([
          { kind: 'declaration', property: '--foo', value: 'bar', important: false },
          { kind: 'declaration', property: '--baz', value: 'rgb(0 0 0)', important: false },
        ])
      })

      it('should parse a custom property with an unclosed bracket at the end of the input', () => {
        expect(parse('--foo: [bar')).toEqual([
          { kind: 'declaration', property: '--foo', value: '[bar', important: false },
        ])
        expect(parse('color: red; --foo: (bar')).toEqual([
          { kind: 'declaration', property: 'color', value: 'red', important: false },
          { kind: 'declaration', property: '--foo', value: '(bar', important: false },
        ])
      })

      it('should parse a custom property with an embedded programming language', () => {
        expect(
          parse(css`
            --foo: if(x > 5) this.width = 10;
          `),
        ).toEqual([
          {
            kind: 'declaration',
            property: '--foo',
            value: 'if(x > 5) this.width = 10',
            important: false,
          },
        ])
      })

      it('should parse a custom property with an empty block as the value', () => {
        expect(parse('--foo: {};')).toEqual([
          {
            kind: 'declaration',
            property: '--foo',
            value: '{}',
            important: false,
          },
        ])
      })

      it('should parse a custom property with an empty value', () => {
        expect(parse('--foo:;')).toEqual([
          {
            kind: 'declaration',
            property: '--foo',
            value: '',
            important: false,
          },
        ])
      })

      it('should parse a custom property with a space value', () => {
        expect(parse('--foo: ;')).toEqual([
          {
            kind: 'declaration',
            property: '--foo',
            value: '',
            important: false,
          },
        ])
      })

      it('should parse a custom property with a block including nested "css"', () => {
        expect(
          parse(css`
            --foo: {
              background-color: red;
              /* A comment */
              content: 'Hello, world!';
            };
          `),
        ).toEqual([
          {
            kind: 'declaration',
            property: '--foo',
            value: `{
              background-color: red;
              /* A comment */
              content: 'Hello, world!';
            }`.replaceAll(/\r?\n/g, lineEndings === 'Windows' ? '\r\n' : '\n'),
            important: false,
          },
        ])
      })

      it('should parse a custom property with a block including nested "css" and comments with end characters inside them', () => {
        expect(
          parse(css`
            --foo: {
              background-color: red;
              /* A comment ; */
              content: 'Hello, world!';
            };
            --bar: {
              background-color: red;
              /* A comment } */
              content: 'Hello, world!';
            };
          `),
        ).toEqual([
          {
            kind: 'declaration',
            property: '--foo',
            value: `{
              background-color: red;
              /* A comment ; */
              content: 'Hello, world!';
            }`.replaceAll(/\r?\n/g, lineEndings === 'Windows' ? '\r\n' : '\n'),
            important: false,
          },
          {
            kind: 'declaration',
            property: '--bar',
            value: `{
              background-color: red;
              /* A comment } */
              content: 'Hello, world!';
            }`.replaceAll(/\r?\n/g, lineEndings === 'Windows' ? '\r\n' : '\n'),
            important: false,
          },
        ])
      })

      it('should parse a custom property with escaped characters in the value', () => {
        expect(
          parse(css`
            --foo: This is not the end \;, but this is;
          `),
        ).toEqual([
          {
            kind: 'declaration',
            property: '--foo',
            value: 'This is not the end \\;, but this is',
            important: false,
          },
        ])
      })

      it('should parse a custom property with escaped characters inside a comment in the value', () => {
        expect(
          parse(css`
            --foo: /* This is not the end \; this is also not the end ; */ but this is;
          `),
        ).toEqual([
          {
            kind: 'declaration',
            property: '--foo',
            value: '/* This is not the end \\; this is also not the end ; */ but this is',
            important: false,
          },
        ])
      })

      it('should end a comment in a custom property at `*/` even when it is preceded by a `\\`', () => {
        expect(
          parse(css`
            --foo: /* C:\temp\*/ bar;
            --bar: /* baz */ qux;
          `),
        ).toEqual([
          {
            kind: 'declaration',
            property: '--foo',
            value: '/* C:\\temp\\*/ bar',
            important: false,
          },
          {
            kind: 'declaration',
            property: '--bar',
            value: '/* baz */ qux',
            important: false,
          },
        ])
      })

      it('should parse empty custom properties', () => {
        expect(
          parse(css`
            --foo: ;
          `),
        ).toEqual([{ kind: 'declaration', property: '--foo', value: '', important: false }])
      })

      it('should parse custom properties with `!important`', () => {
        expect(
          parse(css`
            --foo: bar !important;
          `),
        ).toEqual([{ kind: 'declaration', property: '--foo', value: 'bar', important: true }])
      })

      it('should parse custom properties with data URL value', () => {
        expect(
          parse(css`
            --foo: 'data:text/plain;base64,SGVsbG8sIFdvcmxkIQ==';
          `),
        ).toEqual([
          {
            kind: 'declaration',
            property: '--foo',
            value: "'data:text/plain;base64,SGVsbG8sIFdvcmxkIQ=='",
            important: false,
          },
        ])
      })
    })

    it('should parse multiple declarations', () => {
      expect(
        parse(css`
          color: red;
          background-color: blue;
        `),
      ).toEqual([
        { kind: 'declaration', property: 'color', value: 'red', important: false },
        { kind: 'declaration', property: 'background-color', value: 'blue', important: false },
      ])
    })

    /**
     *
     */
    it('should correctly parse comments with `:` inside of them', () => {
      expect(
        parse(css`
          color/* color: #f00; */: red;
          font-weight:/* font-size: 12px */ bold;

          .foo {
            background-color/* background-color: #f00; */: red;
          }
        `),
      ).toEqual([
        { kind: 'declaration', property: 'color', value: 'red', important: false },
        { kind: 'declaration', property: 'font-weight', value: 'bold', important: false },
        {
          kind: 'rule',
          selector: '.foo',
          nodes: [
            {
              kind: 'declaration',
              property: 'background-color',
              value: 'red',
              important: false,
            },
          ],
        },
      ])
    })

    it('should parse multi-line declarations', () => {
      expect(
        parse(css`
          .foo {
            grid-template-areas:
              'header header header'
              'sidebar main main'
              'footer footer footer';
          }
        `),
      ).toEqual([
        {
          kind: 'rule',
          selector: '.foo',
          nodes: [
            {
              kind: 'declaration',
              property: 'grid-template-areas',
              value: "'header header header' 'sidebar main main' 'footer footer footer'",
              important: false,
            },
          ],
        },
      ])
    })

    it('should parse url(…) without quotes and special characters such as `;`, `{}`, and `[]`', () => {
      expect(
        parse(css`
          .foo {
            /* ';' should be valid inside the 'url(…)' function */
            background: url(data:image/png;base64,abc==);

            /* '{', '}', '[' and ']' should be valid inside the 'url(…)' function */
            /* '{' and '}' should not start a new block (nesting) */
            background: url(https://example-image-search.org?q={query;limit=5}&ids=[1,2,3]);

            /* '{' and '}' don't need to be balanced */
            background: url(https://example-image-search.org?curlies=}});

            /* '(' and ')' are not valid, unless we are in a string with quotes */
            background: url('https://example-image-search.org?q={query;limit=5}&ids=[1,2,3]&format=(png|jpg)');
          }
        `),
      ).toEqual([
        {
          kind: 'rule',
          selector: '.foo',
          nodes: [
            {
              kind: 'declaration',
              property: 'background',
              value: 'url(data:image/png;base64,abc==)',
              important: false,
            },
            {
              kind: 'declaration',
              property: 'background',
              value: 'url(https://example-image-search.org?q={query;limit=5}&ids=[1,2,3])',
              important: false,
            },
            {
              kind: 'declaration',
              property: 'background',
              value: 'url(https://example-image-search.org?curlies=}})',
              important: false,
            },
            {
              kind: 'declaration',
              property: 'background',
              value:
                "url('https://example-image-search.org?q={query;limit=5}&ids=[1,2,3]&format=(png|jpg)')",
              important: false,
            },
          ],
        },
      ])
    })
  })

  describe('selectors', () => {
    it('should parse a simple selector', () => {
      expect(
        parse(css`
          .foo {
          }
        `),
      ).toEqual([{ kind: 'rule', selector: '.foo', nodes: [] }])
    })

    it('should parse selectors with escaped characters', () => {
      expect(
        parse(css`
          .hover\:foo:hover {
          }
          .\32 xl\:foo {
          }
        `),
      ).toEqual([
        { kind: 'rule', selector: '.hover\\:foo:hover', nodes: [] },
        { kind: 'rule', selector: '.\\32 xl\\:foo', nodes: [] },
      ])
    })

    it('should parse multiple simple selectors', () => {
      expect(
        parse(css`
          .foo,
          .bar {
          }
        `),
      ).toEqual([{ kind: 'rule', selector: '.foo, .bar', nodes: [] }])
    })

    it('should parse multiple declarations inside of a selector', () => {
      expect(
        parse(css`
          .foo {
            color: red;
            font-size: 16px;
          }
        `),
      ).toEqual([
        {
          kind: 'rule',
          selector: '.foo',
          nodes: [
            { kind: 'declaration', property: 'color', value: 'red', important: false },
            { kind: 'declaration', property: 'font-size', value: '16px', important: false },
          ],
        },
      ])
    })

    it('should parse rules with declarations that end with a missing `;`', () => {
      expect(
        parse(`
          .foo {
            color: red;
            font-size: 16px
          }
        `),
      ).toEqual([
        {
          kind: 'rule',
          selector: '.foo',
          nodes: [
            { kind: 'declaration', property: 'color', value: 'red', important: false },
            { kind: 'declaration', property: 'font-size', value: '16px', important: false },
          ],
        },
      ])
    })

    it('should parse rules with declarations that end with a missing `;` and `!important`', () => {
      expect(
        parse(`
          .foo {
            color: red;
            font-size: 16px !important
          }
        `),
      ).toEqual([
        {
          kind: 'rule',
          selector: '.foo',
          nodes: [
            { kind: 'declaration', property: 'color', value: 'red', important: false },
            { kind: 'declaration', property: 'font-size', value: '16px', important: true },
          ],
        },
      ])
    })

    it('should parse a multi-line selector', () => {
      expect(parse(['.foo,', '.bar,', '.baz', '{', 'color:red;', '}'].join('\n'))).toEqual([
        {
          kind: 'rule',
          selector: '.foo, .bar, .baz',
          nodes: [{ kind: 'declaration', property: 'color', value: 'red', important: false }],
        },
      ])
    })

    it('should parse a multi-line selector and preserves important whitespace', () => {
      expect(
        parse(['.foo,', '.bar,', '.baz\t\n \n .qux', '{', 'color:red;', '}'].join('\n')),
      ).toEqual([
        {
          kind: 'rule',
          selector: '.foo, .bar, .baz .qux',
          nodes: [{ kind: 'declaration', property: 'color', value: 'red', important: false }],
        },
      ])
    })
  })

  describe('at-rules', () => {
    it('should parse an at-rule without a block', () => {
      expect(
        parse(css`
          @charset "UTF-8";
        `),
      ).toEqual([{ kind: 'at-rule', name: '@charset', params: '"UTF-8"', nodes: [] }])
    })

    it.each([
      [' '], // space
      ['  '], // multiple spaces
      ['\t'], // tab
      [' \t'], // space + tab
      ['\t '], // tab + space
      ['\t\t'], // multiple tabs
      ['\n'], // newline
      [' \n'], // space + newline
      ['\n '], // newline + space
      ['\n\n'], // multiple newlines
      ['\r\n'], // windows newline
      [' \r\n'], // space + windows newline
      ['\r\n '], // windows newline + space
    ])('should parse an at-rule with whitespace %s in the params', (whitespace) => {
      expect(parse(`@apply${whitespace}bg-red-500;`)).toEqual([
        { kind: 'at-rule', name: '@apply', params: 'bg-red-500', nodes: [] },
      ])
    })

    it('should parse an at-rule without a block or semicolon', () => {
      expect(
        parse(`
          @tailwind utilities
        `),
      ).toEqual([{ kind: 'at-rule', name: '@tailwind', params: 'utilities', nodes: [] }])
    })

    it("should parse an at-rule without a block or semicolon when it's the last rule in a block", () => {
      expect(
        parse(`
          @layer utilities {
            @tailwind utilities
          }
        `),
      ).toEqual([
        {
          kind: 'at-rule',
          name: '@layer',
          params: 'utilities',
          nodes: [{ kind: 'at-rule', name: '@tailwind', params: 'utilities', nodes: [] }],
        },
      ])
    })

    it('should parse a nested at-rule without a block', () => {
      expect(
        parse(css`
          @layer utilities {
            @charset "UTF-8";
          }

          .foo {
            @apply font-bold hover:text-red-500;
          }
        `),
      ).toEqual([
        {
          kind: 'at-rule',
          name: '@layer',
          params: 'utilities',
          nodes: [{ kind: 'at-rule', name: '@charset', params: '"UTF-8"', nodes: [] }],
        },
        {
          kind: 'rule',
          selector: '.foo',
          nodes: [
            { kind: 'at-rule', name: '@apply', params: 'font-bold hover:text-red-500', nodes: [] },
          ],
        },
      ])
    })

    it('should parse custom at-rules without a block', () => {
      expect(
        parse(css`
          @tailwind;
          @tailwind base;
        `),
      ).toEqual([
        { kind: 'at-rule', name: '@tailwind', params: '', nodes: [] },
        { kind: 'at-rule', name: '@tailwind', params: 'base', nodes: [] },
      ])
    })

    it('should parse (nested) media queries', () => {
      expect(
        parse(css`
          @media (width >= 600px) {
            .foo {
              color: red;
              @media (width >= 800px) {
                color: blue;
              }
              @media (width >= 1000px) {
                color: green;
              }
            }
          }
        `),
      ).toEqual([
        {
          kind: 'at-rule',
          name: '@media',
          params: '(width >= 600px)',
          nodes: [
            {
              kind: 'rule',
              selector: '.foo',
              nodes: [
                { kind: 'declaration', property: 'color', value: 'red', important: false },
                {
                  kind: 'at-rule',
                  name: '@media',
                  params: '(width >= 800px)',
                  nodes: [
                    { kind: 'declaration', property: 'color', value: 'blue', important: false },
                  ],
                },
                {
                  kind: 'at-rule',
                  name: '@media',
                  params: '(width >= 1000px)',
                  nodes: [
                    { kind: 'declaration', property: 'color', value: 'green', important: false },
                  ],
                },
              ],
            },
          ],
        },
      ])
    })

    it('should parse at-rules that span multiple lines', () => {
      expect(
        parse(css`
          .foo {
            @apply hover:text-red-100
                   sm:hover:text-red-200
                   md:hover:text-red-300
                   lg:hover:text-red-400
                   xl:hover:text-red-500;
          }
        `),
      ).toEqual([
        {
          kind: 'rule',
          nodes: [
            {
              kind: 'at-rule',
              name: '@apply',
              params:
                'hover:text-red-100 sm:hover:text-red-200 md:hover:text-red-300 lg:hover:text-red-400 xl:hover:text-red-500',
              nodes: [],
            },
          ],
          selector: '.foo',
        },
      ])
    })
  })

  describe('nesting', () => {
    it('should parse nested rules', () => {
      expect(
        parse(css`
          .foo {
            .bar {
              .baz {
                color: red;
              }
            }
          }
        `),
      ).toEqual([
        {
          kind: 'rule',
          selector: '.foo',
          nodes: [
            {
              kind: 'rule',
              selector: '.bar',
              nodes: [
                {
                  kind: 'rule',
                  selector: '.baz',
                  nodes: [
                    { kind: 'declaration', property: 'color', value: 'red', important: false },
                  ],
                },
              ],
            },
          ],
        },
      ])
    })

    it('should parse nested selector with `&`', () => {
      expect(
        parse(css`
          .foo {
            color: red;

            &:hover {
              color: blue;
            }
          }
        `),
      ).toEqual([
        {
          kind: 'rule',
          selector: '.foo',
          nodes: [
            { kind: 'declaration', property: 'color', value: 'red', important: false },
            {
              kind: 'rule',
              selector: '&:hover',
              nodes: [{ kind: 'declaration', property: 'color', value: 'blue', important: false }],
            },
          ],
        },
      ])
    })

    it('should parse nested sibling selectors', () => {
      expect(
        parse(css`
          .foo {
            .bar {
              color: red;
            }

            .baz {
              color: blue;
            }
          }
        `),
      ).toEqual([
        {
          kind: 'rule',
          selector: '.foo',
          nodes: [
            {
              kind: 'rule',
              selector: '.bar',
              nodes: [{ kind: 'declaration', property: 'color', value: 'red', important: false }],
            },
            {
              kind: 'rule',
              selector: '.baz',
              nodes: [{ kind: 'declaration', property: 'color', value: 'blue', important: false }],
            },
          ],
        },
      ])
    })

    it('should parse nested sibling selectors and sibling declarations', () => {
      expect(
        parse(css`
          .foo {
            font-weight: bold;
            text-declaration-line: underline;

            .bar {
              color: red;
            }

            --in-between: 1;

            .baz {
              color: blue;
            }

            --at-the-end: 2;
          }
        `),
      ).toEqual([
        {
          kind: 'rule',
          selector: '.foo',
          nodes: [
            { kind: 'declaration', property: 'font-weight', value: 'bold', important: false },
            {
              kind: 'declaration',
              property: 'text-declaration-line',
              value: 'underline',
              important: false,
            },
            {
              kind: 'rule',
              selector: '.bar',
              nodes: [{ kind: 'declaration', property: 'color', value: 'red', important: false }],
            },
            { kind: 'declaration', property: '--in-between', value: '1', important: false },
            {
              kind: 'rule',
              selector: '.baz',
              nodes: [{ kind: 'declaration', property: 'color', value: 'blue', important: false }],
            },
            { kind: 'declaration', property: '--at-the-end', value: '2', important: false },
          ],
        },
      ])
    })
  })

  describe('complex', () => {
    it('should parse complex examples', () => {
      expect(
        parse(css`
          @custom \{ {
            foo: bar;
          }
        `),
      ).toEqual([
        {
          kind: 'at-rule',
          name: '@custom',
          params: '\\{',
          nodes: [{ kind: 'declaration', property: 'foo', value: 'bar', important: false }],
        },
      ])
    })

    it('should parse minified nested CSS', () => {
      expect(
        parse('.foo{color:red;@media(width>=600px){.bar{color:blue;font-weight:bold}}}'),
      ).toEqual([
        {
          kind: 'rule',
          selector: '.foo',
          nodes: [
            { kind: 'declaration', property: 'color', value: 'red', important: false },
            {
              kind: 'at-rule',
              name: '@media',
              params: '(width>=600px)',
              nodes: [
                {
                  kind: 'rule',
                  selector: '.bar',
                  nodes: [
                    { kind: 'declaration', property: 'color', value: 'blue', important: false },
                    {
                      kind: 'declaration',
                      property: 'font-weight',
                      value: 'bold',
                      important: false,
                    },
                  ],
                },
              ],
            },
          ],
        },
      ])
    })

    it('should ignore everything inside of comments', () => {
      expect(
        parse(css`
          .foo:has(.bar /* instead \*\/ of .baz { */) {
            color: red;
          }
        `),
      ).toEqual([
        {
          kind: 'rule',
          selector: '.foo:has(.bar )',
          nodes: [{ kind: 'declaration', property: 'color', value: 'red', important: false }],
        },
      ])
    })

    it('should ignore consecutive semicolons', () => {
      expect(parse(';;;')).toEqual([])
    })

    it('should ignore semicolons after an at-rule with a body', () => {
      expect(parse('@plugin "foo" {} ;')).toEqual([
        {
          kind: 'at-rule',
          name: '@plugin',
          params: '"foo"',
          nodes: [],
        },
      ])
    })

    it('should ignore consecutive semicolons a declaration', () => {
      expect(parse('.foo { color: red;;; }')).toEqual([
        {
          kind: 'rule',
          selector: '.foo',
          nodes: [
            {
              kind: 'declaration',
              property: 'color',
              value: 'red',
              important: false,
            },
          ],
        },
      ])
    })
  })

  describe('CDO and CDC tokens', () => {
    it('should ignore `<!--` and `-->` on their own', () => {
      expect(parse('<!--')).toEqual([])
      expect(parse('-->')).toEqual([])
      expect(parse('<!-- -->')).toEqual([])
    })

    it('should ignore `<!--` and `-->` around rules', () => {
      expect(
        parse(css`
          <!--
          a {
            color: red;
          }
          -->
          b {
            color: blue;
          }
          -->
        `),
      ).toEqual([
        {
          kind: 'rule',
          selector: 'a',
          nodes: [{ kind: 'declaration', property: 'color', value: 'red', important: false }],
        },
        {
          kind: 'rule',
          selector: 'b',
          nodes: [{ kind: 'declaration', property: 'color', value: 'blue', important: false }],
        },
      ])
    })

    it('should ignore `<!--` and `-->` without whitespace around them', () => {
      expect(parse('<!--a{color:red}-->b{color:blue}')).toEqual([
        {
          kind: 'rule',
          selector: 'a',
          nodes: [{ kind: 'declaration', property: 'color', value: 'red', important: false }],
        },
        {
          kind: 'rule',
          selector: 'b',
          nodes: [{ kind: 'declaration', property: 'color', value: 'blue', important: false }],
        },
      ])
    })

    it('should ignore `<!--` and `-->` next to at-rules and declarations', () => {
      expect(parse('<!-- @charset "UTF-8"; --> @media print { a { color: red } }')).toEqual([
        { kind: 'at-rule', name: '@charset', params: '"UTF-8"', nodes: [] },
        {
          kind: 'at-rule',
          name: '@media',
          params: 'print',
          nodes: [
            {
              kind: 'rule',
              selector: 'a',
              nodes: [{ kind: 'declaration', property: 'color', value: 'red', important: false }],
            },
          ],
        },
      ])
      expect(parse('--foo: bar; --> --baz: qux;')).toEqual([
        { kind: 'declaration', property: '--foo', value: 'bar', important: false },
        { kind: 'declaration', property: '--baz', value: 'qux', important: false },
      ])
    })

    it('should keep `<!--` and `-->` inside of a selector', () => {
      expect(parse('a <!-- b{color:blue}')).toEqual([
        {
          kind: 'rule',
          selector: 'a <!-- b',
          nodes: [{ kind: 'declaration', property: 'color', value: 'blue', important: false }],
        },
      ])
      expect(parse('a --> b{color:blue}')).toEqual([
        {
          kind: 'rule',
          selector: 'a --> b',
          nodes: [{ kind: 'declaration', property: 'color', value: 'blue', important: false }],
        },
      ])
    })

    it('should keep `<!--` and `-->` inside of a custom property', () => {
      expect(parse('--foo: <!-- -->;')).toEqual([
        { kind: 'declaration', property: '--foo', value: '<!-- -->', important: false },
      ])
    })

    it('should not treat a name that starts with `---` as `-->`', () => {
      expect(parse('---a: b;')).toEqual([
        { kind: 'declaration', property: '---a', value: 'b', important: false },
      ])
    })

    it('should only ignore `<!--` and `-->` at the top level', () => {
      expect(() => parse('a { --> }')).toThrow('Invalid custom property, expected a value')
    })
  })

  describe('errors', () => {
    it('should error when curly brackets are unbalanced (opening)', () => {
      expect(() =>
        parse(`
          .foo {
            color: red;
          }

          .bar
            /* ^ Missing opening { */
            color: blue;
          }
        `),
      ).toThrowErrorMatchingInlineSnapshot(`[CssSyntaxError: Missing opening {]`)

      expect(() =>
        parseWithLoc(`
          .foo {
            color: red;
          }

          .bar
            /* ^ Missing opening { */
            color: blue;
          }
        `),
      ).toThrowErrorMatchingInlineSnapshot(`[CssSyntaxError: input.css:9:11: Missing opening {]`)
    })

    it('should error when curly brackets are unbalanced (closing)', () => {
      expect(() =>
        parse(`
          .foo {
            color: red;
          }

          .bar {
            color: blue;

       /* ^ Missing closing } */
        `),
      ).toThrowErrorMatchingInlineSnapshot(`[CssSyntaxError: Missing closing } at .bar]`)

      expect(() =>
        parseWithLoc(`
          .foo {
            color: red;
          }

          .bar {
            color: blue;

       /* ^ Missing closing } */
        `),
      ).toThrowErrorMatchingInlineSnapshot(
        `[CssSyntaxError: input.css:6:11: Missing closing } at .bar]`,
      )
    })

    it('should error when an unterminated string is used', () => {
      let input = css`
        .foo {
          content: "Hello world!
          /*                    ^ missing " */
          font-weight: bold;
        }
      `

      expect(() => parse(input)).toThrowErrorMatchingInlineSnapshot(
        `[CssSyntaxError: Unterminated string: "Hello world!"]`,
      )

      expect(() => parseWithLoc(input)).toThrowErrorMatchingInlineSnapshot(
        `[CssSyntaxError: input.css:3:20: Unterminated string: "Hello world!"]`,
      )
    })

    it('should error when an unterminated string is used with a `;`', () => {
      let input = css`
        .foo {
          content: "Hello world!;
          /*                    ^ missing " */
          font-weight: bold;
        }
      `

      expect(() => parse(input)).toThrowErrorMatchingInlineSnapshot(
        `[CssSyntaxError: Unterminated string: "Hello world!;"]`,
      )

      expect(() => parseWithLoc(input)).toThrowErrorMatchingInlineSnapshot(
        `[CssSyntaxError: input.css:3:20: Unterminated string: "Hello world!;"]`,
      )
    })

    it('should error when incomplete custom properties are used', () => {
      expect(() => parse('--foo')).toThrowErrorMatchingInlineSnapshot(
        `[CssSyntaxError: Invalid custom property, expected a value]`,
      )

      expect(() => parseWithLoc('--foo')).toThrowErrorMatchingInlineSnapshot(
        `[CssSyntaxError: input.css:1:1: Invalid custom property, expected a value]`,
      )
    })

    it('should error when incomplete custom properties are used inside rules', () => {
      expect(() => parse('.foo { --bar }')).toThrowErrorMatchingInlineSnapshot(
        `[CssSyntaxError: Invalid custom property, expected a value]`,
      )

      expect(() => parseWithLoc('.foo { --bar }')).toThrowErrorMatchingInlineSnapshot(
        `[CssSyntaxError: input.css:1:8: Invalid custom property, expected a value]`,
      )
    })

    it('should error when an unterminated string is used in a custom property', () => {
      // prettier-ignore
      let input = css`
        .foo {
          --bar: 'Hello world!
          /*                  ^ missing ' * /;
        }
      `

      expect(() => parse(input)).toThrowErrorMatchingInlineSnapshot(
        `[CssSyntaxError: Unterminated string: 'Hello world!']`,
      )

      expect(() => parseWithLoc(input)).toThrowErrorMatchingInlineSnapshot(
        `[CssSyntaxError: input.css:3:18: Unterminated string: 'Hello world!']`,
      )
    })

    it('should error when a declaration is incomplete', () => {
      expect(() => parse('.foo { bar }')).toThrowErrorMatchingInlineSnapshot(
        `[CssSyntaxError: Invalid declaration: \`bar\`]`,
      )

      expect(() => parseWithLoc('.foo { bar }')).toThrowErrorMatchingInlineSnapshot(
        `[CssSyntaxError: input.css:1:8: Invalid declaration: \`bar\`]`,
      )
    })
  })

  it('ignores BOM at the beginning of a file', () => {
    expect(parse("\uFEFF@reference 'tailwindcss';")).toEqual([
      {
        kind: 'at-rule',
        name: '@reference',
        nodes: [],
        params: "'tailwindcss'",
      },
    ])
  })
})
