/*
 * Authored by Alex Hultman, 2018-2021.
 * Intellectual property of third-party.

 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at

 *     http://www.apache.org/licenses/LICENSE-2.0

 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef UWS_WEBSOCKET_H
#define UWS_WEBSOCKET_H

#include "AsyncSocket.h"
#include "WebSocketContextData.h"
#include "WebSocketData.h"
#include "WebSocketProtocol.h"

#include <string_view>
// clang-format off
namespace uWS {

template <bool SSL, bool isServer, typename USERDATA>
struct WebSocket : AsyncSocket<SSL> {
    template <bool> friend struct TemplatedApp;
    template <bool> friend struct HttpResponse;
private:
    typedef AsyncSocket<SSL> Super;

    void *init(bool perMessageDeflate, CompressOptions compressOptions, BackPressure &&backpressure, void *socketData, WebSocketData::OnSocketClosedCallback onSocketClosed) {
        new (us_socket_ext((us_socket_t *) this)) WebSocketData(perMessageDeflate, compressOptions, std::move(backpressure), socketData, onSocketClosed);
        return this;
    }

    /* Recover the per-route context data from the socket's group. The group's
     * ext is the embedding WebSocketContext*, whose layout is {group; data;}
     * — so (group_t*)ext + 1 = &data. Mirrors the old us_socket_context_ext
     * (which returned context + 1) without needing WebSocketContext.h. */
    WebSocketContextData<SSL, USERDATA> *getContextData() {
        return (WebSocketContextData<SSL, USERDATA> *)
            ((us_socket_group_t *) us_socket_group_ext(us_socket_group((us_socket_t *) this)) + 1);
    }
public:

    /* Returns pointer to the per socket user data */
    USERDATA *getUserData() {
        WebSocketData *webSocketData = (WebSocketData *) us_socket_ext((us_socket_t *) this);
        /* We just have it overallocated by sizeof type */
        return (USERDATA *) (webSocketData + 1);
    }

    /* See AsyncSocket */
    using Super::getBufferedAmount;
    using Super::getRemoteAddress;
    using Super::getRemoteAddressAsText;
    using Super::getNativeHandle;

    /* WebSocket close cannot be an alias to AsyncSocket::close since
     * we need to check first if it was shut down by remote peer */
    us_socket_t *close() {
        if (us_socket_is_closed((us_socket_t *) this)) {
            return nullptr;
        }
        WebSocketData *webSocketData = (WebSocketData *) Super::getAsyncSocketData();
        if (webSocketData->isShuttingDown) {
            return nullptr;
        }

        /* Callers rely on the close event having run on return, which code 0 does not give on TLS (CloseCode, src/uws_sys/us_socket_t.rs). */
        us_socket_t *s = us_socket_close((us_socket_t *) this, LIBUS_SOCKET_CLOSE_CODE_FAST_SHUTDOWN, nullptr);
        if (!us_socket_is_closed((us_socket_t *) this)) {
            /* Parked behind the TLS ciphertext spill, which a peer that stopped reading never drains. */
            s = us_socket_close((us_socket_t *) this, LIBUS_SOCKET_CLOSE_CODE_CONNECTION_RESET, nullptr);
        }
        return s;
    }

    enum SendStatus : int {
        BACKPRESSURE,
        SUCCESS,
        DROPPED
    };

    /* Report what send() would return right now without sending: DROPPED over
     * maxBackpressure, BACKPRESSURE if anything is buffered, else SUCCESS.
     * publish() uses this to surface per-subscriber backpressure. */
    SendStatus sendStatus() {
        WebSocketContextData<SSL, USERDATA> *webSocketContextData = getContextData();
        size_t buffered = getBufferedAmount();
        if (webSocketContextData->maxBackpressure && webSocketContextData->maxBackpressure < buffered) {
            return DROPPED;
        }
        if (buffered > 0) {
            return BACKPRESSURE;
        }
        return SUCCESS;
    }

    /* Fold a per-subscriber status into an aggregate: DROPPED beats
     * BACKPRESSURE beats SUCCESS. */
    static SendStatus worseStatus(SendStatus a, SendStatus b) {
        if (a == DROPPED || b == DROPPED) return DROPPED;
        if (a == BACKPRESSURE || b == BACKPRESSURE) return BACKPRESSURE;
        return SUCCESS;
    }

    size_t memoryCost() {
        /* Allocation footprint for reportExtraMemoryAllocated, not unsent bytes. */
        return Super::getAsyncSocketData()->buffer.totalLength() + sizeof(WebSocket);
    }

    /* Sending fragmented messages puts a bit of effort on the user; you must not interleave regular sends
     * with fragmented sends and you must sendFirstFragment, [sendFragment], then finally sendLastFragment. */
    SendStatus sendFirstFragment(std::string_view message, OpCode opCode = OpCode::BINARY, bool compress = false) {
        return send(message, opCode, compress, false);
    }

    SendStatus sendFragment(std::string_view message, bool compress = false) {
        return send(message, CONTINUATION, compress, false);
    }

    SendStatus sendLastFragment(std::string_view message, bool compress = false) {
        return send(message, CONTINUATION, compress, true);
    }

    /* Send or buffer a WebSocket frame, compressed or not. Returns BACKPRESSURE on increased user space backpressure,
     * DROPPED on dropped message (due to backpressure) or SUCCCESS if you are free to send even more now. */
    SendStatus send(std::string_view message, OpCode opCode = OpCode::BINARY, bool compress = false, bool fin = true) {
        WebSocketContextData<SSL, USERDATA> *webSocketContextData = getContextData();

        /* Skip sending and report success if we are over the limit of maxBackpressure */
        if (webSocketContextData->maxBackpressure && webSocketContextData->maxBackpressure < getBufferedAmount()) {
            /* Also defer a close if we should */
            if (webSocketContextData->closeOnBackpressureLimit) {
                us_socket_shutdown_read((us_socket_t *) this);
            }
            return DROPPED;
        }

        /* If we are subscribers and have messages to drain we need to drain them here to stay synced */
        WebSocketData *webSocketData = (WebSocketData *) Super::getAsyncSocketData();

        /* Special path for long sends of non-compressed, non-SSL messages */
        int ourCorkSlot = Super::getLoopData()->findCorkSlot(this);
        bool corkBufferEmpty = ourCorkSlot == LoopData::INVALID_CORK_SLOT || Super::getLoopData()->getCorkSlot(ourCorkSlot)->offset == 0;
        if (message.length() >= 16 * 1024 && !compress && !SSL && !webSocketData->subscriber && getBufferedAmount() == 0 && corkBufferEmpty) {
            char header[10];
            int header_length = (int) protocol::formatMessage<isServer>(header, "", 0, opCode, message.length(), compress, fin);
            int written = us_socket_write2((struct us_socket_t *)this, header, header_length, message.data(), (int) message.length());

            if (written != header_length + (int) message.length()) {
                /* Buffer up backpressure */
                if (written > header_length) {
                    webSocketData->buffer.append(message.data() + written - header_length, message.length() - (size_t) (written - header_length));
                } else {
                    webSocketData->buffer.append(header + written, (size_t) header_length - (size_t) written);
                    webSocketData->buffer.append(message.data(), message.length());
                }
                /* We cannot still be corked if we have backpressure.
                 * We also cannot uncork normally since it will re-write the already buffered
                 * up backpressure again. */
                Super::uncorkWithoutSending();
                return BACKPRESSURE;
            }
        } else {

            if (webSocketData->subscriber) {
                /* This will call back into us, send. */
                webSocketContextData->topicTree->drain(webSocketData->subscriber);
            }

            /* Transform the message to compressed domain if requested */
            if (compress) {
                WebSocketData *webSocketData = (WebSocketData *) Super::getAsyncSocketData();

                /* Check and correct the compress hint. It is never valid to compress 0 bytes */
                if (message.length() && opCode < 3 && webSocketData->compressionStatus == WebSocketData::ENABLED) {
                    LoopData *loopData = Super::getLoopData();
                    /* Compress using either shared or dedicated deflationStream */
                    if (webSocketData->deflationStream) {
                        message = webSocketData->deflationStream->deflate(loopData->zlibContext, message, false);
                    } else {
                        message = loopData->deflationStream->deflate(loopData->zlibContext, message, true);
                    }
                } else {
                    compress = false;
                }
            }

            /* Get size, allocate size, write if needed */
            size_t messageFrameSize = protocol::messageFrameSize(message.length());
            auto [sendBuffer, sendBufferAttribute] = Super::getSendBuffer(messageFrameSize);
            protocol::formatMessage<isServer>(sendBuffer, message.data(), message.length(), opCode, message.length(), compress, fin);

            /* Depending on size of message we have different paths */
            if (sendBufferAttribute == SendBufferAttribute::NEEDS_DRAIN) {
                /* This is a drain */
                auto[written, failed] = Super::write(nullptr, 0);
                if (failed) {
                    /* Return false for failure, skipping to reset the timeout below */
                    return BACKPRESSURE;
                }
            } else if (sendBufferAttribute == SendBufferAttribute::NEEDS_UNCORK) {
                /* Uncork if we came here uncorked */
                auto [written, failed] = Super::uncork();
                if (failed) {
                    return BACKPRESSURE;
                }
            }

        }

        /* Every successful send resets the timeout */
        if (webSocketContextData->resetIdleTimeoutOnSend) {
            Super::timeout(webSocketContextData->idleTimeoutComponents.first);
            WebSocketData *webSocketData = (WebSocketData *) Super::getAsyncSocketData();
            webSocketData->hasTimedOut = false;
        }

        /* Return success */
        return SUCCESS;
    }

    /* Send websocket close frame, emit close event, send FIN if successful.
     * Will not append a close reason if code is 0 or 1005. */
    void end(int code = 0, std::string_view message = {}) {
        /* Check if we already called this one */
        WebSocketData *webSocketData = (WebSocketData *) us_socket_ext((us_socket_t *) this);
        if (webSocketData->isShuttingDown) {
            return;
        }

        /* We postpone any FIN sending to either drainage or uncorking */
        webSocketData->isShuttingDown = true;

        /* Format and send the close frame */
        static const int MAX_CLOSE_PAYLOAD = 123;
        size_t length = std::min<size_t>(MAX_CLOSE_PAYLOAD, message.length());
        char closePayload[MAX_CLOSE_PAYLOAD + 2];
        size_t closePayloadLength = protocol::formatClosePayload(closePayload, (uint16_t) code, message.data(), length);
        bool ok = send(std::string_view(closePayload, closePayloadLength), OpCode::CLOSE);

        /* FIN if we are ok and not corked */
        if (!this->isCorked()) {
            if (ok) {
                /* If we are not corked, and we just sent off everything, we need to FIN right here.
                 * In all other cases, we need to fin either if uncork was successful, or when drainage is complete. */
                this->shutdown();
            }
        }

        WebSocketContextData<SSL, USERDATA> *webSocketContextData = getContextData();

        /* Set shorter timeout (use ping-timeout) to avoid long hanging sockets after end() on broken connections */
        Super::timeout(webSocketContextData->idleTimeoutComponents.second);

        /* Make sure to unsubscribe from any pub/sub node at exit */
        webSocketContextData->topicTree->freeSubscriber(webSocketData->subscriber);
        webSocketData->subscriber = nullptr;

        /* Emit close event */
        if (webSocketContextData->closeHandler) {
            webSocketContextData->closeHandler(this, code, message);
        }
    }

    /* Corks the response if possible. Leaves already corked socket be. */
    void cork(MoveOnlyFunction<void()> &&handler) {
        if (!Super::isCorked()) {
            Super::cork();
            handler();

            /* There is no timeout when failing to uncork for WebSockets,
             * as that is handled by idleTimeout */
            auto [written, failed] = Super::uncork();
            (void)written;
            (void)failed;
        } else {
            /* We are already corked, or can't cork so let's just call the handler */
            handler();
        }
    }

    /* Subscribe to a topic according to MQTT rules and syntax. Returns success */
    bool subscribe(std::string_view topic, bool = false) {
        WebSocketContextData<SSL, USERDATA> *webSocketContextData = getContextData();

        /* Make us a subscriber if we aren't yet */
        WebSocketData *webSocketData = (WebSocketData *) us_socket_ext((us_socket_t *) this);
        if (!webSocketData->subscriber) {
            webSocketData->subscriber = webSocketContextData->topicTree->createSubscriber();
            webSocketData->subscriber->user = this;
        }

        webSocketContextData->topicTree->subscribe(webSocketData->subscriber, topic);

        /* Subscribe always succeeds */
        return true;
    }

    /* Unsubscribe from a topic, returns true if we were subscribed. */
    bool unsubscribe(std::string_view topic, bool = false) {
        WebSocketContextData<SSL, USERDATA> *webSocketContextData = getContextData();

        WebSocketData *webSocketData = (WebSocketData *) us_socket_ext((us_socket_t *) this);

        if (!webSocketData->subscriber) { return false; }

        auto [ok, last] = webSocketContextData->topicTree->unsubscribe(webSocketData->subscriber, topic);

        /* Free us as subscribers if we unsubscribed from our last topic */
        if (ok && last) {
            /* Flush queued publish() messages before the Subscriber is freed.
             * freeSubscriber unlinks without draining, which would otherwise
             * drop messages that publish() already accepted this tick. */
            webSocketContextData->topicTree->drain(webSocketData->subscriber);
            webSocketContextData->topicTree->freeSubscriber(webSocketData->subscriber);
            webSocketData->subscriber = nullptr;
        }

        return ok;
    }

    /* Returns whether this socket is subscribed to the specified topic */
    bool isSubscribed(std::string_view topic) {
        WebSocketContextData<SSL, USERDATA> *webSocketContextData = getContextData();

        WebSocketData *webSocketData = (WebSocketData *) us_socket_ext((us_socket_t *) this);
        if (!webSocketData->subscriber) {
            return false;
        }

        Topic *topicPtr = webSocketContextData->topicTree->lookupTopic(topic);
        if (!topicPtr) {
            return false;
        }

        return topicPtr->count(webSocketData->subscriber);
    }

    /* Iterates all topics of this WebSocket. Every topic is represented by its full name.
     * Can be called in close handler. It is possible to modify the subscription list while
     * inside the callback ONLY IF not modifying the topic passed to the callback.
     * Topic names are valid only for the duration of the callback. */
    void iterateTopics(MoveOnlyFunction<void(std::string_view)> cb) {
        WebSocketContextData<SSL, USERDATA> *webSocketContextData = getContextData();

        WebSocketData *webSocketData = (WebSocketData *) us_socket_ext((us_socket_t *) this);
        if (webSocketData->subscriber) {
            /* Lock this subscriber for unsubscription / subscription */
            webSocketContextData->topicTree->iteratingSubscriber = webSocketData->subscriber;

            for (Topic *topicPtr : webSocketData->subscriber->topics) {
                cb({topicPtr->name.data(), topicPtr->name.length()});
            }

            /* Unlock subscriber */
            webSocketContextData->topicTree->iteratingSubscriber = nullptr;
        }
    }

    /* MQTT-style publish that never delivers to this WebSocket (the sender).
     * Returns the worst receiver SendStatus; no receivers is DROPPED.
     * Use App::publish for an unconditional broadcast. */
    SendStatus publish(std::string_view topic, std::string_view message, OpCode opCode = OpCode::TEXT, bool compress = false) {
        WebSocketContextData<SSL, USERDATA> *webSocketContextData = getContextData();

        /* A sender with no Subscriber (never subscribed to anything) still publishes; nullptr
         * is a valid "exclude nobody" sender for TopicTree (App::publish relies on this). */
        WebSocketData *webSocketData = (WebSocketData *) us_socket_ext((us_socket_t *) this);
        Subscriber *sender = webSocketData->subscriber;

        /* Publish as sender, does not receive its own messages even if subscribed to relevant topics */
        if (message.length() >= LoopData::CORK_COPY_MAX) {
            SendStatus worst = SUCCESS;
            bool hasReceivers = false;
            webSocketContextData->topicTree->publishBig(sender, topic, {message, opCode, compress}, [&worst, &hasReceivers](Subscriber *s, TopicTreeBigMessage &message) {
                hasReceivers = true;
                auto *ws = (WebSocket<SSL, true, int> *) s->user;

                worst = worseStatus(worst, (SendStatus) ws->send(message.message, (OpCode)message.opCode, message.compress));
            });
            return hasReceivers ? worst : DROPPED;
        } else {
            Topic *t = webSocketContextData->topicTree->lookupTopic(topic);
            if (!t) {
                return DROPPED;
            }
            webSocketContextData->topicTree->publish(sender, topic, {std::string(message), opCode, compress});
            /* publish() may have synchronously drained a subscriber; check backpressure after. */
            SendStatus worst = SUCCESS;
            bool hasReceivers = false;
            for (Subscriber *s : *t) {
                if (s == sender) continue;
                hasReceivers = true;
                auto *ws = (WebSocket<SSL, true, int> *) s->user;
                worst = worseStatus(worst, (SendStatus) ws->sendStatus());
            }
            return hasReceivers ? worst : DROPPED;
        }
    }
};

}

#endif // UWS_WEBSOCKET_H