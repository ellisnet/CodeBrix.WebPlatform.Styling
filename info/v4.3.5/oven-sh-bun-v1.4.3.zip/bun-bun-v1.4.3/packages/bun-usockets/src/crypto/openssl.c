/*
 * Authored by Alex Hultman, 2018-2019.
 * Intellectual property of third-party.

 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at

 *     http://www.apache.org/licenses/LICENSE-2.0

 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
// clang-format off
#if (defined(LIBUS_USE_OPENSSL) || defined(LIBUS_USE_WOLFSSL))

#include "internal/internal.h"
#include "internal/fault_inject.h"
#include "libusockets.h"
#include <string.h>
#include <limits.h>
#include <stdatomic.h>
#include <time.h>

/* These are in sni_tree.cpp */
void *sni_new();
void sni_free(void *sni, void (*cb)(void *));
int sni_add(void *sni, const char *hostname, void *user);
void *sni_remove(void *sni, const char *hostname);
void *sni_find(void *sni, const char *hostname);

#ifdef LIBUS_USE_OPENSSL
#include <openssl/bio.h>
#include <openssl/dh.h>
#include <openssl/err.h>
#include <openssl/ssl.h>
#include <openssl/pkcs12.h>
#include <openssl/pool.h>
#elif LIBUS_USE_WOLFSSL
#include <wolfssl/openssl/bio.h>
#include <wolfssl/openssl/dh.h>
#include <wolfssl/openssl/err.h>
#include <wolfssl/openssl/ssl.h>
#include <wolfssl/options.h>
#endif

#include "./root_certs_header.h"
#include "./default_ciphers.h"

/* ──────────────────────────────────────────────────────────────────────────
 * Per-socket SSL model.
 *
 * SSL_CTX is owned externally (SecureContext / listener) and
 * never created here outside of us_ssl_ctx_from_options(). Each TLS socket carries a
 * heap-allocated us_ssl_socket_data_t at s->ssl, which owns one SSL* built
 * from a borrowed SSL_CTX. The loop dispatch path is:
 *
 *   loop.c readable → s->ssl ? us_internal_ssl_on_data : us_dispatch_data
 *
 * and us_internal_ssl_on_data decrypts then re-enters us_dispatch_data with
 * plaintext. Same shape for open/writable/close/end.
 * ────────────────────────────────────────────────────────────────────────── */

/* Capacity of the parked fatal-error reason (ERR_error_string_n output).
 * OpenSSL formats "error:...:reason" strings well under this; anything
 * longer is truncated by ERR_error_string_n itself (always NUL-terminated). */
#define US_SSL_FATAL_ERROR_REASON_MAX 256

struct loop_ssl_data {
  char *ssl_read_input, *ssl_read_output;
  unsigned int ssl_read_input_length;
  unsigned int ssl_read_input_offset;

  struct us_socket_t *ssl_socket;
  BIO *shared_rbio;
  BIO *shared_wbio;
  BIO_METHOD *shared_biom;
  /* The OpenSSL error string of the fatal SSL error that is about to close
   * the current socket (set in the SSL_ERROR_SSL branch immediately before
   * ssl_close, consumed by the handshake-failure dispatch inside that
   * ssl_close, cleared after use). Lets 'wrong version number' and friends
   * reach the JS 'tlsClientError' / client error the way Node reports them.
   * A longer reason is truncated: every writer goes through
   * ERR_error_string_n, which NUL-terminates and truncates to the buffer
   * size (OpenSSL's own error strings stay well under it). */
  char ssl_last_fatal_error[US_SSL_FATAL_ERROR_REASON_MAX];
  /* The socket that parked ssl_last_fatal_error. The scratch is per-loop, so
   * a reason parked by one socket must never be reported for another (a
   * server and a client in the same process share this loop). */
  void *ssl_last_fatal_error_owner;

  /* Ciphertext write batching: while one us_internal_ssl_write runs,
   * BIO_s_custom_write appends each sealed record here instead of issuing one
   * raw socket write per 16 KB record; the whole batch reaches the kernel in
   * a single write afterwards (node reaches the same shape via its memory
   * BIO drained with writev). Lazily allocated, reused across writes. */
  char *ssl_write_batch;
  unsigned int ssl_write_batch_len;
  unsigned int ssl_write_batch_cap;
  int ssl_write_batching;
  /* The socket whose sealed records fill ssl_write_batch. The slot is shared
   * per-loop, so a flush must only ever deliver the batch to this socket, and
   * a batching region entered for another socket flushes these records to
   * their owner first (BIO_s_custom_write). Meaningful while
   * ssl_write_batch_len > 0. */
  struct us_socket_t *ssl_write_batch_owner;

  /* Single spill slot: ciphertext a partial batch flush could not deliver.
   * SSL believes these records were written, so they MUST reach this exact
   * socket's fd, in order, before any of its later records. Drained from the
   * owner's writable event; while the slot is occupied, other sockets write
   * through per record (the pre-batching path). */
  struct us_socket_t *ssl_spill_owner;
  char *ssl_spill;
  unsigned int ssl_spill_len;
  unsigned int ssl_spill_off;

  /* us_socket_sni_resolve's answer; us_select_cert_cb takes it in the same re-drive. */
  SSL_CTX *ssl_sni_resolved_ctx;
};

enum {
  HANDSHAKE_PENDING = 0,
  HANDSHAKE_COMPLETED = 1,
  HANDSHAKE_RENEGOTIATION_PENDING = 2,
};

/* No per-socket SSL struct: `s->ssl` IS the BoringSSL `SSL*`, and the 6 state
 * bits live in `us_socket_t`'s pointer-alignment padding (see internal.h). */
#define s_ssl(s) ((SSL *)(s)->ssl)

/* SNI tree leaf — stored as the void* user in sni_tree.cpp. */
struct sni_node_t {
  SSL_CTX *ctx;
  void *user;
};

static _Atomic long ssl_ctx_live = 0;

long us_ssl_ctx_live_count(void) {
  return atomic_load(&ssl_ctx_live);
}

/* ex_data indices, registered once at first SSL_CTX/SSL touch:
 *   - us_ctx_ex_idx (SSL_CTX): packed reneg {limit:u32,window:u32}; its
 *     free_func also decrements ssl_ctx_live so the counter tracks ACTUAL
 *     destruction (refcount→0), not every SSL_CTX_free.
 *   - us_sni_ex_idx (SSL_CTX): per-domain userdata (uWS HttpRouter*).
 *   - us_ssl_rare_ex_idx (SSL): us_ssl_rare_t.
 *   - us_ssl_wrapper_ex_idx (SSL): the owner of an SSL that no us_socket_t drives.
 *
 * SSL_CTX creation runs from both the JS thread (SecureContext, Bun.connect/
 * listen) and the HTTP-client thread (HTTPContext.initWithOpts). A racy `<0`
 * check would let two threads each register the ctx_ex_idx free_func, double-
 * decrementing ssl_ctx_live forever after. (BoringSSL's CRYPTO_once is
 * internal-only, so use the platform primitive directly; root_certs.cpp does
 * the same via std::call_once.) */
static int us_ctx_ex_idx = -1;
static int us_sni_ex_idx = -1;
static int us_ctx_cache_ex_idx = -1;
/* Marks an SSL_CTX whose verification store holds user-provided CAs (the
 * ca/caFile options or a later addCACert): the per-socket client attach must
 * not replace such a store with the process-shared default roots. */
static int us_ctx_user_ca_ex_idx = -1;
static int us_ssl_rare_ex_idx = -1;
/* (SSL) The SSLWrapper (src/uws/lib.rs) that owns this SSL. Not set on the SSL of a us_socket_t. */
static int us_ssl_wrapper_ex_idx = -1;
/* BIO type of the loop's shared BIO: tells a us_socket_t's SSL from an SSLWrapper's. */
static int us_ssl_bio_type = 0;
/* (SSL_CTX) packed client-certificate policy of a Bun.serve per-serverName
 * entry — see us_ssl_ctx_set_sni_policy. Absent on node:tls SecureContexts,
 * whose policy is server-level. */
static int us_ctx_sni_policy_ex_idx = -1;
/* Defined in Rust (src/uws_sys/SocketKind.rs) so the ordinal tracks the enum. */
extern const unsigned char BUN_SOCKET_KIND_BUN_SOCKET_TLS;
extern const unsigned char BUN_SOCKET_KIND_UWS_HTTP_TLS;
#ifdef _WIN32
static INIT_ONCE us_ex_idx_once = INIT_ONCE_STATIC_INIT;
#else
#include <pthread.h>
static pthread_once_t us_ex_idx_once = PTHREAD_ONCE_INIT;
#endif

#define US_RENEG_PACK(limit, window) ((void *)(uintptr_t)(((uint64_t)(limit) << 32) | (uint32_t)(window)))
#define US_RENEG_LIMIT(p)  ((uint32_t)((uint64_t)(uintptr_t)(p) >> 32))
#define US_RENEG_WINDOW(p) ((uint32_t)((uint64_t)(uintptr_t)(p)))

/* us_socket_t::ssl_sni_pending: an async SNICallback has the handshake suspended. */
enum {
  US_SNI_NONE = 0,
  US_SNI_WAITING = 1,
  US_SNI_RESOLVED = 2,
  US_SNI_ERROR = 3,
};

struct us_ssl_pending_event_t {
  struct us_ssl_pending_event_t *next;
  uint32_t length;
  unsigned char is_keylog;
  unsigned char data[];
};

/* Allocated for an accepted socket, a node:tls socket's events, a client's first renegotiation, and fetch's session sink. */
struct us_ssl_rare_t {
  struct us_listen_socket_t *listener;
  /* Sessions and keylog lines parked inside SSL_read/SSL_do_handshake, in arrival order. */
  struct us_ssl_pending_event_t *pending_head, *pending_tail;
  void *session_sink;
  void (*session_sink_free)(void *sink);
  uint64_t reneg_window_start_ms;
  uint32_t reneg_count;
};

static void us_ctx_ex_free(void *parent, void *ptr, CRYPTO_EX_DATA *ad,
                           int index, long argl, void *argp) {
  (void)parent; (void)ptr; (void)ad; (void)index; (void)argl; (void)argp;
  atomic_fetch_sub(&ssl_ctx_live, 1);
}
static void us_ssl_rare_free(void *parent, void *ptr, CRYPTO_EX_DATA *ad,
                             int index, long argl, void *argp) {
  (void)parent; (void)ad; (void)index; (void)argl; (void)argp;
  struct us_ssl_rare_t *rare = ptr;
  if (!rare) return;
  while (rare->pending_head) {
    struct us_ssl_pending_event_t *next = rare->pending_head->next;
    us_free(rare->pending_head);
    rare->pending_head = next;
  }
  if (rare->session_sink_free) rare->session_sink_free(rare->session_sink);
  us_free(rare);
}

/* Upper bounds for parked payloads: a serialized SSL_SESSION (i2d) and a
 * single keylog line. Anything larger is dropped at the parking site. */
#define US_SSL_PENDING_SESSION_MAX 65536
#define US_SSL_PENDING_KEYLOG_LINE_MAX 4096

/* Defined in src/uws/lib.rs. `wrapper` is what us_ssl_set_wrapper stored. */
extern int us_ssl_wrapper_server_identity(void *wrapper, SSL *ssl);
extern int us_ssl_wrapper_identity_checked(void *wrapper);
extern void us_ssl_wrapper_new_session(void *wrapper, SSL_SESSION *session);
extern void us_ssl_wrapper_keylog(void *wrapper, const char *line, size_t length);

static inline void *us_ssl_wrapper(const SSL *ssl) {
  return us_ssl_wrapper_ex_idx >= 0 ? SSL_get_ex_data(ssl, us_ssl_wrapper_ex_idx) : NULL;
}

static int us_ssl_is_socket(const SSL *ssl) {
  BIO *bio = SSL_get_wbio(ssl);
  return bio && BIO_method_type(bio) == us_ssl_bio_type;
}

/* The socket driving `ssl`: every BoringSSL callback runs inside one of its SSL_* calls. */
static struct us_socket_t *us_ssl_socket(const SSL *ssl) {
  if (!us_ssl_is_socket(ssl)) return NULL;
  struct us_socket_t *s = ((struct loop_ssl_data *)BIO_get_data(SSL_get_wbio(ssl)))->ssl_socket;
  return s && s->ssl == ssl ? s : NULL;
}

static inline struct us_ssl_rare_t *us_ssl_rare(const SSL *ssl);
static struct us_ssl_rare_t *us_ssl_rare_ensure(SSL *ssl);

static struct us_ssl_pending_event_t *ssl_park_event(struct us_socket_t *s, int is_keylog,
                                                     size_t length) {
  struct us_ssl_pending_event_t *event = us_malloc(sizeof(*event) + length);
  if (!event) return NULL;
  event->next = NULL;
  event->length = (uint32_t)length;
  event->is_keylog = is_keylog ? 1 : 0;
  struct us_ssl_rare_t *rare = us_ssl_rare_ensure(s_ssl(s));
  if (rare->pending_tail) {
    rare->pending_tail->next = event;
  } else {
    rare->pending_head = event;
  }
  rare->pending_tail = event;
  s->ssl_has_pending_events = 1;
  return event;
}

static void us_ssl_keylog_cb(const SSL *ssl, const char *line) {
  size_t line_len = strlen(line);
  if (line_len == 0 || line_len > US_SSL_PENDING_KEYLOG_LINE_MAX) {
    return;
  }
  void *wrapper = us_ssl_wrapper(ssl);
  if (wrapper) {
    us_ssl_wrapper_keylog(wrapper, line, line_len);
    return;
  }
  struct us_socket_t *s = us_ssl_socket(ssl);
  if (!s || us_socket_kind(s) != BUN_SOCKET_KIND_BUN_SOCKET_TLS) {
    return;
  }
  struct us_ssl_pending_event_t *event = ssl_park_event(s, 1, line_len + 1);
  if (!event) {
    return;
  }
  memcpy(event->data, line, line_len);
  /* Node appends the newline before it emits 'keylog'. */
  event->data[line_len] = '\n';
}

static int us_ssl_new_session_cb(SSL *ssl, SSL_SESSION *session) {
  void *wrapper = us_ssl_wrapper(ssl);
  if (wrapper) {
    us_ssl_wrapper_new_session(wrapper, session);
    return 0;
  }
  struct us_socket_t *s = us_ssl_socket(ssl);
  /* The owner takes its own reference if it keeps the session; 1 asks for a 'session' event. */
  if (!s || !us_dispatch_new_session(s, session)) {
    return 0;
  }
  int length = i2d_SSL_SESSION(session, NULL);
  if (length <= 0 || length > US_SSL_PENDING_SESSION_MAX) {
    return 0;
  }
  struct us_ssl_pending_event_t *event = ssl_park_event(s, 0, (size_t)length);
  if (!event) {
    return 0;
  }
  unsigned char *out = event->data;
  event->length = (uint32_t)i2d_SSL_SESSION(session, &out);
  return 0;
}

/* Runs JS, which may close the socket: call after the SSL_* call returned, then check ssl_gone(s). */
static void ssl_flush_pending_events(struct us_socket_t *s) {
  if (!s->ssl_has_pending_events) {
    return;
  }
  s->ssl_has_pending_events = 0;
  struct us_ssl_rare_t *rare = s->ssl ? us_ssl_rare(s_ssl(s)) : NULL;
  if (!rare) {
    return;
  }
  struct us_ssl_pending_event_t *events = rare->pending_head;
  rare->pending_head = rare->pending_tail = NULL;
  /* Sessions first, then keylog lines. */
  for (int is_keylog = 0; is_keylog <= 1; is_keylog++) {
    for (struct us_ssl_pending_event_t *event = events; event; event = event->next) {
      if (event->is_keylog != is_keylog || us_socket_is_closed(s) || !s->ssl) continue;
      if (is_keylog) {
        us_dispatch_keylog(s, event->data, (int)event->length);
      } else {
        us_dispatch_session(s, event->data, (int)event->length);
      }
    }
  }
  while (events) {
    struct us_ssl_pending_event_t *next = events->next;
    us_free(events);
    events = next;
  }
}

/* Defined in `src/runtime/api/bun/SSLContextCache.rs`: tombstones the cache entry on
 * SSL_CTX refcount→0 so the per-VM weak SSL_CTX cache learns the pointer is
 * dead without holding a ref of its own. */
extern void bun_ssl_ctx_cache_on_free(void *parent, void *ptr, CRYPTO_EX_DATA *ad,
                                      int index, long argl, void *argp);

static void us_ex_idx_init(void) {
  us_ctx_ex_idx = SSL_CTX_get_ex_new_index(0, NULL, NULL, NULL, us_ctx_ex_free);
  us_sni_ex_idx = SSL_CTX_get_ex_new_index(0, NULL, NULL, NULL, NULL);
  us_ctx_cache_ex_idx = SSL_CTX_get_ex_new_index(0, NULL, NULL, NULL, bun_ssl_ctx_cache_on_free);
  us_ctx_user_ca_ex_idx = SSL_CTX_get_ex_new_index(0, NULL, NULL, NULL, NULL);
  us_ctx_sni_policy_ex_idx = SSL_CTX_get_ex_new_index(0, NULL, NULL, NULL, NULL);
  us_ssl_rare_ex_idx = SSL_get_ex_new_index(0, NULL, NULL, NULL, us_ssl_rare_free);
  us_ssl_wrapper_ex_idx = SSL_get_ex_new_index(0, NULL, NULL, NULL, NULL);
  us_ssl_bio_type = BIO_get_new_index() | BIO_TYPE_SOURCE_SINK;
}

#ifdef _WIN32
static BOOL CALLBACK us_ex_idx_init_win(PINIT_ONCE o, PVOID p, PVOID *c) {
  (void)o; (void)p; (void)c;
  us_ex_idx_init();
  return TRUE;
}
#endif

static inline void us_ex_idx_ensure(void) {
#ifdef _WIN32
  InitOnceExecuteOnce(&us_ex_idx_once, us_ex_idx_init_win, NULL, NULL);
#else
  pthread_once(&us_ex_idx_once, us_ex_idx_init);
#endif
}

static inline int us_ssl_ctx_ex_idx(void) {
  us_ex_idx_ensure();
  return us_ctx_ex_idx;
}

int us_ssl_ctx_cache_ex_idx(void) {
  us_ex_idx_ensure();
  return us_ctx_cache_ex_idx;
}

static inline void us_reneg_policy(SSL *ssl, uint32_t *limit, uint32_t *window) {
  void *packed = us_ctx_ex_idx >= 0
      ? SSL_CTX_get_ex_data(SSL_get_SSL_CTX(ssl), us_ctx_ex_idx) : NULL;
  *limit = packed ? US_RENEG_LIMIT(packed) : 3;
  *window = packed ? US_RENEG_WINDOW(packed) : 600;
}

static inline struct us_ssl_rare_t *us_ssl_rare(const SSL *ssl) {
  return us_ssl_rare_ex_idx >= 0 ? SSL_get_ex_data(ssl, us_ssl_rare_ex_idx) : NULL;
}

static struct us_ssl_rare_t *us_ssl_rare_ensure(SSL *ssl) {
  us_ex_idx_ensure();
  struct us_ssl_rare_t *rare = SSL_get_ex_data(ssl, us_ssl_rare_ex_idx);
  if (rare) return rare;
  rare = us_calloc(1, sizeof(*rare));
  if (!rare || !SSL_set_ex_data(ssl, us_ssl_rare_ex_idx, rare)) Bun__outOfMemory();
  return rare;
}

void us_ssl_set_wrapper(SSL *ssl, void *wrapper) {
  us_ex_idx_ensure();
  if (!SSL_set_ex_data(ssl, us_ssl_wrapper_ex_idx, wrapper)) Bun__outOfMemory();
}

void *us_ssl_wrapper_from_verify(void *ctx) {
  SSL *ssl = X509_STORE_CTX_get_ex_data(ctx, SSL_get_ex_data_X509_STORE_CTX_idx());
  return ssl ? us_ssl_wrapper(ssl) : NULL;
}

/* `sink` lives until SSL_free, then `on_free(sink)` runs. Replaces the sink set before. */
void us_socket_set_session_sink(struct us_socket_t *s, void *sink, void (*on_free)(void *)) {
  if (!s->ssl) {
    if (on_free) on_free(sink);
    return;
  }
  struct us_ssl_rare_t *rare = us_ssl_rare_ensure(s_ssl(s));
  if (rare->session_sink_free) rare->session_sink_free(rare->session_sink);
  rare->session_sink = sink;
  rare->session_sink_free = on_free;
}

void *us_socket_session_sink(struct us_socket_t *s) {
  struct us_ssl_rare_t *rare = s->ssl ? us_ssl_rare(s_ssl(s)) : NULL;
  return rare ? rare->session_sink : NULL;
}

/* socket.c — raw TCP FIN that does NOT re-enter the SSL layer. */
extern void us_internal_socket_raw_shutdown(struct us_socket_t *s);

static void ssl_update_handshake(struct us_socket_t *s, int fin_ends_handshake);
static int ssl_flush_write_batch(struct loop_ssl_data *loop_ssl_data, struct us_socket_t *s);
static int us_ssl_inline_reject_tripped(struct us_socket_t *s);
static inline int ssl_gone(struct us_socket_t *s);

/* ── BIO plumbing ─────────────────────────────────────────────────────────
 * The same shared mem-BIO pair is reused for every SSL* on a loop. The write
 * BIO sends ciphertext straight to the wire via raw_write (which never
 * re-enters the SSL layer). */

int passphrase_cb(char *buf, int size, int rwflag, void *u) {
  /* No passphrase configured: behave like Node's PasswordCallback and try an
   * empty password, so an encrypted key fails with BAD_DECRYPT instead of
   * BoringSSL's default callback failing with BAD_PASSWORD_READ. */
  if (u == NULL) return 0;
  const char *passphrase = (const char *)u;
  size_t passphrase_length = strlen(passphrase);
  if (passphrase_length > (size_t)size) return -1;
  memcpy(buf, passphrase, passphrase_length);
  return (int)passphrase_length;
}

static int BIO_s_custom_create(BIO *bio) {
  BIO_set_init(bio, 1);
  return 1;
}

static long BIO_s_custom_ctrl(BIO *bio, int cmd, long num, void *user) {
  switch (cmd) {
  case BIO_CTRL_FLUSH:
    return 1;
  default:
    return 0;
  }
}

/* Save/restore the per-loop BIO routing state around a JS callback that runs
 * from inside SSL_do_handshake/SSL_read: user JS that writes to or destroys a
 * different TLS socket on the same loop re-points loop_ssl_data->ssl_socket
 * (and may consume the read-input window), and the interrupted handshake's
 * next BIO_write would otherwise land on that other socket's fd. The batching
 * flag is saved-and-zeroed so a write or close_notify for a different socket
 * inside the callback goes to that socket's fd via the per-record BIO path
 * instead of appending to the interrupted handshake's batch. */
int us_internal_ssl_loop_state_slots(void) { return US_SSL_LOOP_STATE_SLOTS; }

void us_internal_ssl_loop_state_save(void *ssl_ptr, void **out) {
  SSL *ssl = (SSL *)ssl_ptr;
  struct loop_ssl_data *d = (struct loop_ssl_data *)BIO_get_data(SSL_get_wbio(ssl));
  out[0] = d;
  out[1] = d ? (void *)d->ssl_socket : NULL;
  out[2] = d ? (void *)d->ssl_read_input : NULL;
  out[3] = d ? (void *)(uintptr_t)d->ssl_read_input_length : NULL;
  out[4] = d ? (void *)(uintptr_t)d->ssl_read_input_offset : NULL;
  out[5] = d ? (void *)(uintptr_t)d->ssl_write_batching : NULL;
  if (d) d->ssl_write_batching = 0;
}

void us_internal_ssl_loop_state_restore(void **saved) {
  struct loop_ssl_data *d = (struct loop_ssl_data *)saved[0];
  if (!d) return;
  d->ssl_socket = (struct us_socket_t *)saved[1];
  d->ssl_read_input = (char *)saved[2];
  d->ssl_read_input_length = (unsigned int)(uintptr_t)saved[3];
  d->ssl_read_input_offset = (unsigned int)(uintptr_t)saved[4];
  d->ssl_write_batching = (int)(uintptr_t)saved[5];
}

static int BIO_s_custom_write(BIO *bio, const char *data, int length) {
  struct loop_ssl_data *loop_ssl_data = (struct loop_ssl_data *)BIO_get_data(bio);

  /* A callback run from inside SSL_do_handshake/SSL_read marked this socket
   * for deferred destruction (an SNI abort, or JS destroying the socket): the
   * connection is being dropped without a TLS-level goodbye, so swallow
   * whatever BoringSSL tries to flush (typically the fatal alert). The bytes
   * are reported as written so the SSL state machine completes its error
   * path instead of retrying. */
  if (loop_ssl_data->ssl_socket && loop_ssl_data->ssl_socket->ssl_pending_detach) {
    BIO_clear_retry_flags(bio);
    return length;
  }

  /* Rejecting client whose chain verification failed: suppress the
   * post-verify flight so the peer never sees the handshake complete
   * (node's post-verify destroy cancels its queued Finished the same way). */
  if (loop_ssl_data->ssl_socket &&
      us_ssl_inline_reject_tripped(loop_ssl_data->ssl_socket)) {
    BIO_clear_retry_flags(bio);
    return length;
  }

  if (loop_ssl_data->ssl_write_batching &&
      loop_ssl_data->ssl_write_batch_len &&
      loop_ssl_data->ssl_write_batch_owner != loop_ssl_data->ssl_socket) {
    /* The batch holds another socket's records (a JS callback in this
     * dispatch wrote to a second TLS socket on the same loop while the
     * first socket's flight was held). Deliver them to their owner first so
     * each socket's records stay in order. */
    ssl_flush_write_batch(loop_ssl_data, loop_ssl_data->ssl_write_batch_owner);
  }

  if (loop_ssl_data->ssl_write_batching && loop_ssl_data->ssl_spill_owner == NULL) {
    /* Append the sealed record; the batch hits the kernel once, after
     * SSL_write returns. Reporting the full length keeps BoringSSL sealing
     * the next record instead of parking a partial one. Skipped while a
     * spill occupies the slot: a later short flush could not park its
     * remainder without clobbering that socket's pending ciphertext. */
    unsigned int needed = loop_ssl_data->ssl_write_batch_len + (unsigned int)length;
    if (needed > loop_ssl_data->ssl_write_batch_cap) {
      unsigned int new_cap = loop_ssl_data->ssl_write_batch_cap ? loop_ssl_data->ssl_write_batch_cap : 65536;
      while (new_cap < needed) new_cap *= 2;
      char *grown = us_realloc(loop_ssl_data->ssl_write_batch, new_cap);
      if (!grown) {
        /* Earlier sealed records sit in the batch and SSL's sequence numbers have
         * already advanced past them; writing the current record first would break
         * wire order (bad_record_mac at the peer). Same as the spill OOM path: the
         * connection cannot stay coherent. */
        if (loop_ssl_data->ssl_socket)
          loop_ssl_data->ssl_socket->ssl_fatal_error = 1;
        BIO_clear_retry_flags(bio);
        return length;
      }
      loop_ssl_data->ssl_write_batch = grown;
      loop_ssl_data->ssl_write_batch_cap = new_cap;
    }
    memcpy(loop_ssl_data->ssl_write_batch + loop_ssl_data->ssl_write_batch_len, data, (size_t)length);
    loop_ssl_data->ssl_write_batch_len = needed;
    loop_ssl_data->ssl_write_batch_owner = loop_ssl_data->ssl_socket;
    BIO_clear_retry_flags(bio);
    return length;
  }
  int written = us_socket_raw_write(loop_ssl_data->ssl_socket, data, length);

  BIO_clear_retry_flags(bio);
  if (!written) {
    if (!us_internal_socket_can_raw_write(loop_ssl_data->ssl_socket)) {
      /* Sealed after our FIN, so it can never leave. A retry would wait for a
       * writable event that never comes. */
      return length;
    }
    BIO_set_retry_write(bio);
    return -1;
  }
  return written;
}

/* Flush the ciphertext batch to its socket in one write. A partial write
 * spills the remainder into the loop's single spill slot - SSL already
 * counts those records as delivered, so they are drained (in order, to this
 * socket only) from its writable event. Returns 1 when the wire took
 * everything, 0 when it did not: the rest is spilled, or dropped when it can
 * never be sent. */
static int ssl_flush_write_batch(struct loop_ssl_data *loop_ssl_data, struct us_socket_t *s) {
  unsigned int len = loop_ssl_data->ssl_write_batch_len;
  if (!len) return 1;
  if (loop_ssl_data->ssl_write_batch_owner != s) {
    /* Not this socket's records (SSL_write failed before sealing anything
     * while another socket's flight was held): leave them for their owner's
     * own flush point. */
    return 1;
  }
  loop_ssl_data->ssl_write_batch_len = 0;
  loop_ssl_data->ssl_write_batch_owner = NULL;
  int written = us_socket_raw_write(s, loop_ssl_data->ssl_write_batch, (int)len);
  if (written < 0) written = 0;
  if ((unsigned int)written < len) {
    unsigned int remainder = len - (unsigned int)written;
    if (!us_internal_socket_can_raw_write(s)) {
      /* Sealed after our FIN, so it can never leave. A spill would hold the
       * loop's one spill slot, and us_internal_ssl_close would wait for it. */
      return 0;
    }
    if (loop_ssl_data->ssl_spill_owner) {
      /* The spill slot is already another socket's (a re-entrant JS region
       * produced one between the entry-time gate and this flush).
       * Overwriting it would leak and corrupt that socket's stream; this
       * socket's remainder is undeliverable. */
      s->ssl_fatal_error = 1;
      return 0;
    }
    char *spill = us_malloc(remainder);
    if (!spill) {
      /* Out of memory with ciphertext in flight: the connection cannot stay
       * coherent (SSL already advanced its sequence numbers). Drop it. */
      s->ssl_fatal_error = 1;
      return 0;
    }
    memcpy(spill, loop_ssl_data->ssl_write_batch + written, remainder);
    loop_ssl_data->ssl_spill = spill;
    loop_ssl_data->ssl_spill_len = remainder;
    loop_ssl_data->ssl_spill_off = 0;
    loop_ssl_data->ssl_spill_owner = s;
    return 0;
  }
  return 1;
}

/* Drop the batch slot when its owner dies without reaching a flush point
 * (error/RST teardown), or when a destroy from inside the handshake cancels
 * the held flight. The buffer itself is loop-owned and reused. */
static void ssl_release_batch(struct us_loop_t *loop, struct us_socket_t *s) {
  struct loop_ssl_data *loop_ssl_data = (struct loop_ssl_data *)loop->data.ssl_data;
  if (loop_ssl_data && loop_ssl_data->ssl_write_batch_owner == s) {
    loop_ssl_data->ssl_write_batch_len = 0;
    loop_ssl_data->ssl_write_batch_owner = NULL;
  }
}

/* Try to drain the spill slot for `s`. Returns 1 when clear (or not ours),
 * 0 while ciphertext is still pending for this socket. */
static int ssl_drain_spill(struct loop_ssl_data *loop_ssl_data, struct us_socket_t *s) {
  if (loop_ssl_data->ssl_spill_owner != s) return 1;
  unsigned int pending = loop_ssl_data->ssl_spill_len - loop_ssl_data->ssl_spill_off;
  int written = us_socket_raw_write(s, loop_ssl_data->ssl_spill + loop_ssl_data->ssl_spill_off, (int)pending);
  if (written < 0) written = 0;
  loop_ssl_data->ssl_spill_off += (unsigned int)written;
  if (loop_ssl_data->ssl_spill_off == loop_ssl_data->ssl_spill_len) {
    us_free(loop_ssl_data->ssl_spill);
    loop_ssl_data->ssl_spill = NULL;
    loop_ssl_data->ssl_spill_len = 0;
    loop_ssl_data->ssl_spill_off = 0;
    loop_ssl_data->ssl_spill_owner = NULL;
    return 1;
  }
  return 0;
}

/* Release the spill slot when its owner dies (close path). */
static void ssl_release_spill(struct us_loop_t *loop, struct us_socket_t *s) {
  struct loop_ssl_data *loop_ssl_data = (struct loop_ssl_data *)loop->data.ssl_data;
  if (loop_ssl_data && loop_ssl_data->ssl_spill_owner == s) {
    /* Hard close with ciphertext still spilled: give the kernel one last
     * chance to take it (it usually can - the spill is bounded small). */
    ssl_drain_spill(loop_ssl_data, s);
  }
  if (loop_ssl_data && loop_ssl_data->ssl_spill_owner == s) {
    us_free(loop_ssl_data->ssl_spill);
    loop_ssl_data->ssl_spill = NULL;
    loop_ssl_data->ssl_spill_len = 0;
    loop_ssl_data->ssl_spill_off = 0;
    loop_ssl_data->ssl_spill_owner = NULL;
  }
}

void us_internal_ssl_socket_relocated(struct us_loop_t *loop, struct us_socket_t *old_s,
                                      struct us_socket_t *new_s) {
  struct loop_ssl_data *loop_ssl_data = (struct loop_ssl_data *)loop->data.ssl_data;
  if (!loop_ssl_data) return;
  if (loop_ssl_data->ssl_spill_owner == old_s) {
    loop_ssl_data->ssl_spill_owner = new_s;
  }
  if (loop_ssl_data->ssl_write_batch_owner == old_s) {
    loop_ssl_data->ssl_write_batch_owner = new_s;
  }
  if (loop_ssl_data->ssl_last_fatal_error_owner == (void *)old_s) {
    loop_ssl_data->ssl_last_fatal_error_owner = (void *)new_s;
  }
}

/* The listener cleanup walks its accept group only, so a socket that leaves the group drops the pointer. */
void us_internal_ssl_socket_left_group(struct us_socket_t *s) {
  struct us_ssl_rare_t *rare = s->ssl ? us_ssl_rare(s_ssl(s)) : NULL;
  if (rare) rare->listener = NULL;
}

static int BIO_s_custom_read(BIO *bio, char *dst, int length) {
  struct loop_ssl_data *loop_ssl_data = (struct loop_ssl_data *)BIO_get_data(bio);

  BIO_clear_retry_flags(bio);
  if (!loop_ssl_data->ssl_read_input_length) {
    BIO_set_retry_read(bio);
    return -1;
  }

  if ((unsigned int)length > loop_ssl_data->ssl_read_input_length) {
    length = loop_ssl_data->ssl_read_input_length;
  }

  memcpy(dst, loop_ssl_data->ssl_read_input + loop_ssl_data->ssl_read_input_offset, length);

  loop_ssl_data->ssl_read_input_offset += length;
  loop_ssl_data->ssl_read_input_length -= length;
  return length;
}

static struct loop_ssl_data *ssl_set_loop_data(struct us_socket_t *s) {
  struct us_loop_t *loop = s->group->loop;
  struct loop_ssl_data *loop_ssl_data = (struct loop_ssl_data *)loop->data.ssl_data;

  loop_ssl_data->ssl_read_input_length = 0;
  loop_ssl_data->ssl_read_input_offset = 0;
  loop_ssl_data->ssl_socket = s;
  return loop_ssl_data;
}

/* The loop's shared TLS plaintext buffer. Split out so the fault injector can
 * fail this one allocation: a 512 KiB malloc only returns NULL where the OS
 * does not overcommit, which is the only place the crash was ever seen. */
static char *ssl_alloc_read_output(void) {
#if defined(LIBUS_SOCKET_FAULT_INJECTION) && LIBUS_SOCKET_FAULT_INJECTION
  ssize_t injected = 0;
  int unused = 0;
  if (US_FAULT_CHECK(US_FAULT_SSL_LOOP_BUFFER, -1, injected, unused)) return NULL;
#endif
  return us_malloc(LIBUS_RECV_BUFFER_LENGTH + LIBUS_RECV_BUFFER_PADDING * 2);
}

void us_internal_init_loop_ssl_data(struct us_loop_t *loop) {
  if (!loop->data.ssl_data) {
    struct loop_ssl_data *loop_ssl_data = us_calloc(1, sizeof(struct loop_ssl_data));
    if (!loop_ssl_data) Bun__outOfMemory();
    loop_ssl_data->ssl_read_output = ssl_alloc_read_output();
    if (!loop_ssl_data->ssl_read_output) Bun__outOfMemory();

    OPENSSL_init_ssl(0, NULL);

    us_ex_idx_ensure();
    loop_ssl_data->shared_biom = BIO_meth_new(us_ssl_bio_type, "µS BIO");
    if (!loop_ssl_data->shared_biom) Bun__outOfMemory();
    BIO_meth_set_create(loop_ssl_data->shared_biom, BIO_s_custom_create);
    BIO_meth_set_write(loop_ssl_data->shared_biom, BIO_s_custom_write);
    BIO_meth_set_read(loop_ssl_data->shared_biom, BIO_s_custom_read);
    BIO_meth_set_ctrl(loop_ssl_data->shared_biom, BIO_s_custom_ctrl);

    loop_ssl_data->shared_rbio = BIO_new(loop_ssl_data->shared_biom);
    loop_ssl_data->shared_wbio = BIO_new(loop_ssl_data->shared_biom);
    if (!loop_ssl_data->shared_rbio || !loop_ssl_data->shared_wbio) Bun__outOfMemory();
    BIO_set_data(loop_ssl_data->shared_rbio, loop_ssl_data);
    BIO_set_data(loop_ssl_data->shared_wbio, loop_ssl_data);

    loop->data.ssl_data = loop_ssl_data;
  }
}

void us_internal_free_loop_ssl_data(struct us_loop_t *loop) {
  struct loop_ssl_data *loop_ssl_data = (struct loop_ssl_data *)loop->data.ssl_data;
  if (loop_ssl_data) {
    us_free(loop_ssl_data->ssl_read_output);
    us_free(loop_ssl_data->ssl_write_batch);
    us_free(loop_ssl_data->ssl_spill);
    BIO_free(loop_ssl_data->shared_rbio);
    BIO_free(loop_ssl_data->shared_wbio);
    BIO_meth_free(loop_ssl_data->shared_biom);
    us_free(loop_ssl_data);
    /* us_internal_init_loop_ssl_data's guard reads this: leaving it dangling
     * would hand a freed loop_ssl_data back to the next TLS socket. */
    loop->data.ssl_data = NULL;
  }
}

/* ── SSL_CTX construction ────────────────────────────────────────────────── */

static int us_ssl_ctx_use_privatekey_content(SSL_CTX *ctx, const char *content, int type) {
  int reason_code, ret = 0;
  BIO *in;
  EVP_PKEY *pkey = NULL;
  if (content == NULL) return 0;
  in = BIO_new_mem_buf(content, strlen(content));
  if (in == NULL) {
    OPENSSL_PUT_ERROR(SSL, ERR_R_BUF_LIB);
    goto end;
  }

  if (type == SSL_FILETYPE_PEM) {
    reason_code = ERR_R_PEM_LIB;
    pkey = PEM_read_bio_PrivateKey(in, NULL, SSL_CTX_get_default_passwd_cb(ctx),
                                   SSL_CTX_get_default_passwd_cb_userdata(ctx));
  } else if (type == SSL_FILETYPE_ASN1) {
    reason_code = ERR_R_ASN1_LIB;
    pkey = d2i_PrivateKey_bio(in, NULL);
  } else {
    OPENSSL_PUT_ERROR(SSL, SSL_R_BAD_SSL_FILETYPE);
    goto end;
  }

  if (pkey == NULL) {
    OPENSSL_PUT_ERROR(SSL, reason_code);
    goto end;
  }
  ret = SSL_CTX_use_PrivateKey(ctx, pkey);
  EVP_PKEY_free(pkey);
end:
  BIO_free(in);
  return ret;
}

/* The context's own cert store for mutation: the process-shared root store and
 * the still-empty SSL_CTX_new() store are first replaced by a private full
 * default-root copy, and the context is marked so the per-socket attach keeps
 * it. https://github.com/nodejs/node/blob/v26.3.0/src/crypto/crypto_context.cc#L1831 */
static X509_STORE *us_ssl_ctx_get_own_cert_store(SSL_CTX *ctx) {
  X509_STORE *store = SSL_CTX_get_cert_store(ctx);
  /* us_get_shared_default_ca_store() up-refs before returning, so release
   * the reference taken just for this comparison. */
  X509_STORE *shared = us_get_shared_default_ca_store();
  int store_is_shared = store != NULL && store == shared;
  X509_STORE_free(shared);
  us_ex_idx_ensure();
  int store_is_empty = 0;
  if (store != NULL && !store_is_shared) {
    const STACK_OF(X509_OBJECT) *objs = X509_STORE_get0_objects(store);
    store_is_empty = objs == NULL || sk_X509_OBJECT_num(objs) == 0;
  }
  /* A user `ca` can legitimately add zero certificates (a key PEM is ignored,
   * like Node), leaving an intentionally-empty pin set: only a context with
   * no `ca` configured at all may be seeded with the default roots here. */
  int user_ca = SSL_CTX_get_ex_data(ctx, us_ctx_user_ca_ex_idx) != NULL;
  if (store == NULL || store_is_shared || (store_is_empty && !user_ca)) {
    X509_STORE *own = us_get_default_ca_store();
    if (own == NULL) {
      return NULL;
    }
    SSL_CTX_set_cert_store(ctx, own);
    store = own;
  }
  /* Without this marker us_internal_ssl_attach() would hand client sockets
   * the shared default roots, discarding the store configured here. */
  SSL_CTX_set_ex_data(ctx, us_ctx_user_ca_ex_idx, (void *)1);
  return store;
}

/* The `ca` option: every CERTIFICATE block of `content` as DER into `certs`. User-supplied certificates are validated
 * with a full parse here so a bad one fails the context rather than a later handshake; the parsed object is dropped and
 * the store keeps the DER lazily. Returns the number appended, or -1 for content that is not PEM or whose first
 * certificate block does not decode or parse. As with a PEM_read_bio_X509 loop, a PEM document with no certificates
 * (Node's tests pass a private key) counts as zero, and blocks after one that fails are ignored. */
static int us_collect_ca_pem(SSL_CTX *ctx, const char *content, STACK_OF(CRYPTO_BUFFER) *certs) {
  if (content == NULL) return 0;
  ERR_clear_error();
  BIO *in = BIO_new_mem_buf(content, strlen(content));
  if (in == NULL) return -1;
  int count = 0;
  for (;;) {
    uint8_t *der = NULL;
    long der_len = 0;
    char *name = NULL;
    if (!PEM_bytes_read_bio(&der, &der_len, &name, PEM_STRING_X509, in, SSL_CTX_get_default_passwd_cb(ctx),
                            SSL_CTX_get_default_passwd_cb_userdata(ctx))) {
      break;
    }
    OPENSSL_free(name);
    CRYPTO_BUFFER *buf = CRYPTO_BUFFER_new(der, der_len, NULL);
    OPENSSL_free(der);
    X509 *parsed = buf != NULL ? X509_parse_from_buffer(buf) : NULL;
    if (parsed == NULL) {
      CRYPTO_BUFFER_free(buf);
      buf = NULL;
    }
    X509_free(parsed);
    if (buf == NULL || !sk_CRYPTO_BUFFER_push(certs, buf)) {
      CRYPTO_BUFFER_free(buf);
      if (count == 0) count = -1;
      break;
    }
    count++;
  }
  BIO_free(in);
  if (count == 0) {
    unsigned long pem_err = ERR_peek_last_error();
    if (!((pem_err == 0 || (ERR_GET_LIB(pem_err) == ERR_LIB_PEM && ERR_GET_REASON(pem_err) == PEM_R_NO_START_LINE)) &&
          strstr(content, "-----BEGIN ") != NULL)) {
      count = -1;
    }
  }
  ERR_clear_error();
  return count;
}

static int us_crypto_buffer_cmp(const CRYPTO_BUFFER *const *a, const CRYPTO_BUFFER *const *b) {
  size_t al = CRYPTO_BUFFER_len(*a), bl = CRYPTO_BUFFER_len(*b);
  if (al != bl) return al < bl ? -1 : 1;
  return memcmp(CRYPTO_BUFFER_data(*a), CRYPTO_BUFFER_data(*b), al);
}

/* Trusts the DER certificates in `certs` (duplicates dropped) through one lazily-parsed set on `store`, and makes their
 * subjects the context's client-CA list, as X509_STORE_add_cert + SSL_CTX_add_client_CA per parsed certificate did.
 * Consumes `certs`. */
static int us_install_ca_buffers(SSL_CTX *ctx, X509_STORE *store, STACK_OF(CRYPTO_BUFFER) *certs) {
  int ok = 1;
  size_t n = sk_CRYPTO_BUFFER_num(certs);
  if (n > 1) {
    sk_CRYPTO_BUFFER_set_cmp_func(certs, us_crypto_buffer_cmp);
    sk_CRYPTO_BUFFER_sort(certs);
    size_t kept = 0;
    for (size_t i = 0; i < n; i++) {
      CRYPTO_BUFFER *buf = sk_CRYPTO_BUFFER_value(certs, i);
      const CRYPTO_BUFFER *prev = kept > 0 ? sk_CRYPTO_BUFFER_value(certs, kept - 1) : NULL;
      if (prev != NULL && us_crypto_buffer_cmp((const CRYPTO_BUFFER *const *)&buf, &prev) == 0) {
        CRYPTO_BUFFER_free(buf);
        continue;
      }
      sk_CRYPTO_BUFFER_set(certs, kept++, buf);
    }
    while (sk_CRYPTO_BUFFER_num(certs) > kept) sk_CRYPTO_BUFFER_pop(certs);
    n = kept;
  }
  if (n > 0) {
    CRYPTO_BUFFER **bufs = (CRYPTO_BUFFER **)malloc(n * sizeof(CRYPTO_BUFFER *));
    for (size_t i = 0; bufs != NULL && i < n; i++) bufs[i] = sk_CRYPTO_BUFFER_value(certs, i);
    X509_LAZY_CERT_SET *set = bufs != NULL ? X509_LAZY_CERT_SET_new(bufs, n) : NULL;
    free(bufs);
    STACK_OF(CRYPTO_BUFFER) *names = sk_CRYPTO_BUFFER_new_null();
    ok = set != NULL && names != NULL && X509_STORE_add_lazy_cert_set(store, set);
    for (size_t i = 0; ok && i < n; i++) {
      const uint8_t *subject;
      size_t subject_len;
      CRYPTO_BUFFER *name = NULL;
      ok = X509_LAZY_CERT_SET_get0_subject(set, i, &subject, &subject_len) &&
           (name = CRYPTO_BUFFER_new(subject, subject_len, NULL)) != NULL && sk_CRYPTO_BUFFER_push(names, name);
      if (!ok) CRYPTO_BUFFER_free(name);
    }
    if (ok) {
      SSL_CTX_set0_client_CAs(ctx, names);
    } else {
      sk_CRYPTO_BUFFER_pop_free(names, CRYPTO_BUFFER_free);
    }
    X509_LAZY_CERT_SET_free(set);
  }
  sk_CRYPTO_BUFFER_pop_free(certs, CRYPTO_BUFFER_free);
  return ok;
}

static int add_ca_cert_to_ctx_store(SSL_CTX *ctx, const char *content, X509_STORE *store) {
  X509 *x = NULL;
  ERR_clear_error();
  int count = 0;
  if (content == NULL) return 0;
  BIO *in = BIO_new_mem_buf(content, strlen(content));
  if (in == NULL) {
    OPENSSL_PUT_ERROR(SSL, ERR_R_BUF_LIB);
    goto end;
  }

  while ((x = PEM_read_bio_X509(in, NULL, SSL_CTX_get_default_passwd_cb(ctx),
                                SSL_CTX_get_default_passwd_cb_userdata(ctx)))) {
    X509_STORE_add_cert(store, x);
    if (!SSL_CTX_add_client_CA(ctx, x)) {
      X509_free(x);
      BIO_free(in);
      return 0;
    }
    count++;
    X509_free(x);
  }
end:
  BIO_free(in);
  if (count == 0) {
    /* The PEM loop terminates with PEM_R_NO_START_LINE once there are no
     * (more) CERTIFICATE blocks. A PEM document that contains no
     * certificates at all - Node's test suite passes a private key here - is
     * ignored the way Node ignores it rather than failing the whole context.
     * Content that is not PEM at all, or a malformed certificate block, is
     * still an error. */
    unsigned long pem_err = ERR_peek_last_error();
    if ((pem_err == 0 || (ERR_GET_LIB(pem_err) == ERR_LIB_PEM &&
                          ERR_GET_REASON(pem_err) == PEM_R_NO_START_LINE)) &&
        strstr(content, "-----BEGIN ") != NULL) {
      ERR_clear_error();
      return 1;
    }
    return 0;
  }
  ERR_clear_error();
  return 1;
}

static int us_ssl_ctx_use_certificate_chain(SSL_CTX *ctx, const char *content) {
  BIO *in;
  int ret = 0;
  X509 *x = NULL;

  ERR_clear_error();
  if (content == NULL) return 0;
  in = BIO_new_mem_buf(content, strlen(content));
  if (in == NULL) {
    OPENSSL_PUT_ERROR(SSL, ERR_R_BUF_LIB);
    goto end;
  }

  x = PEM_read_bio_X509_AUX(in, NULL, SSL_CTX_get_default_passwd_cb(ctx),
                            SSL_CTX_get_default_passwd_cb_userdata(ctx));
  if (x == NULL) {
    OPENSSL_PUT_ERROR(SSL, ERR_R_PEM_LIB);
    goto end;
  }

  ret = SSL_CTX_use_certificate(ctx, x);
  if (ERR_peek_error() != 0) ret = 0;

  if (ret) {
    X509 *ca;
    int r;
    uint32_t err;

    SSL_CTX_clear_chain_certs(ctx);
    while ((ca = PEM_read_bio_X509(
                in, NULL, SSL_CTX_get_default_passwd_cb(ctx),
                SSL_CTX_get_default_passwd_cb_userdata(ctx))) != NULL) {
      r = SSL_CTX_add0_chain_cert(ctx, ca);
      if (!r) {
        X509_free(ca);
        ret = 0;
        goto end;
      }
    }
    err = ERR_peek_last_error();
    if (ERR_GET_LIB(err) == ERR_LIB_PEM &&
        ERR_GET_REASON(err) == PEM_R_NO_START_LINE) {
      ERR_clear_error();
    } else {
      ret = 0;
    }
  }
end:
  X509_free(x);
  BIO_free(in);
  return ret;
}

static int us_verify_callback(int preverify_ok, X509_STORE_CTX *ctx) {
  /* Always continue; the user inspects via us_socket_verify_error after
   * on_handshake. Returning 1 defers the decision to JS without aborting
   * mid-handshake - the same model as Node (crypto_tls.cc VerifyCallback). */
  return 1;
}

/* Rejecting client: keep walking (so the final verdict matches node's
 * ssl.verifyError()) but remember the failure; the BIO hook and the
 * handshake drive then keep the Finished off the wire and fail the socket. */
static int us_inline_reject_verify_callback(int preverify_ok, X509_STORE_CTX *ctx) {
  if (!preverify_ok) {
    SSL *ssl = X509_STORE_CTX_get_ex_data(ctx, SSL_get_ex_data_X509_STORE_CTX_idx());
    struct us_socket_t *s = ssl ? us_ssl_socket(ssl) : NULL;
    if (s) s->ssl_verify_failed = 1;
  }
  return 1;
}

/* Whether this socket is a rejecting client whose chain verification failed:
 * from that point on its handshake output is suppressed and the handshake is
 * reported as failed. */
static int us_ssl_inline_reject_tripped(struct us_socket_t *s) {
  if (!s->ssl || s->ssl_handshake_state == HANDSHAKE_COMPLETED) return 0;
  if (!s->ssl_inline_reject || !s->ssl_verify_failed) return 0;
  /* Only the final verdict rejects: an alternate chain can recover a per-depth failure. */
  return SSL_get_verify_result(s_ssl(s)) != X509_V_OK;
}

/* What the owner of a client says about the name on the server's certificate. */
enum {
  US_IDENTITY_REJECTED = 0,
  US_IDENTITY_ACCEPTED = 1,
  /* The owner does not check the name natively: its JS decides after the handshake. */
  US_IDENTITY_UNCHECKED = 2,
};

/* Verifies the chain, then asks the owner of a client for the name: a wrong name is a verify error like any other. */
static int us_cert_verify_cb(X509_STORE_CTX *ctx, void *arg) {
  (void)arg;
  int ok = X509_verify_cert(ctx);
  SSL *ssl = X509_STORE_CTX_get_ex_data(ctx, SSL_get_ex_data_X509_STORE_CTX_idx());
  if (!ssl) return ok;
  void *wrapper = us_ssl_wrapper(ssl);
  struct us_socket_t *s = wrapper ? NULL : us_ssl_socket(ssl);
  if (s) s->ssl_peer_chain_checked = 1;
  if (SSL_is_server(ssl) || X509_STORE_CTX_get_error(ctx) != X509_V_OK) return ok;
  int verdict = wrapper ? us_ssl_wrapper_server_identity(wrapper, ssl)
                : s     ? us_dispatch_server_identity(s, ssl)
                        : US_IDENTITY_UNCHECKED;
  if (verdict == US_IDENTITY_UNCHECKED) return ok;
  if (s) s->ssl_identity_checked = 1;
  if (verdict == US_IDENTITY_REJECTED) {
    if (s) s->ssl_verify_failed = 1;
    X509_STORE_CTX_set_error(ctx, X509_V_ERR_HOSTNAME_MISMATCH);
  }
  return ok;
}

int us_ssl_identity_checked(SSL *ssl) {
  void *wrapper = us_ssl_wrapper(ssl);
  if (wrapper) return us_ssl_wrapper_identity_checked(wrapper);
  struct us_socket_t *s = us_ssl_socket(ssl);
  return s && s->ssl_identity_checked;
}

/* A rejecting client refuses a bad chain inside the handshake, before its Certificate flight. */
void us_socket_set_inline_reject(struct us_socket_t *s) {
  if (!s->ssl || s->ssl_is_server || s->ssl_handshake_state == HANDSHAKE_COMPLETED) return;
  s->ssl_inline_reject = 1;
  SSL_set_verify(s_ssl(s), SSL_VERIFY_PEER, us_inline_reject_verify_callback);
}

void us_socket_set_first_flight_before_fin(struct us_socket_t *s) {
  s->ssl_first_flight_before_fin = 1;
}

/* Drop the strdup'd passphrase. Called as soon as private-key load completes
 * (the only consumer of the passwd_cb), so the secret never outlives ctx
 * construction and SSL_CTX_free() is sufficient on every later path. Also
 * called on the build-error path before SSL_CTX_free. */
static void ssl_ctx_drop_passphrase(SSL_CTX *ctx) {
  void *password = SSL_CTX_get_default_passwd_cb_userdata(ctx);
  if (password) {
    us_free(password);
    SSL_CTX_set_default_passwd_cb_userdata(ctx, NULL);
  }
}

static void ssl_ctx_build_fail(SSL_CTX *ctx) {
  ssl_ctx_drop_passphrase(ctx);
  /* ex_data slot already set right after SSL_CTX_new, so the free_func will
   * decrement ssl_ctx_live on this SSL_CTX_free. */
  SSL_CTX_free(ctx);
}

/* Exported for quic.c (lsquic configures ALPN/transport-params on the SSL_CTX
 * directly) and as the body of us_ssl_ctx_from_options. */
SSL_CTX *us_ssl_ctx_build_raw(struct us_bun_socket_context_options_t options,
                              enum create_bun_socket_error_t *err) {
  ERR_clear_error();

  SSL_CTX *ssl_context = SSL_CTX_new(TLS_method());
  atomic_fetch_add(&ssl_ctx_live, 1);
  /* An expired CA in a trust source (the OS store caches stale intermediates; a bundled root can outlive its notAfter in
   * an old binary; a user bundle can carry both generations) is treated as absent rather than left to shadow the
   * currently-valid certificate for the same issuer. */
  X509_VERIFY_PARAM_set_flags(SSL_CTX_get0_param(ssl_context), X509_V_FLAG_IGNORE_EXPIRED_TRUST_ANCHORS);
  /* Register the live-count free_func first thing so every exit (including
   * build_fail) balances. The packed reneg policy reuses the same slot. */
  SSL_CTX_set_ex_data(ssl_context, us_ssl_ctx_ex_idx(), NULL);

  /* Default options we rely on — changing these breaks the BIO logic. */
  SSL_CTX_set_read_ahead(ssl_context, 1);
  SSL_CTX_set_mode(ssl_context, SSL_MODE_ACCEPT_MOVING_WRITE_BUFFER);
  /* BoringSSL ships with SSL_MODE_NO_AUTO_CHAIN set; Node clears it so a
   * leaf-only `cert` presents the intermediates found in the context's store
   * (crypto_context.cc#L1640). It only runs when the configured chain is 1. */
  SSL_CTX_clear_mode(ssl_context, SSL_MODE_NO_AUTO_CHAIN);
  /* Honor explicit minVersion/maxVersion (Node's secureProtocol/min/maxVersion);
   * default to a TLS1.2 floor when no minimum is requested. */
  SSL_CTX_set_min_proto_version(ssl_context, options.ssl_min_version ? options.ssl_min_version : TLS1_2_VERSION);
  if (options.ssl_max_version) {
    SSL_CTX_set_max_proto_version(ssl_context, options.ssl_max_version);
  }

  if (options.ssl_prefer_low_memory_usage) {
    SSL_CTX_set_mode(ssl_context, SSL_MODE_RELEASE_BUFFERS);
  }

  if (options.passphrase) {
    SSL_CTX_set_default_passwd_cb_userdata(ssl_context, (void *)us_strdup(options.passphrase));
  }
  /* Installed unconditionally: with no userdata it supplies an empty password
   * (see passphrase_cb), matching Node's key-decryption error shape. */
  SSL_CTX_set_default_passwd_cb(ssl_context, passphrase_cb);

  /* Multiple identities (e.g. an RSA and an EC pair, the way Node accepts
   * arrays of key/cert or several pfx entries) must be loaded pair-wise:
   * loading every certificate first and then every key makes BoringSSL check
   * each key against the last certificate loaded and fail with
   * KEY_TYPE_MISMATCH on a mixed configuration. With pair-wise loading the
   * later identity replaces the earlier one in the legacy slot, which is the
   * documented BoringSSL behaviour the adapted tests expect. */
  int interleave_identities = !options.cert_file_name && !options.key_file_name &&
                              options.cert && options.key &&
                              options.cert_count == options.key_count &&
                              options.cert_count > 1;
  if (interleave_identities) {
    for (unsigned int i = 0; i < options.cert_count; i++) {
      if (us_ssl_ctx_use_certificate_chain(ssl_context, options.cert[i]) != 1 ||
          us_ssl_ctx_use_privatekey_content(ssl_context, options.key[i], SSL_FILETYPE_PEM) != 1) {
        ssl_ctx_build_fail(ssl_context);
        return NULL;
      }
    }
  } else {
    if (options.cert_file_name) {
      if (SSL_CTX_use_certificate_chain_file(ssl_context, options.cert_file_name) != 1) {
        ssl_ctx_build_fail(ssl_context);
        return NULL;
      }
    } else if (options.cert && options.cert_count > 0) {
      for (unsigned int i = 0; i < options.cert_count; i++) {
        if (us_ssl_ctx_use_certificate_chain(ssl_context, options.cert[i]) != 1) {
          ssl_ctx_build_fail(ssl_context);
          return NULL;
        }
      }
    }

    if (options.key_file_name) {
      if (SSL_CTX_use_PrivateKey_file(ssl_context, options.key_file_name, SSL_FILETYPE_PEM) != 1) {
        ssl_ctx_build_fail(ssl_context);
        return NULL;
      }
    } else if (options.key && options.key_count > 0) {
      for (unsigned int i = 0; i < options.key_count; i++) {
        if (us_ssl_ctx_use_privatekey_content(ssl_context, options.key[i], SSL_FILETYPE_PEM) != 1) {
          ssl_ctx_build_fail(ssl_context);
          return NULL;
        }
      }
    }
  }
  /* passwd_cb is only consulted by SSL_CTX_use_PrivateKey* above; the secret
   * is dead now. Dropping it here means SSL_CTX_free() is sufficient cleanup
   * everywhere downstream — no special "owner" path. */
  ssl_ctx_drop_passphrase(ssl_context);

  if (options.ca_file_name) {
    /* An explicit CA replaces the default trust store (Node.js semantics):
     * chains must validate exclusively against the supplied CAs. The SSL_CTX
     * already owns a fresh, empty X509_STORE from SSL_CTX_new(), so
     * SSL_CTX_load_verify_locations below populates only the user's CAs. */
    STACK_OF(X509_NAME) *ca_list = SSL_load_client_CA_file(options.ca_file_name);
    if (ca_list == NULL) {
      *err = CREATE_BUN_SOCKET_ERROR_LOAD_CA_FILE;
      ssl_ctx_build_fail(ssl_context);
      return NULL;
    }
    SSL_CTX_set_client_CA_list(ssl_context, ca_list);
    us_ex_idx_ensure();
    SSL_CTX_set_ex_data(ssl_context, us_ctx_user_ca_ex_idx, (void *)1);
    if (SSL_CTX_load_verify_locations(ssl_context, options.ca_file_name, NULL) != 1) {
      *err = CREATE_BUN_SOCKET_ERROR_INVALID_CA_FILE;
      ssl_ctx_build_fail(ssl_context);
      return NULL;
    }
    SSL_CTX_set_verify(ssl_context,
        options.reject_unauthorized ? (SSL_VERIFY_PEER | SSL_VERIFY_FAIL_IF_NO_PEER_CERT)
                                    : SSL_VERIFY_PEER,
        us_verify_callback);

  } else if (options.ca && options.ca_count > 0) {
    us_ex_idx_ensure();
    SSL_CTX_set_ex_data(ssl_context, us_ctx_user_ca_ex_idx, (void *)1);
    /* As above: user CAs only, into the SSL_CTX's own initially-empty store —
     * otherwise a server doing mTLS with `ca: [internalCA]` would also accept
     * any client certificate that chains to a public root. */
    X509_STORE *cert_store = SSL_CTX_get_cert_store(ssl_context);
    STACK_OF(CRYPTO_BUFFER) *ca_certs = sk_CRYPTO_BUFFER_new_null();
    for (unsigned int i = 0; ca_certs != NULL && i < options.ca_count; i++) {
      if (us_collect_ca_pem(ssl_context, options.ca[i], ca_certs) < 0) {
        sk_CRYPTO_BUFFER_pop_free(ca_certs, CRYPTO_BUFFER_free);
        ca_certs = NULL;
      }
    }
    if (ca_certs == NULL || !us_install_ca_buffers(ssl_context, cert_store, ca_certs)) {
      *err = CREATE_BUN_SOCKET_ERROR_INVALID_CA;
      ssl_ctx_build_fail(ssl_context);
      return NULL;
    }
    ERR_clear_error();
    SSL_CTX_set_verify(ssl_context,
        options.reject_unauthorized ? (SSL_VERIFY_PEER | SSL_VERIFY_FAIL_IF_NO_PEER_CERT)
                                    : SSL_VERIFY_PEER,
        us_verify_callback);
  } else {
    /* No user CA: seed the shared default root store, like Node's
     * addRootCerts() when `ca` is absent - the handshake-time auto-chain and
     * (for requestCert) client verification both read it. The getter up-refs,
     * so set_cert_store owns exactly one reference per context. */
    SSL_CTX_set_cert_store(ssl_context, us_get_shared_default_ca_store());
    if (options.request_cert) {
      SSL_CTX_set_verify(ssl_context,
          options.reject_unauthorized ? (SSL_VERIFY_PEER | SSL_VERIFY_FAIL_IF_NO_PEER_CERT)
                                      : SSL_VERIFY_PEER,
          us_verify_callback);
    }
  }

  if (options.dh_params_file_name) {
    DH *dh_2048 = NULL;
    FILE *paramfile = fopen(options.dh_params_file_name, "r");
    if (paramfile) {
      dh_2048 = PEM_read_DHparams(paramfile, NULL, NULL, NULL);
      fclose(paramfile);
    } else {
      ssl_ctx_build_fail(ssl_context);
      return NULL;
    }
    if (dh_2048 == NULL) {
      ssl_ctx_build_fail(ssl_context);
      return NULL;
    }
    const long set_tmp_dh = SSL_CTX_set_tmp_dh(ssl_context, dh_2048);
    DH_free(dh_2048);
    if (set_tmp_dh != 1) {
      ssl_ctx_build_fail(ssl_context);
      return NULL;
    }
    if (!SSL_CTX_set_cipher_list(ssl_context, DEFAULT_CIPHER_LIST)) {
      ssl_ctx_build_fail(ssl_context);
      return NULL;
    }
  }

  if (options.ssl_ciphers) {
    if (!SSL_CTX_set_cipher_list(ssl_context, options.ssl_ciphers)) {
      /* Peek, don't consume: the caller decomposes the queued reason
       * (NO_CIPHER_MATCH, INVALID_COMMAND) into the JS error. */
      unsigned long ssl_err = ERR_peek_error();
      if (!(strlen(options.ssl_ciphers) == 0 && ERR_GET_REASON(ssl_err) == SSL_R_NO_CIPHER_MATCH)) {
        *err = CREATE_BUN_SOCKET_ERROR_INVALID_CIPHERS;
        ssl_ctx_build_fail(ssl_context);
        return NULL;
      }
      ERR_clear_error();
    }
  }

  if (options.secure_options) {
    SSL_CTX_set_options(ssl_context, options.secure_options);
  }

  if (options.crl && options.crl_count > 0) {
    /* Mirrors Node's SecureContext::AddCRL: each PEM CRL is added to the
     * context's OWN store (never the process-shared default root store) and
     * CRL checking is enabled for the whole chain. */
    X509_STORE *crl_store = us_ssl_ctx_get_own_cert_store(ssl_context);
    if (!crl_store) {
      *err = CREATE_BUN_SOCKET_ERROR_INVALID_CRL;
      ssl_ctx_build_fail(ssl_context);
      return NULL;
    }
    for (unsigned int i = 0; i < options.crl_count; i++) {
      BIO *crl_bio = BIO_new_mem_buf(options.crl[i], -1);
      if (!crl_bio) {
        *err = CREATE_BUN_SOCKET_ERROR_INVALID_CRL;
        ssl_ctx_build_fail(ssl_context);
        return NULL;
      }
      X509_CRL *crl = PEM_read_bio_X509_CRL(crl_bio, NULL, NULL, NULL);
      BIO_free(crl_bio);
      if (!crl) {
        *err = CREATE_BUN_SOCKET_ERROR_INVALID_CRL;
        ssl_ctx_build_fail(ssl_context);
        return NULL;
      }
      int added = X509_STORE_add_crl(crl_store, crl);
      X509_CRL_free(crl);
      if (!added) {
        *err = CREATE_BUN_SOCKET_ERROR_INVALID_CRL;
        ssl_ctx_build_fail(ssl_context);
        return NULL;
      }
    }
    X509_STORE_set_flags(crl_store,
                         X509_V_FLAG_CRL_CHECK | X509_V_FLAG_CRL_CHECK_ALL);
  }

  if (options.session_timeout > 0) {
    SSL_CTX_set_timeout(ssl_context, options.session_timeout);
  }

  if (options.allow_partial_trust_chain) {
    /* Mirrors Node's SecureContext::SetAllowPartialTrustChain, which also
     * flags only the context's own store. A store that cannot be prepared
     * fails context creation: the user explicitly asked for the option. */
    X509_STORE *partial_store = us_ssl_ctx_get_own_cert_store(ssl_context);
    if (!partial_store) {
      ssl_ctx_build_fail(ssl_context);
      return NULL;
    }
    X509_STORE_set_flags(partial_store, X509_V_FLAG_PARTIAL_CHAIN);
  }

  if (options.sigalgs) {
    if (!SSL_CTX_set1_sigalgs_list(ssl_context, options.sigalgs)) {
      ssl_ctx_build_fail(ssl_context);
      return NULL;
    }
  }

  if (options.ecdh_curve) {
    if (!SSL_CTX_set1_groups_list(ssl_context, options.ecdh_curve)) {
      *err = CREATE_BUN_SOCKET_ERROR_INVALID_ECDH_CURVE;
      ssl_ctx_build_fail(ssl_context);
      return NULL;
    }
  }

  /* Surface resumable sessions through the new-session callback the way Node
   * does: for TLS 1.3 the resumable session only exists once the peer's
   * NewSessionTicket arrives, and BoringSSL only exposes it here. NO_INTERNAL
   * keeps BoringSSL from also caching it. */
  SSL_CTX_set_session_cache_mode(ssl_context, SSL_SESS_CACHE_CLIENT |
                                                  SSL_SESS_CACHE_SERVER |
                                                  SSL_SESS_CACHE_NO_INTERNAL |
                                                  SSL_SESS_CACHE_NO_AUTO_CLEAR);
  SSL_CTX_sess_set_new_cb(ssl_context, us_ssl_new_session_cb);
  SSL_CTX_set_keylog_callback(ssl_context, us_ssl_keylog_cb);
  SSL_CTX_set_cert_verify_callback(ssl_context, us_cert_verify_cb, NULL);
  return ssl_context;
}

/* Whether the context's store was configured from user CAs (ca / addCACert / pfx extras) rather than being the
 * empty SSL_CTX_new() store or the shared default roots. */
int us_ssl_ctx_has_user_ca(SSL_CTX *ctx) {
  us_ex_idx_ensure();
  return ctx != NULL && SSL_CTX_get_ex_data(ctx, us_ctx_user_ca_ex_idx) != NULL;
}

/* node:tls `secureContext.context.addCACert(pem)`: append the certificates in
 * `content` to this context's trust store. Returns 0 when the content is not
 * a PEM document or contains a malformed certificate. */
int us_ssl_ctx_add_ca_cert(SSL_CTX *ctx, const char *content) {
  if (!ctx || !content) {
    return 0;
  }
  /* addCACert must EXTEND the default trust set the way Node does: the
   * own-store helper replaces a shared or still-empty store with a private
   * full default-root copy before the user's CA is appended. */
  X509_STORE *store = us_ssl_ctx_get_own_cert_store(ctx);
  if (!store) {
    return 0;
  }
  /* A CA added after the context was built (pfx extras, addCACert) lands in
   * the store the handshake-time auto-chain walks, so a leaf-only cert picks
   * the intermediate up with no eager re-walk. */
  return add_ca_cert_to_ctx_store(ctx, content, store);
}

/* node:tls `pfx` support: parse a PKCS#12 blob and hand back PEM-encoded
 * key / certificate / extra-chain strings the regular key/cert/ca options can
 * consume. Returns 1 on success; the three out-strings are libc malloc'd (not
 * us_malloc) because the Rust caller releases them with libc free(). On
 * failure returns 0 and sets *err_reason to a static tag: "parse" (not
 * PKCS#12), "mac" (bad passphrase / corrupt), "key" (no private key),
 * "cert" (no certificate). */
static int pem_from_bio(BIO *bio, char **out, size_t *out_len) {
  char *mem = NULL;
  long n = BIO_get_mem_data(bio, &mem);
  if (n <= 0 || !mem) return 0;
  char *copy = (char *)malloc((size_t)n + 1);
  if (!copy) return 0;
  memcpy(copy, mem, (size_t)n);
  copy[n] = 0;
  *out = copy;
  *out_len = (size_t)n;
  return 1;
}

int us_ssl_parse_pkcs12(const char *data, size_t len, const char *pass,
                        char **out_key, size_t *out_key_len,
                        char **out_cert, size_t *out_cert_len,
                        char **out_ca, size_t *out_ca_len,
                        const char **err_reason) {
  *out_key = *out_cert = *out_ca = NULL;
  *out_key_len = *out_cert_len = *out_ca_len = 0;
  *err_reason = NULL;
  int ok = 0;
  EVP_PKEY *pkey = NULL;
  X509 *cert = NULL;
  STACK_OF(X509) *extra = NULL;
  PKCS12 *p12 = NULL;
  BIO *kb = NULL, *cb = NULL, *ab = NULL;
  if (len > INT_MAX) {
    /* BIO_new_mem_buf takes an int; a negative value would mean
     * "treat as a NUL-terminated string", silently misparsing the blob. */
    *err_reason = "parse";
    return 0;
  }
  BIO *in = BIO_new_mem_buf(data, (int)len);
  if (!in) {
    *err_reason = "parse";
    return 0;
  }
  p12 = d2i_PKCS12_bio(in, NULL);
  BIO_free(in);
  if (!p12) {
    *err_reason = "parse";
    ERR_clear_error();
    return 0;
  }
  if (!PKCS12_parse(p12, pass ? pass : "", &pkey, &cert, &extra)) {
    *err_reason = "mac";
    ERR_clear_error();
    goto done;
  }
  if (!pkey) {
    *err_reason = "key";
    goto done;
  }
  if (!cert) {
    *err_reason = "cert";
    goto done;
  }
  kb = BIO_new(BIO_s_mem());
  cb = BIO_new(BIO_s_mem());
  if (!kb || !cb || !PEM_write_bio_PrivateKey(kb, pkey, NULL, NULL, 0, NULL, NULL) ||
      !PEM_write_bio_X509(cb, cert) || !pem_from_bio(kb, out_key, out_key_len) ||
      !pem_from_bio(cb, out_cert, out_cert_len)) {
    *err_reason = "parse";
    goto done;
  }
  if (extra && sk_X509_num(extra) > 0) {
    ab = BIO_new(BIO_s_mem());
    if (ab) {
      for (size_t i = 0; i < sk_X509_num(extra); i++) {
        PEM_write_bio_X509(ab, sk_X509_value(extra, i));
      }
      pem_from_bio(ab, out_ca, out_ca_len);
    }
  }
  ok = 1;
done:
  if (!ok) {
    free(*out_key);
    free(*out_cert);
    free(*out_ca);
    *out_key = *out_cert = *out_ca = NULL;
  }
  if (kb) BIO_free(kb);
  if (cb) BIO_free(cb);
  if (ab) BIO_free(ab);
  if (pkey) EVP_PKEY_free(pkey);
  if (cert) X509_free(cert);
  if (extra) sk_X509_pop_free(extra, X509_free);
  if (p12) PKCS12_free(p12);
  ERR_clear_error();
  return ok;
}

SSL_CTX *us_ssl_ctx_from_options(struct us_bun_socket_context_options_t options,
                                 enum create_bun_socket_error_t *err) {
  SSL_CTX *ctx = us_ssl_ctx_build_raw(options, err);
  if (!ctx) return NULL;

  /* SecureContext is mode-neutral (Node lets one back both tls.connect and
   * tls.createServer), so we can't bake client-vs-server into the CTX. CTX
   * verify_mode comes purely from options (ca/request_cert/reject_unauthorized)
   * in build_raw — for a server that decides whether CertificateRequest is
   * sent, so we MUST NOT force VERIFY_PEER here. The per-SSL client override
   * (verify mode + trust store) lives in us_internal_ssl_attach. */

  /* Reneg policy is the only Bun-specific config BoringSSL has nowhere to
   * store. Packed into one ex_data slot (no malloc; the void* IS the value)
   * so it dies with the SSL_CTX refcount. The slot was already registered in
   * build_raw for the live counter; this just overwrites its NULL value. */
  if (options.client_renegotiation_limit || options.client_renegotiation_window) {
    SSL_CTX_set_ex_data(ctx, us_ssl_ctx_ex_idx(),
        US_RENEG_PACK(options.client_renegotiation_limit,
                      options.client_renegotiation_window));
  }

  return ctx;
}

/* SSL_CTX's own refcount IS the refcount; SSL_new() takes one more per socket
 * internally, so a socket outlives its SecureContext without help from us.
 * Exported so context.c / socket.c stay free of OpenSSL headers. */
void us_internal_ssl_ctx_up_ref(SSL_CTX *p) {
  if (p) SSL_CTX_up_ref(p);
}
void us_internal_ssl_ctx_unref(SSL_CTX *p) {
  if (p) SSL_CTX_free(p);
}

/* ── HTTP/2 ALPN ─────────────────────────────────────────────────────────── */

static int us_alpn_select_h2(SSL *ssl, const unsigned char **out, unsigned char *outlen,
                             const unsigned char *in, unsigned int inlen, void *arg) {
  (void) ssl;
  int allow_http1 = arg != NULL;
  const unsigned char *http1 = NULL;
  for (unsigned int i = 0; i + 1 <= inlen;) {
    unsigned int len = in[i];
    if (i + 1 + len > inlen) break;
    const unsigned char *proto = &in[i + 1];
    if (len == 2 && proto[0] == 'h' && proto[1] == '2') {
      *out = proto;
      *outlen = 2;
      return SSL_TLSEXT_ERR_OK;
    }
    if (len == 8 && memcmp(proto, "http/1.1", 8) == 0) http1 = proto;
    i += 1 + len;
  }
  if (http1 && allow_http1) {
    *out = http1;
    *outlen = 8;
    return SSL_TLSEXT_ERR_OK;
  }
  /* The client offered ALPN but not h2 (this callback doesn't run at all for
   * a client that sends no ALPN extension; that one completes the handshake
   * and is answered at the HTTP layer). Proceed without ALPN when HTTP/1 is
   * allowed; otherwise refuse the handshake with no_application_protocol. */
  return allow_http1 ? SSL_TLSEXT_ERR_NOACK : SSL_TLSEXT_ERR_ALERT_FATAL;
}

void us_ssl_ctx_enable_http2_alpn(SSL_CTX *ctx, int allow_http1) {
  SSL_CTX_set_alpn_select_cb(ctx, us_alpn_select_h2, allow_http1 ? (void *) 1 : NULL);
}

int us_socket_alpn_is_h2(struct us_socket_t *s) {
  if (!s->ssl) return 0;
  const unsigned char *proto = NULL;
  unsigned int len = 0;
  SSL_get0_alpn_selected(s_ssl(s), &proto, &len);
  return len == 2 && proto[0] == 'h' && proto[1] == '2';
}

/* ── Per-socket SSL attach/detach ────────────────────────────────────────── */

void us_internal_ssl_attach(struct us_socket_t *s, SSL_CTX *ctx,
                            int is_client, const char *sni,
                            struct us_listen_socket_t *listener) {
  us_internal_init_loop_ssl_data(s->group->loop);
  struct loop_ssl_data *loop_ssl_data = (struct loop_ssl_data *)s->group->loop->data.ssl_data;

  SSL *ssl = SSL_new(ctx);
  SSL_set_bio(ssl, loop_ssl_data->shared_rbio, loop_ssl_data->shared_wbio);
  BIO_up_ref(loop_ssl_data->shared_rbio);
  BIO_up_ref(loop_ssl_data->shared_wbio);

  /* renegotiation: ssl_renegotiate_explicit lets us bound it on the client
   * (issues #6197/#5363); never on the server (DoS vector). */
  if (is_client) {
    SSL_set_renegotiate_mode(ssl, ssl_renegotiate_explicit);
    SSL_set_connect_state(ssl);
    if (sni) SSL_set_tlsext_host_name(ssl, sni);
    /* The CTX's session id context partitions a server's sessions by context
     * configuration (create_ssl_context_with_digest). A client fails its
     * handshake when a resumed session's id differs from its own, so clients
     * keep none: a `session` stays usable under any client options. */
    SSL_set_session_id_context(ssl, NULL, 0);
    /* The CTX is mode-neutral and may have verify_mode == NONE (no
     * ca/requestCert in options). Clients must always run verification so
     * verify_error is populated for the JS rejectUnauthorized check — but
     * setting VERIFY_PEER on the CTX would make a server using the same
     * SecureContext send CertificateRequest. SSL_set_verify scopes the mode to
     * this socket; SSL_set0_verify_cert_store gives it the process-shared root
     * bundle without touching the CTX (servers using the same CTX never pay
     * the ~150-root build). us_verify_callback returns 1 so the handshake
     * never aborts here — JS reads verify_error and decides. */
    if (SSL_CTX_get_verify_mode(ctx) == SSL_VERIFY_NONE) {
      SSL_set_verify(ssl, SSL_VERIFY_PEER, us_verify_callback);
      us_ex_idx_ensure();
      if (!SSL_CTX_get_ex_data(ctx, us_ctx_user_ca_ex_idx)) {
        /* Default context: give this socket the process-shared root bundle.
         * A context whose store holds user-provided CAs (ca/caFile options or
         * addCACert) keeps using its own store - overriding it here would
         * hide those CAs from chain verification. */
        X509_STORE *roots = us_get_shared_default_ca_store();
        if (roots) SSL_set0_verify_cert_store(ssl, roots);
      }
    }
  } else {
    SSL_set_accept_state(ssl);
    SSL_set_renegotiate_mode(ssl, ssl_renegotiate_never);
    /* sni_cb recovers ls per-SSL — never via the shared SSL_CTX. */
    if (listener) us_ssl_rare_ensure(ssl)->listener = listener;
  }

  s->ssl = ssl;
  s->ssl_handshake_state = HANDSHAKE_PENDING;
  s->ssl_write_wants_read = 0;
  s->ssl_write_parked = 0;
  s->ssl_read_wants_write = 0;
  s->ssl_fatal_error = 0;
  s->ssl_raw_tap = 0;
  s->ssl_shutdown_after_spill = 0;
  s->ssl_close_after_spill = 0;
  s->ssl_end_delivered = 0;
  s->ssl_in_use = 0;
  s->ssl_pending_detach = 0;
  s->ssl_pending_close_code = 0;
  s->ssl_first_flight_before_fin = 0;
  s->ssl_shutdown_after_first_flight = 0;
  s->ssl_is_server = is_client ? 0 : 1;
  s->ssl_inline_reject = 0;
  s->ssl_verify_failed = 0;
  s->ssl_identity_checked = 0;
  s->ssl_peer_chain_checked = 0;
  s->ssl_sni_pending = US_SNI_NONE;
  s->ssl_sni_resolver = 0;
  s->ssl_has_pending_events = 0;
}

void us_internal_ssl_detach(struct us_socket_t *s) {
  /* Error/RST teardowns (us_internal_socket_close_raw) reach here without going
   * through us_internal_ssl_close: release any spilled ciphertext this socket
   * owns or the loop-wide slot dangles (batching permanently disabled, and a
   * reused socket address would drain the dead socket's records). */
  ssl_release_spill(s->group->loop, s);
  ssl_release_batch(s->group->loop, s);
  if (s->ssl) {
    if (s->ssl_in_use) {
      /* SSL_do_handshake/SSL_read is on the stack (a JS callback run from
       * inside it destroyed the socket); freeing now would leave BoringSSL
       * working on freed memory when control returns. The driver frees it
       * when the call unwinds. */
      s->ssl_pending_detach = 1;
      return;
    }
    SSL_free(s_ssl(s));
    s->ssl = NULL;
    /* Same for a parked handshake reason: no dispatch can claim it now, and a
     * socket reusing this address would report it as its own failure. */
    struct loop_ssl_data *loop_ssl_data = (struct loop_ssl_data *)s->group->loop->data.ssl_data;
    if (loop_ssl_data && loop_ssl_data->ssl_last_fatal_error_owner == (void *)s) {
      loop_ssl_data->ssl_last_fatal_error[0] = 0;
      loop_ssl_data->ssl_last_fatal_error_owner = NULL;
    }
  }
}

/* ── Verify error reporting ──────────────────────────────────────────────── */

const char *us_X509_error_code(long err) {
  const char *code = "UNSPECIFIED";
#define CASE_X509_ERR(CODE) case X509_V_ERR_##CODE: code = #CODE; break;
  switch (err) {
    CASE_X509_ERR(UNABLE_TO_GET_ISSUER_CERT)
    CASE_X509_ERR(UNABLE_TO_GET_CRL)
    CASE_X509_ERR(UNABLE_TO_DECRYPT_CERT_SIGNATURE)
    CASE_X509_ERR(UNABLE_TO_DECRYPT_CRL_SIGNATURE)
    CASE_X509_ERR(UNABLE_TO_DECODE_ISSUER_PUBLIC_KEY)
    CASE_X509_ERR(CERT_SIGNATURE_FAILURE)
    CASE_X509_ERR(CRL_SIGNATURE_FAILURE)
    CASE_X509_ERR(CERT_NOT_YET_VALID)
    CASE_X509_ERR(CERT_HAS_EXPIRED)
    CASE_X509_ERR(CRL_NOT_YET_VALID)
    CASE_X509_ERR(CRL_HAS_EXPIRED)
    CASE_X509_ERR(ERROR_IN_CERT_NOT_BEFORE_FIELD)
    CASE_X509_ERR(ERROR_IN_CERT_NOT_AFTER_FIELD)
    CASE_X509_ERR(ERROR_IN_CRL_LAST_UPDATE_FIELD)
    CASE_X509_ERR(ERROR_IN_CRL_NEXT_UPDATE_FIELD)
    CASE_X509_ERR(OUT_OF_MEM)
    CASE_X509_ERR(DEPTH_ZERO_SELF_SIGNED_CERT)
    CASE_X509_ERR(SELF_SIGNED_CERT_IN_CHAIN)
    CASE_X509_ERR(UNABLE_TO_GET_ISSUER_CERT_LOCALLY)
    CASE_X509_ERR(UNABLE_TO_VERIFY_LEAF_SIGNATURE)
    CASE_X509_ERR(CERT_CHAIN_TOO_LONG)
    CASE_X509_ERR(CERT_REVOKED)
    CASE_X509_ERR(INVALID_CA)
    CASE_X509_ERR(PATH_LENGTH_EXCEEDED)
    CASE_X509_ERR(INVALID_PURPOSE)
    CASE_X509_ERR(CERT_UNTRUSTED)
    CASE_X509_ERR(CERT_REJECTED)
    CASE_X509_ERR(HOSTNAME_MISMATCH)
  }
#undef CASE_X509_ERR
  return code;
}

static long us_internal_verify_peer_certificate(const SSL *ssl, long def) {
  if (!ssl) return def;
  long err = def;
  X509 *peer_cert = SSL_get_peer_certificate(ssl);
  if (peer_cert) {
    X509_free(peer_cert);
    err = SSL_get_verify_result(ssl);
  } else {
    const SSL_CIPHER *curr_cipher = SSL_get_current_cipher(ssl);
    if (curr_cipher && SSL_CIPHER_get_auth_nid(curr_cipher) == NID_auth_psk) {
      return X509_V_OK;
    }
  }
  return err;
}

struct us_bun_verify_error_t us_ssl_socket_verify_error_from_ssl(SSL *ssl) {
  long x509_verify_error =
      us_internal_verify_peer_certificate(ssl, X509_V_ERR_UNABLE_TO_GET_ISSUER_CERT);
  if (x509_verify_error == X509_V_OK)
    return (struct us_bun_verify_error_t){.error = 0, .code = NULL, .reason = NULL};
  /* Only us_cert_verify_cb sets this one: no X509_VERIFY_PARAM here carries a host. */
  if (x509_verify_error == X509_V_ERR_HOSTNAME_MISMATCH) {
    return (struct us_bun_verify_error_t){
        .error = X509_V_ERR_HOSTNAME_MISMATCH,
        .code = "ERR_TLS_CERT_ALTNAME_INVALID",
        .reason = "Hostname/IP does not match certificate's altnames"};
  }
  const char *reason = X509_verify_cert_error_string(x509_verify_error);
  const char *code = us_X509_error_code(x509_verify_error);
  return (struct us_bun_verify_error_t){.error = x509_verify_error, .code = code, .reason = reason};
}

/* A sent FIN, a sent close_notify or a fatal error says nothing about the
 * peer's certificate: on an open socket the SSL alone answers, like node's
 * TLSWrap::VerifyError
 * (https://github.com/nodejs/node/blob/v26.3.0/src/crypto/crypto_tls.cc#L1840-L1853). */
struct us_bun_verify_error_t us_internal_ssl_verify_error(struct us_socket_t *s) {
  if (!s->ssl || !s_ssl(s) || us_socket_is_closed(s)) {
    return (struct us_bun_verify_error_t){.error = 0, .code = NULL, .reason = NULL};
  }
  return us_ssl_socket_verify_error_from_ssl(s_ssl(s));
}

/* After our own FIN a failed handshake reports the SSL's verdict only for a
 * chain that it checked: node:tls reads a failure with an X509 code as an
 * established session. */
static struct us_bun_verify_error_t ssl_failed_handshake_verify_error(struct us_socket_t *s) {
  if (us_internal_ssl_is_shut_down(s) && !s->ssl_peer_chain_checked) {
    return (struct us_bun_verify_error_t){.error = 0, .code = NULL, .reason = NULL};
  }
  return us_internal_ssl_verify_error(s);
}

/* ── Handshake state machine ─────────────────────────────────────────────── */

/* Park the fatal OpenSSL reason behind a failed SSL_* call where the
 * handshake-failure dispatch can find it, then drain the queue and mark the
 * socket fatal. Only parks while the handshake is unfinished: that dispatch is
 * the sole consumer, so a later reason would linger and be misreported as some
 * other socket's handshake failure. */
static void ssl_park_fatal_reason(struct us_socket_t *s) {
  struct loop_ssl_data *loop_ssl_data =
      (struct loop_ssl_data *) s->group->loop->data.ssl_data;
  if (loop_ssl_data && s->ssl_handshake_state != HANDSHAKE_COMPLETED) {
    /* The OLDEST queued entry is the root cause and is what node reports
     * (https://github.com/nodejs/node/blob/v26.3.0/src/crypto/crypto_tls.cc#L860);
     * later entries wrap it or belong to another socket on this thread. */
    unsigned long ssl_queue_err = ERR_peek_error();
    if (ssl_queue_err != 0) {
      ERR_error_string_n(ssl_queue_err, loop_ssl_data->ssl_last_fatal_error,
                         sizeof(loop_ssl_data->ssl_last_fatal_error));
      loop_ssl_data->ssl_last_fatal_error_owner = s;
    }
  }
  ERR_clear_error();
  s->ssl_fatal_error = 1;
}

/* The on_handshake callback runs JS which may us_socket_close(s) — that frees
 * s->ssl. Every caller MUST check ssl_gone(s) immediately after this returns
 * and bail before touching s->ssl again. */
/* If a fatal handshake reason was parked by `s`, dispatch it as the EPROTO
 * failure for `s` and return 1; the per-loop scratch is copied to the stack
 * and cleared before the dispatch runs JS. Returns 0 when nothing was parked
 * for this socket. */
static int ssl_dispatch_parked_reason(struct us_socket_t *s) {
  struct loop_ssl_data *loop_ssl_data =
      (struct loop_ssl_data *) s->group->loop->data.ssl_data;
  if (!loop_ssl_data || !loop_ssl_data->ssl_last_fatal_error[0] ||
      loop_ssl_data->ssl_last_fatal_error_owner != (void *)s) {
    return 0;
  }
  char reason[sizeof(loop_ssl_data->ssl_last_fatal_error)];
  memcpy(reason, loop_ssl_data->ssl_last_fatal_error, sizeof(reason));
  loop_ssl_data->ssl_last_fatal_error[0] = 0;
  loop_ssl_data->ssl_last_fatal_error_owner = NULL;
  struct us_bun_verify_error_t verify_error = {
      .error = -71, .code = "EPROTO", .reason = reason};
  us_dispatch_handshake(s, 0, verify_error);
  return 1;
}

static void ssl_trigger_handshake(struct us_socket_t *s, int success) {
  /* Read before the state flip below turns tripped() off. */
  int inline_rejected = us_ssl_inline_reject_tripped(s);
  s->ssl_handshake_state = HANDSHAKE_COMPLETED;
  /* Inline rejection: the rejecting client's post-verify flight was
   * suppressed - the session must not be reported as established. */
  if (inline_rejected) {
    success = 0;
  }
  /* An inline-rejected handshake reports the X509 verdict node surfaces
   * through ssl.verifyError() (UNABLE_TO_VERIFY_LEAF_SIGNATURE, ...), not
   * the SSL protocol reason that may wrap it. */
  if (!success && inline_rejected && s->ssl && s_ssl(s)) {
    struct loop_ssl_data *loop_ssl_data =
        (struct loop_ssl_data *)s->group->loop->data.ssl_data;
    if (loop_ssl_data &&
        loop_ssl_data->ssl_last_fatal_error_owner == (void *)s) {
      loop_ssl_data->ssl_last_fatal_error[0] = 0;
      loop_ssl_data->ssl_last_fatal_error_owner = NULL;
    }
    /* The peer never derived the keys our Finished would have carried, so a
     * graceful close (code 0) must send a bare FIN, not a close_notify it
     * cannot read, and must not wait for a reply. Fatal also refuses writes. */
    s->ssl_fatal_error = 1;
    us_dispatch_handshake(s, 0, us_ssl_socket_verify_error_from_ssl(s_ssl(s)));
    /* Nothing else will tear this connection down (the peer is still waiting
     * for a Finished that will never come) - close unless JS already did. */
    if (!ssl_gone(s) && !us_socket_is_closed(s)) {
      us_socket_close(s, 0, NULL);
    }
    return;
  }
  /* A fatal SSL protocol error (wrong version number, bad record, ...) was
   * recorded just before this failure: report it instead of the X509 verify
   * result so Node's tlsClientError / client error carries the OpenSSL
   * reason string. */
  if (!success && ssl_dispatch_parked_reason(s)) {
    return;
  }
  /* A finished handshake reports the SSL's X509 verdict in every socket state. */
  struct us_bun_verify_error_t verify_error =
      success && s->ssl ? us_ssl_socket_verify_error_from_ssl(s_ssl(s))
                        : ssl_failed_handshake_verify_error(s);
  us_dispatch_handshake(s, success, verify_error);
}

static void ssl_trigger_handshake_econnreset(struct us_socket_t *s) {
  s->ssl_handshake_state = HANDSHAKE_COMPLETED;
  /* A fatal SSL protocol error (wrong version number, bad record, ...) was
   * recorded just before this close: report it instead of the generic
   * disconnected-before-established message so Node's tlsClientError /
   * client error carries the OpenSSL reason. */
  if (ssl_dispatch_parked_reason(s)) {
    return;
  }
  struct us_bun_verify_error_t verify_error = {
      .error = -46, .code = "ECONNRESET",
      .reason = "Client network socket disconnected before secure TLS connection was established"};
  us_dispatch_handshake(s, 0, verify_error);
}

/* True once a re-entrant us_socket_close() has run inside a dispatch. Any
 * `s->ssl` is NULL at that point. */
static inline int ssl_gone(struct us_socket_t *s) {
  return us_socket_is_closed(s) || s->ssl == NULL;
}

static int ssl_renegotiate(struct us_socket_t *s) {
  /* Server-forced renegotiation (HelloRequest -> SSL_ERROR_WANT_RENEGOTIATE).
   * Enforce the per-context policy (default 3 per 600s, Node's
   * CLIENT_RENEG_LIMIT/CLIENT_RENEG_WINDOW) before re-entering a full
   * handshake — otherwise a malicious server can pin a core with
   * back-to-back renegotiations. limit == 0 disables renegotiation; window
   * == 0 means the per-connection counter never resets. Returning 0 makes
   * the caller treat this as SSL_ERROR_SSL and close the connection. */
  uint32_t limit, window;
  us_reneg_policy(s_ssl(s), &limit, &window);
  struct us_ssl_rare_t *st = us_ssl_rare_ensure(s_ssl(s));
  s->ssl_handshake_state = HANDSHAKE_RENEGOTIATION_PENDING;
  /* Wall-clock time can step backwards (NTP, manual adjustment); the
   * unsigned subtraction below would underflow and reset the window every
   * time. Only treat the window as elapsed when time has moved forward. */
  uint64_t now_ms = (uint64_t)time(NULL) * 1000;
  if (st->reneg_count == 0 ||
      (window && now_ms >= st->reneg_window_start_ms &&
       now_ms - st->reneg_window_start_ms >= (uint64_t)window * 1000)) {
    st->reneg_window_start_ms = now_ms;
    st->reneg_count = 0;
  }
  if (st->reneg_count >= limit) {
    ssl_trigger_handshake(s, 0);
    return 0;
  }
  st->reneg_count++;
  if (!SSL_renegotiate(s_ssl(s))) {
    ssl_trigger_handshake(s, 0);
    return 0;
  }
  return 1;
}

/* Returns 1 if shutdown is complete (or impossible) and the TCP socket may be
 * closed; 0 if we sent close_notify but must wait for the peer's. */
static int ssl_handle_shutdown(struct us_socket_t *s) {
    if (!s->ssl || us_internal_ssl_is_shut_down(s) || s->ssl_fatal_error || !SSL_is_init_finished(s_ssl(s)))
    return 1;

  int state = SSL_get_shutdown(s_ssl(s));
  int sent_shutdown = state & SSL_SENT_SHUTDOWN;
  int received_shutdown = state & SSL_RECEIVED_SHUTDOWN;
  if (!sent_shutdown || !received_shutdown) {
    ssl_set_loop_data(s);
    int ret = SSL_shutdown(s_ssl(s));
    if (ret < 0) {
      int err = SSL_get_error(s_ssl(s), ret);
      if (err == SSL_ERROR_SSL || err == SSL_ERROR_SYSCALL) {
        ERR_clear_error();
        s->ssl_fatal_error = 1;
        return 1;
      }
      if (err == SSL_ERROR_WANT_READ || err == SSL_ERROR_WANT_WRITE) {
        /* The close_notify could not be flushed (BIO write failed: kernel
         * buffer full or peer already gone). There is no retry path —
         * SSL_SENT_SHUTDOWN is already set, so on_writable/on_data
         * short-circuit through is_shut_down and never re-dispatch the
         * alert. Returning 0 here would keep s->ssl (and BoringSSL's
         * write_buffer holding the encoded alert) alive until the next
         * socket event, which may never arrive — observed as an LSan
         * leak in node-https-checkServerIdentity.test.ts when the child
         * exits right after server.close(). The deferred-close contract
         * documented in us_internal_ssl_close only applies to the
         * SSL_shutdown()==0 case where the alert *was* flushed; here it
         * never went out, so close now. Deliberate divergence from node,
         * which parks the alert in its stream write queue (crypto_tls.cc
         * DoShutdown): replicating that needs a retry hook surviving the
         * is_shut_down short-circuits, and until one exists dropping the
         * alert under backpressure is the accepted tradeoff — the peer
         * still observes the TCP FIN. */
        return 1;
      }
      s->ssl_fatal_error = 1;
      return 1;
    }
    return ret == 1;
  }
  return 1;
}

struct us_socket_t *us_internal_ssl_close(struct us_socket_t *s, int code, void *reason) {
  if (s->ssl && s->ssl_in_use) {
    /* A JS callback running from inside SSL_do_handshake/SSL_read (ALPN, SNI,
     * keylog, ...) destroyed this socket. Reaching ssl_set_loop_data /
     * SSL_do_handshake here would re-enter BoringSSL on the same SSL* while
     * the outer ssl_run_handshake is still on the stack; defer to the SSL
     * driver's epilogue (the same protocol close_raw and ssl_detach honor),
     * releasing the spill now so the re-issued close cannot itself defer. */
    ssl_release_spill(s->group->loop, s);
    s->ssl_pending_detach = 1;
    s->ssl_pending_close_code = (unsigned char) code;
    return s;
  }
  {
    /* Ciphertext batched in this dispatch and still held (the handshake's
     * final flight, a fatal alert sealed by a failing SSL_read) goes to the
     * wire before the close_notify/FIN this teardown sends. A partial write
     * spills; the graceful-close deferral below then waits for the drain. */
    struct loop_ssl_data *loop_ssl_data = (struct loop_ssl_data *)s->group->loop->data.ssl_data;
    if (loop_ssl_data && loop_ssl_data->ssl_write_batch_len &&
        loop_ssl_data->ssl_write_batch_owner == s && !us_socket_is_closed(s)) {
      ssl_flush_write_batch(loop_ssl_data, s);
    }
  }
  /* Neither node's `_handle.close()` (FAST_SHUTDOWN, no reason) nor a graceful
   * close (code 0: peer close_notify / end-completion) may cut off spilled
   * ciphertext already reported as written: SSL sealed it, so it can only be
   * delivered, never re-sent. Mirror ssl_shutdown_after_spill; defer at most once. */
  if ((code == LIBUS_SOCKET_CLOSE_CODE_FAST_SHUTDOWN || code == LIBUS_SOCKET_CLOSE_CODE_CLEAN_SHUTDOWN)
      && !reason
      && !s->ssl_close_after_spill && !s->ssl_fatal_error && !us_socket_is_closed(s)) {
    struct loop_ssl_data *loop_ssl_data = (struct loop_ssl_data *)s->group->loop->data.ssl_data;
    if (loop_ssl_data && !ssl_drain_spill(loop_ssl_data, s)) {
      s->ssl_close_after_spill = 1;
      /* Resume with the SAME code: a graceful close must not come back as a
       * forceful FAST_SHUTDOWN (on_close would see an abortive teardown). */
      s->ssl_pending_close_code = (unsigned char) code;
      return s;
    }
  }
  ssl_release_spill(s->group->loop, s);
  /* SEMI_SOCKET never connected — SSL was attached eagerly on the fast-path
   * connect, but no bytes were ever exchanged. Firing on_handshake(0) here
   * lands in JS after onConnectError already tore down `this`/its handlers. */
  if (ssl_gone(s) || (us_internal_poll_type(&s->p) & POLL_TYPE_KIND_MASK) == POLL_TYPE_SEMI_SOCKET) {
    return us_internal_socket_close_raw(s, code, reason);
  }
  ssl_set_loop_data(s);
  ssl_update_handshake(s, 1);
  if (ssl_gone(s)) return s;

  if (s->ssl_handshake_state != HANDSHAKE_COMPLETED) {
    /* Surface ECONNRESET-style handshake failure exactly once so callers
     * (fetch, sockets) don't each have to check on_close themselves. */
    ssl_trigger_handshake_econnreset(s);
    if (ssl_gone(s)) return s;
  }

  /* code == 2 (forceful — `_destroy()` / `_handle.close()`): raw-close now,
   * with no close_notify — a bare FIN, like node's destroy (crypto_tls.cc
   * only sends the alert from DoShutdown, the end() path). A destroy-time
   * alert would land in the peer's receive buffer ahead of the FIN, and a
   * peer whose stream is paused never reads it, which holds that stream's
   * 'end'/'close' back forever (node semantics). The destroy path also
   * detaches + poll_ref.unref() right after, so deferring would orphan the
   * us_socket_t.
   *
   * code == 1 (reset — terminate() / abort): no close_notify, only the RST,
   * like node's resetAndDestroy().
   *
   * code == 0 (graceful — `end()` → markInactive → closeAndDetach(.normal)):
   * send close_notify and DEFER the fd close until the peer replies. The
   * graceful path keeps `poll_ref` held until onClose runs, so the loop stays
   * alive to receive the peer's close_notify/FIN; raw-closing here would let
   * the client resolve `close` before the server has even seen our Finished
   * under low-prio fan-out (connectionListener race). The actual raw-close
   * happens via on_end/ZERO_RETURN re-entering this function with
   * SSL_SENT_SHUTDOWN already set (ssl_handle_shutdown then returns 1). */
  if (code != LIBUS_SOCKET_CLOSE_CODE_CLEAN_SHUTDOWN || ssl_handle_shutdown(s)) {
    return us_internal_socket_close_raw(s, code, reason);
  }
  return s;
}
#define ssl_close us_internal_ssl_close

/* `fin_ends_handshake` is 0 only from the writable event, which the read path
 * re-enters while a handshake is in progress: the socket keeps reading after
 * our FIN or close_notify, and the peer's next flight can still complete that
 * handshake. For every other caller a half-closed socket's handshake is over. */
static void ssl_update_handshake(struct us_socket_t *s, int fin_ends_handshake) {
  /* The OpenSSL error queue is per-thread and another socket's failure (a
   * server and a client commonly share this thread) may have left entries on
   * it; clear it before this socket's handshake step so any reason captured
   * below genuinely belongs to this socket's own failure. */
  ERR_clear_error();
    if (!s->ssl || s->ssl_handshake_state != HANDSHAKE_PENDING) return;

  /* SSL_read may have driven the handshake to completion before we got here
   * (TLS 1.3 server: client's Finished + close_notify in one segment lands as
   * ZERO_RETURN with init already finished). Report success based on what
   * BoringSSL actually negotiated, not on whether the peer happens to have
   * already closed — RECEIVED_SHUTDOWN after a completed handshake is a clean
   * close, not a handshake failure. */
  if (SSL_is_init_finished(s_ssl(s))) {
    ssl_trigger_handshake(s, 1);
    return;
  }

  if (us_socket_is_closed(s) || s->ssl_fatal_error ||
      (SSL_get_shutdown(s_ssl(s)) & SSL_RECEIVED_SHUTDOWN) ||
      (fin_ends_handshake && us_internal_ssl_is_shut_down(s))) {
    ssl_trigger_handshake(s, 0);
    return;
  }

  unsigned char ssl_was_in_use = s->ssl_in_use;
  s->ssl_in_use = 1;
  int result = SSL_do_handshake(s_ssl(s));
  s->ssl_in_use = ssl_was_in_use;
  if (!ssl_was_in_use && s->ssl_pending_detach) {
    /* A callback run from inside the handshake destroyed this socket; perform
     * the deferred close now and do not touch the SSL again. */
    s->ssl_pending_detach = 0;
    us_socket_close(s, s->ssl_pending_close_code, NULL);
    return;
  }

  if (SSL_get_shutdown(s_ssl(s)) & SSL_RECEIVED_SHUTDOWN) {
    ssl_close(s, 0, NULL);
    return;
  }

  /* Inline rejection tripped during this drive: nothing more will arrive (a
   * TLS 1.2 client would otherwise wait forever for the server's Finished).
   * ssl_trigger_handshake reports the recorded X509 verdict and closes. */
  if (us_ssl_inline_reject_tripped(s)) {
    ssl_trigger_handshake(s, 0);
    return;
  }

  if (result <= 0) {
    int err = SSL_get_error(s_ssl(s), result);
    if (err == SSL_ERROR_PENDING_CERTIFICATE) {
      /* Suspended by an async SNICallback: stay in HANDSHAKE_PENDING with no
       * poll re-arm; us_socket_sni_resolve() re-drives the handshake when the
       * JS resolution arrives. */
      s->ssl_handshake_state = HANDSHAKE_PENDING;
      return;
    }
    if (err != SSL_ERROR_WANT_READ && err != SSL_ERROR_WANT_WRITE) {
      if (err == SSL_ERROR_SSL || err == SSL_ERROR_SYSCALL) {
        ssl_park_fatal_reason(s);
      }
      ssl_trigger_handshake(s, 0);
      return;
    }
    s->ssl_handshake_state = HANDSHAKE_PENDING;
    s->ssl_write_wants_read = 1;
    /* Keep writable interest only for a blocked write. Setting this for
     * WANT_READ too kept the always-writable socket's writable event firing
     * every tick with zero progress (100% CPU) whenever writable interest
     * existed while the handshake stalled, e.g. pause() mid-handshake.
     * WANT_WRITE's blocked BIO write normally sets it in us_socket_raw_write
     * already; kept for BIO retry paths that buffer without a send. */
    if (err == SSL_ERROR_WANT_WRITE) {
      s->flags.last_write_failed = 1;
    }
    return;
  }

  ssl_trigger_handshake(s, 1);
  if (ssl_gone(s)) return;
  s->ssl_write_wants_read = 1;
}

/* ── Event hooks (called from loop.c / socket.c when s->ssl != NULL) ────── */

struct us_socket_t *us_internal_ssl_on_open(struct us_socket_t *s, int is_client,
                                            char *ip, int ip_length) {
  ssl_set_loop_data(s);
  struct us_socket_t *result = us_dispatch_open(s, is_client, ip, ip_length);
  if (!result || ssl_gone(result)) return result;
  /* Kick the handshake immediately — some peers stall waiting for ClientHello. */
  ssl_set_loop_data(result);
  ssl_update_handshake(result, 1);
  if (ssl_gone(result)) return result;
  result->ssl_first_flight_before_fin = 0;
  if (result->ssl_shutdown_after_first_flight) {
    result->ssl_shutdown_after_first_flight = 0;
    us_internal_ssl_shutdown(result);
  }
  return result;
}

struct us_socket_t *us_internal_ssl_on_close(struct us_socket_t *s, int code, void *reason) {
  ssl_set_loop_data(s);
  struct us_socket_t *ret = us_dispatch_close(s, code, reason);
  /* Free SSL after on_close so user code can still inspect ALPN / cert. */
  us_internal_ssl_detach(s);
  return ret;
}

static int ssl_is_uws_http_tls(struct us_socket_t *s) {
  return us_socket_kind(s) == BUN_SOCKET_KIND_UWS_HTTP_TLS;
}

/* EOF dispatch only for kinds whose user layer consumes 'end' + honors
 * allow_half_open (uWS HTTP server: their context's onEnd owns the EOF;
 * Bun.connect/listen, which node:tls rides on). All other TLS kinds derive
 * EOF from close and keep the historical force-close (dispatching for them
 * strands sockets whose end handler expects the transport to close
 * underneath it). */
static int ssl_wants_eof_dispatch(struct us_socket_t *s) {
  unsigned char kind = us_socket_kind(s);
  if (kind == BUN_SOCKET_KIND_UWS_HTTP_TLS) {
    return 1;
  }
  /* Mid-handshake EOF keeps the force-close so JS surfaces it as a failed
   * handshake (ECONNRESET "socket hang up", like Node) not a clean 'end'. */
  return kind == BUN_SOCKET_KIND_BUN_SOCKET_TLS &&
         s->ssl_handshake_state == HANDSHAKE_COMPLETED;
}

/* Deliver the plaintext EOF to the user layer once, like the plain-TCP path
 * (loop.c dispatches us_dispatch_end for non-SSL sockets). Both TLS EOF
 * paths (peer close_notify -> ZERO_RETURN, and the raw TCP FIN that usually
 * follows it) route through here, so the bit keeps the end handler
 * single-shot. */
static struct us_socket_t *ssl_deliver_eof(struct us_socket_t *s) {
  if (s->ssl_end_delivered) {
    return s;
  }
  s->ssl_end_delivered = 1;
  return us_dispatch_end(s);
}

/* Retry a JS write parked on WANT_READ (written before the handshake
 * finished). No-op while this socket's spill is undrained: the flag is kept
 * so the retry happens after on_writable drains it. */
static struct us_socket_t *ssl_retry_parked_write(struct us_socket_t *s) {
  if (!s->ssl_write_wants_read || s->ssl_read_wants_write) return s;
  struct loop_ssl_data *loop_ssl_data = (struct loop_ssl_data *)s->group->loop->data.ssl_data;
  if (loop_ssl_data && loop_ssl_data->ssl_spill_owner == s) return s;
  s->ssl_write_wants_read = 0;
  return us_internal_ssl_on_writable(s);
}

struct us_socket_t *us_internal_ssl_on_end(struct us_socket_t *s) {
  ssl_set_loop_data(s);
  if (ssl_wants_eof_dispatch(s)) {
    /* Raw TCP FIN under TLS: the peer's write side is gone, so no
     * close_notify reply is ever coming. Record the TLS-level shutdown as
     * received so a later graceful close (an allow_half_open socket ending
     * its side after this EOF) completes immediately in ssl_handle_shutdown
     * instead of deferring for an alert that cannot arrive. */
    if (!ssl_gone(s)) {
      SSL_set_shutdown(s_ssl(s), SSL_get_shutdown(s_ssl(s)) | SSL_RECEIVED_SHUTDOWN);
    }
    s = ssl_deliver_eof(s);
    if (!s || us_socket_is_closed(s)) {
      return s;
    }
    if (s->flags.allow_half_open &&
        (ssl_gone(s) || !(SSL_get_shutdown(s_ssl(s)) & SSL_SENT_SHUTDOWN))) {
      /* Keep the write side alive like the plain-TCP half-open branch in
       * loop.c: TCP permits writing after a received FIN, so queued
       * responses still flush and the app's own end() completes the
       * shutdown. With SENT_SHUTDOWN both directions are closed; fall
       * through so a deferred graceful close completes (mirrors the
       * ZERO_RETURN path; loop.c raw-closes this case first on the
       * epoll/kqueue backend, the libuv one reaches here). */
      return s;
    }
  }
  /* TCP FIN with no half-open: send our close_notify best-effort and
   * raw-close now — deferring (the code==0 path in ssl_close) would wait
   * forever. */
  s = ssl_close(s, 0, NULL);
  if (s && !us_socket_is_closed(s)) {
    if (s->ssl_close_after_spill) {
      /* The close spill-deferred. When on_writable resumes it, the peer's
       * FIN above means its close_notify is never coming, so record the
       * shutdown as received now — otherwise ssl_handle_shutdown defers
       * for the missing alert and the socket hangs. */
      if (!ssl_gone(s)) {
        SSL_set_shutdown(s_ssl(s), SSL_get_shutdown(s_ssl(s)) | SSL_RECEIVED_SHUTDOWN);
      }
    } else {
      s = us_internal_socket_close_raw(s, LIBUS_SOCKET_CLOSE_CODE_CLEAN_SHUTDOWN, NULL);
    }
  }
  return s;
}

struct us_socket_t *us_internal_ssl_on_writable(struct us_socket_t *s) {
  ssl_set_loop_data(s);
  {
    struct loop_ssl_data *loop_ssl_data = (struct loop_ssl_data *)s->group->loop->data.ssl_data;
    /* Ciphertext from a partial batch flush goes out before anything else;
     * while it is pending nothing new may be written for this socket. */
    unsigned int spill_off_before = loop_ssl_data ? loop_ssl_data->ssl_spill_off : 0;
    if (loop_ssl_data && !ssl_drain_spill(loop_ssl_data, s)) {
      /* A writable event that moves zero spill bytes after the peer's
       * readable side has already ended means the peer is gone (send()
       * hit EPIPE/ECONNRESET, folded to 0 by us_socket_raw_write) and
       * this spill will never drain. Returning here would spin the
       * re-armed writable poll on kqueue, since EPOLLERR is not delivered
       * there. Mark the SSL fatal so us_internal_ssl_write returns 0 (the
       * uWS layer's flushed==0-after-FIN guard, or hasFullyDrained() when
       * nothing is buffered, then closes the connection on this dispatch)
       * and dispatch directly, bypassing the is_shut_down gate below that
       * ssl_fatal_error would otherwise trip. On the libuv backend zero
       * progress does not prove death (a stale SEND completion can run
       * after this loop turn refilled the buffer), so confirm with the
       * kernel before declaring the spill undrainable. */
      if (s->ssl_end_delivered && loop_ssl_data->ssl_spill_off == spill_off_before &&
          us_socket_stalled_write_means_peer_gone(s)) {
        ssl_release_spill(s->group->loop, s);
        s->ssl_fatal_error = 1;
        return us_dispatch_writable(s);
      }
      return s;
    }
    if (s->ssl_shutdown_after_spill) {
      s->ssl_shutdown_after_spill = 0;
      us_internal_ssl_shutdown(s);
      if (ssl_gone(s)) return s;
    }
    if (s->ssl_close_after_spill) {
      s->ssl_close_after_spill = 0;
      return us_internal_ssl_close(s, s->ssl_pending_close_code, NULL);
    }
  }
  ssl_update_handshake(s, 0);
  if (ssl_gone(s)) return s;

  if (s->ssl_read_wants_write) {
    s->ssl_read_wants_write = 0;
    /* Re-enter the data path with an empty buffer; SSL_read will pull from
     * the kernel via the next readable event but this lets it flush any
     * pending decrypt that was blocked on a write. */
    s = us_internal_ssl_on_data(s, "", 0);
    if (!s || ssl_gone(s)) return s;
  }
  if (ssl_gone(s) || s->ssl_fatal_error) return s;
  /* uWS HTTP sockets keep the pre-existing SENT_SHUTDOWN suppression: their
   * onWritable clears the teardown timeout armed at shutdown. node sockets
   * still get write-completion dispatch after a half-close in either
   * direction. */
  if (ssl_is_uws_http_tls(s) && us_internal_ssl_is_shut_down(s)) return s;

  if (s->ssl_handshake_state == HANDSHAKE_COMPLETED) {
    s->ssl_write_parked = 0;
    s = us_dispatch_writable(s);
  }
  return s;
}

struct us_socket_t *us_internal_ssl_on_data(struct us_socket_t *s, char *data, int length) {
  /* See ssl_update_handshake: start this socket's SSL processing with a clean
   * per-thread error queue so a captured reason cannot belong to another
   * socket on the same thread. */
  ERR_clear_error();
  /* upgradeTLS [raw, _] half observes ciphertext before SSL_read consumes it.
   * Skip the empty-flush call from on_writable (length==0 → no real wire bytes). */
  if (s->ssl_raw_tap && length > 0) {
    s = us_dispatch_ssl_raw_tap(s, data, length);
    if (!s || us_socket_is_closed(s) || !s->ssl) return s;
  }

  struct loop_ssl_data *loop_ssl_data = ssl_set_loop_data(s);

  loop_ssl_data->ssl_read_input = data;
  loop_ssl_data->ssl_read_input_length = length;

  if (us_socket_is_closed(s)) return NULL;
  /* Neither SENT_SHUTDOWN (TLS half-close from `socket.shutdown()` / node:tls
   * `_final`) nor a sent FIN (POLL_TYPE_SOCKET_SHUT_DOWN) may skip the read
   * loop: a half-closed socket still reads. The peer may have application
   * data in flight that has to be delivered before its close_notify (handled
   * as ZERO_RETURN below) or FIN closes us - under TLS 1.2 this is the
   * NORMAL case for a write()+end() server, because the server finishes its
   * handshake (and ends) one flight before the client can reply. Only bail
   * when reading is genuinely impossible. */
  if (!s->ssl || !s_ssl(s) || s->ssl_fatal_error) {
    ssl_close(s, 0, NULL);
    return NULL;
  }

  /* DO NOT call ssl_update_handshake() before the SSL_read loop. SSL_read
   * drives the handshake itself; firing on_handshake here lets the JS callback
   * write() → ssl_set_loop_data() → clobber the BIO buffer that still holds
   * piggybacked application data. The on_writable tail-call below (gated on
   * ssl_write_wants_read, which on_open()'s update_handshake set) is what
   * pulls the server's handshake event through after each round-trip. */

  int read = 0;
restart:
  while (1) {
    /* While the handshake is pending, SSL_read seals this side's outbound
     * flight (TLS 1.3 client Certificate/Finished, server Hello flight).
     * Batch those records instead of raw-writing each: when the handshake
     * completes in this read, the flight is HELD across the on_handshake
     * dispatch below, so a write the JS callback issues appends to it and
     * us_internal_ssl_write flushes flight + first application data in ONE
     * kernel write (one TCP segment). Two segments let a peer that tears
     * down right after the handshake (node's post-verify destroy, #40653)
     * close with the second segment unread, which turns its FIN teardown
     * into an RST and a bogus ECONNRESET at this side. Node's memory BIO
     * drained once per cycle has the same single-segment shape. Gated on a
     * free spill slot like us_internal_ssl_write, so a short flush cannot
     * clobber another socket's pending ciphertext. */
    int hs_batching = s->ssl_handshake_state == HANDSHAKE_PENDING &&
                      !loop_ssl_data->ssl_write_batching &&
                      !loop_ssl_data->ssl_spill_owner;
    if (hs_batching) loop_ssl_data->ssl_write_batching = 1;
    unsigned char ssl_was_in_use = s->ssl_in_use;
    s->ssl_in_use = 1;
    int just_read = SSL_read(s_ssl(s),
                             loop_ssl_data->ssl_read_output + LIBUS_RECV_BUFFER_PADDING + read,
                             LIBUS_RECV_BUFFER_LENGTH - read);
    s->ssl_in_use = ssl_was_in_use;
    if (hs_batching) {
      loop_ssl_data->ssl_write_batching = 0;
      if (s->ssl_pending_detach) {
        /* Destroyed from a callback inside the read: the flight is cancelled
         * with the connection (the BIO swallows post-detach records the same
         * way). */
        ssl_release_batch(s->group->loop, s);
      } else if (!(s->ssl && s->ssl_handshake_state == HANDSHAKE_PENDING &&
                   SSL_is_init_finished(s_ssl(s)))) {
        /* The handshake did not complete in this read (or already reported):
         * send this round's flight now so the peer can progress. */
        ssl_flush_write_batch(loop_ssl_data, s);
      }
      /* else: handshake just completed - hold the flight for the
       * on_handshake dispatch below. */
    }
    if (!ssl_was_in_use && s->ssl_pending_detach) {
      /* A callback run from inside this read destroyed the socket; perform
       * the deferred close now and stop processing. */
      s->ssl_pending_detach = 0;
      return us_socket_close(s, s->ssl_pending_close_code, NULL);
    }

    if (just_read <= 0) {
      int err = SSL_get_error(s_ssl(s), just_read);
      /* SSL_ERROR_PENDING_CERTIFICATE: the handshake is suspended waiting for
       * an async SNICallback (us_select_cert_cb returned retry). Treat it
       * like WANT_READ - stop the read loop, deliver whatever was decrypted,
       * and park the socket; us_socket_sni_resolve() re-drives the handshake
       * when the JS resolution arrives. */
      if (err != SSL_ERROR_WANT_READ && err != SSL_ERROR_WANT_WRITE &&
          err != SSL_ERROR_PENDING_CERTIFICATE) {
        if (err == SSL_ERROR_WANT_RENEGOTIATE) {
          if (ssl_renegotiate(s)) continue;
          if (ssl_gone(s)) return NULL;
          err = SSL_ERROR_SSL;
        } else if (err == SSL_ERROR_ZERO_RETURN) {
          /* Remote close_notify. A NewSessionTicket that rode in ahead of the
           * close_notify was parked by the new-session callback; deliver it
           * first (wire order - the ticket preceded these bytes, and Node's
           * NewSessionCallback runs before the data reaches JS), then the
           * decrypted data, then the EOF. */
          ssl_flush_pending_events(s);
          if (ssl_gone(s)) return NULL;
          if (read) {
            s = us_dispatch_data(s, loop_ssl_data->ssl_read_output + LIBUS_RECV_BUFFER_PADDING, read);
            if (!s || ssl_gone(s)) return NULL;
          }
          /* close_notify only closed the PEER's write side; when it rides in
           * the same flight as its Finished, the loop tail below is never
           * reached and a parked write would be destroyed with the socket. */
          s = ssl_retry_parked_write(s);
          if (!s || ssl_gone(s)) return NULL;
          /* TLS-level EOF: for uWS HTTP sockets, dispatch the user layer's
           * end handler like a TCP FIN would (see ssl_wants_eof_dispatch),
           * then honor half-open exactly like the plain-TCP eof branch in
           * loop.c. */
          if (ssl_wants_eof_dispatch(s)) {
            s = ssl_deliver_eof(s);
            if (!s || ssl_gone(s)) return NULL;
            if (s->flags.allow_half_open &&
                !(SSL_get_shutdown(s_ssl(s)) & SSL_SENT_SHUTDOWN)) {
              /* close_notify only ended the peer's write side; ours may
               * still flush queued bytes, and the app's own end() completes
               * the shutdown (ssl_handle_shutdown sees RECEIVED_SHUTDOWN and
               * finishes immediately). With SENT_SHUTDOWN both directions are
               * closed and nothing is left to hold open: fall through so the
               * deferred graceful close (code 0, no FIN sent) completes here
               * instead of waiting for a FIN that may never come. A flight
               * held by this read's handshake batching must not be parked
               * past this return. */
              if (loop_ssl_data->ssl_write_batch_len &&
                  loop_ssl_data->ssl_write_batch_owner == s) {
                ssl_flush_write_batch(loop_ssl_data, s);
              }
              return s;
            }
          }
          s = ssl_close(s, 0, NULL);
          if (!s || ssl_gone(s)) return NULL;
          /* Spill-deferred close: the socket is still live; report it so the
           * caller's bookkeeping does not treat it as destroyed. */
          return s;
        }

        if (err == SSL_ERROR_SSL || err == SSL_ERROR_SYSCALL) {
          ssl_park_fatal_reason(s);
        }
        ssl_close(s, 0, NULL);
        loop_ssl_data->ssl_last_fatal_error[0] = 0;
        return NULL;
      } else {
        if (err == SSL_ERROR_WANT_WRITE) s->ssl_read_wants_write = 1;

        /* If the BIO still has unread ciphertext at this point, the TLS
         * framing is broken — close. */
        if (loop_ssl_data->ssl_read_input_length) {
          return ssl_close(s, 0, NULL);
        }
        /* SSL_read drove the handshake to completion but returned no app
         * data (peer's Finished arrived alone). Fire on_handshake here —
         * deferring to the on_writable tail-call lets the low-prio queue
         * (SSL_in_init throttles to 5/tick) reorder the server's
         * secureConnection event past the client's close under fan-out
         * loads. The save/restore below makes this safe even if the JS
         * callback writes; with read==0 the buffer is empty anyway. */
        if (s->ssl_handshake_state == HANDSHAKE_PENDING && SSL_is_init_finished(s_ssl(s))) {
          ssl_trigger_handshake(s, 1);
          if (ssl_gone(s)) return NULL;
          /* A write parked before the handshake (node:https queues its request
           * that way) is retried with the flight still held, so both leave in
           * one segment, like a write from the callback. */
          if (s->ssl_write_parked) {
            s = ssl_retry_parked_write(s);
            if (!s || ssl_gone(s)) return NULL;
          }
          loop_ssl_data->ssl_socket = s;
          /* The callback and the retry ran with the flight held: a write they
           * issued already flushed flight + data together; send whatever is
           * still held. */
          if (loop_ssl_data->ssl_write_batch_len &&
              loop_ssl_data->ssl_write_batch_owner == s) {
            ssl_flush_write_batch(loop_ssl_data, s);
          }
        }
        if (!read) break;

        /* Deliver any parked session/keylog payloads BEFORE the data: the
         * SSL_read that parked them has returned, the ticket preceded these
         * bytes on the wire (Node's NewSessionCallback also runs before the
         * data reaches JS), and the data dispatch may run JS that closes the
         * socket (an agent with keepAlive off destroys it as soon as the
         * response completes) - the tail flush below never runs then and the
         * parked session would be dropped. ssl_read_input_length is 0 here
         * (checked above), so JS writing from the session handler cannot
         * clobber pending ciphertext. */
        ssl_flush_pending_events(s);
        if (ssl_gone(s)) return NULL;
        s = us_dispatch_data(s, loop_ssl_data->ssl_read_output + LIBUS_RECV_BUFFER_PADDING, read);
        if (!s || ssl_gone(s)) return NULL;
        break;
      }
    } else if (s->ssl_handshake_state != HANDSHAKE_COMPLETED) {
      /* SSL_read returned application data with the handshake having
       * finished inside it. Fire on_handshake before delivering data so the
       * caller can inspect ALPN and re-tag the socket. The save/restore lets
       * the JS callback write() without clobbering the BIO buffer that may
       * still hold ciphertext for the next SSL_read. (PR #25946 gated this to
       * clients because the server-side fire reordered node:http2/grpc-js
       * session setup; the save/restore here is what was missing — those
       * suites are re-verified below.) */
      char *saved_input = loop_ssl_data->ssl_read_input;
      unsigned int saved_length = loop_ssl_data->ssl_read_input_length;
      unsigned int saved_offset = loop_ssl_data->ssl_read_input_offset;
      ssl_trigger_handshake(s, 1);
      if (ssl_gone(s)) return NULL;
      loop_ssl_data->ssl_read_input = saved_input;
      loop_ssl_data->ssl_read_input_length = saved_length;
      loop_ssl_data->ssl_read_input_offset = saved_offset;
      loop_ssl_data->ssl_socket = s;
      /* Send what the callback's own write did not already flush of the held
       * flight. No parked-write retry here: its writable dispatch would run
       * before the data this read decrypted reaches the caller. */
      if (loop_ssl_data->ssl_write_batch_len &&
          loop_ssl_data->ssl_write_batch_owner == s) {
        ssl_flush_write_batch(loop_ssl_data, s);
      }
    }

    read += just_read;

    if (read == LIBUS_RECV_BUFFER_LENGTH) {
      char *saved_input = loop_ssl_data->ssl_read_input;
      unsigned int saved_length = loop_ssl_data->ssl_read_input_length;
      unsigned int saved_offset = loop_ssl_data->ssl_read_input_offset;
      /* Same flush-before-dispatch as the loop exit below; the save/restore
       * around this block protects the ciphertext still in the BIO from any
       * JS the session handler runs. */
      ssl_flush_pending_events(s);
      if (ssl_gone(s)) return NULL;
      s = us_dispatch_data(s, loop_ssl_data->ssl_read_output + LIBUS_RECV_BUFFER_PADDING, read);
      if (!s || ssl_gone(s)) return NULL;
      loop_ssl_data->ssl_read_input = saved_input;
      loop_ssl_data->ssl_read_input_length = saved_length;
      loop_ssl_data->ssl_read_input_offset = saved_offset;
      loop_ssl_data->ssl_socket = s;
      read = 0;
      goto restart;
    }
  }

  /* If the last SSL_write failed with WANT_READ and we've now read, give the
   * application a writable callback — but not if SSL_read just told us it
   * needs to write first (would recurse). Re-check s->ssl: any dispatch above may
   * have closed and freed s->ssl. */
  if (ssl_gone(s)) return NULL;
  s = ssl_retry_parked_write(s);
  if (!s || ssl_gone(s)) return NULL;

  /* The SSL_read loop above is fully unwound; deliver any session the
   * new-session callback parked while it ran. The JS this dispatches may
   * close the socket. */
  ssl_flush_pending_events(s);
  if (ssl_gone(s)) return NULL;

  return s;
}

/* Throttle reading for sockets still in TLS init — the kernel buffers for us
 * and the expensive crypto work is the first step, so deprioritising
 * mid-handshake sockets keeps fully-established ones responsive under load. */
int us_internal_ssl_is_low_prio(struct us_socket_t *s) {
  return SSL_in_init(s_ssl(s));
}

/* ── Socket-level accessors / write / shutdown ───────────────────────────── */

int us_internal_ssl_is_shut_down(struct us_socket_t *s) {
    /* Check the TCP poll-type directly; us_socket_is_shut_down() is TCP-level
   * and does not re-dispatch to SSL. */
  if (us_internal_poll_type(&s->p) == POLL_TYPE_SOCKET_SHUT_DOWN) return 1;
  return !s->ssl || !s_ssl(s) || (SSL_get_shutdown(s_ssl(s)) & SSL_SENT_SHUTDOWN) || s->ssl_fatal_error;
}

int us_internal_ssl_is_handshake_finished(struct us_socket_t *s) {
  if (!s->ssl || !s_ssl(s)) return 0;
  return SSL_is_init_finished(s_ssl(s));
}

int us_internal_ssl_handshake_callback_has_fired(struct us_socket_t *s) {
  return s->ssl && s->ssl_handshake_state == HANDSHAKE_COMPLETED;
}

void *us_internal_ssl_get_native_handle(struct us_socket_t *s) {
  return s->ssl ? s_ssl(s) : NULL;
}

/* Ciphertext bytes already sealed for `s` and counted as written by
 * us_internal_ssl_write, still waiting on a writable event to reach the
 * kernel. uWS's AsyncSocket::hasFullyDrained() checks this so the HTTP
 * close-after-drain gates do not fire while the last batch is still in
 * userspace. */
unsigned int us_internal_ssl_spill_pending(struct us_socket_t *s) {
  struct loop_ssl_data *loop_ssl_data = (struct loop_ssl_data *)s->group->loop->data.ssl_data;
  if (!loop_ssl_data || loop_ssl_data->ssl_spill_owner != s) return 0;
  return loop_ssl_data->ssl_spill_len - loop_ssl_data->ssl_spill_off;
}

int us_internal_ssl_write(struct us_socket_t *s, const char *data, int length) {
  struct us_iovec_t iov = {(void *)data, (size_t)length};
  return us_internal_ssl_writev(s, &iov, 1);
}

/* The records of every part share one batch, so they reach the kernel in one write. Returns the plaintext bytes taken, in order. */
int us_internal_ssl_writev(struct us_socket_t *s, const struct us_iovec_t *iov, int count) {
  while (count && iov->iov_len == 0) iov++, count--;
  if (us_socket_is_closed(s) || us_internal_ssl_is_shut_down(s) || count == 0) return 0;

  /* Fast-path connect attaches SSL eagerly on a SEMI_SOCKET (see
   * us_socket_group_connect_resolved_dns); on_open hasn't fired yet so
   * SNI/ALPN aren't on the SSL. SSL_write here would serialize the
   * ClientHello without them. Report 0 so the caller buffers; on_open →
   * ssl_update_handshake drains it. Mirrors the SEMI_SOCKET guard in
   * us_internal_ssl_close above. */
  if ((us_internal_poll_type(&s->p) & POLL_TYPE_KIND_MASK) == POLL_TYPE_SEMI_SOCKET) {
    s->ssl_write_parked = 1;
    return 0;
  }

  /* Called from inside SSL_read/SSL_do_handshake on this socket (an ALPN/SNI
   * callback writing): wait for the handshake, same as WANT_READ below. */
  if (s->ssl_in_use) {
    s->ssl_write_wants_read = 1;
    s->ssl_write_parked = 1;
    return 0;
  }

    struct loop_ssl_data *loop_ssl_data = (struct loop_ssl_data *)s->group->loop->data.ssl_data;

  /* Earlier batched records of ours must reach the wire before anything new:
   * SSL already counts them as written. While they cannot be delivered, the
   * caller buffers plaintext (return 0), bounding the in-flight ciphertext. */
  if (!ssl_drain_spill(loop_ssl_data, s)) {
    return 0;
  }

  loop_ssl_data->ssl_read_input_length = 0;
  loop_ssl_data->ssl_socket = s;

  /* Batch this write's records unless another socket's spill occupies the
   * slot (then write through per record, the pre-batching behavior).
   *
   * Plaintext is consumed in record-size slices and the batch flushes every
   * few records: the moment the wire blocks we STOP consuming, so the bytes
   * we report as written are honest up to one bounded spill. Reporting a
   * whole large write as consumed while its ciphertext sat in memory let the
   * layers above fire 'finish' and close before the data reached the wire. */
  int outer_batching = loop_ssl_data->ssl_write_batching;
  int batching = (loop_ssl_data->ssl_spill_owner == NULL);
  loop_ssl_data->ssl_write_batching = batching;

  int total = 0;
  int last_ssl_written = 1;
  size_t part_offset = 0;
  while (count) {
    if (part_offset == iov->iov_len) {
      iov++, count--, part_offset = 0;
      continue;
    }
    size_t part_left = iov->iov_len - part_offset;
    int chunk = part_left > 16384 ? 16384 : (int)part_left;
    /* Same deferred-close protocol as the SSL_do_handshake/SSL_read drivers. */
    s->ssl_in_use = 1;
    last_ssl_written = SSL_write(s_ssl(s), (const char *)iov->iov_base + part_offset, chunk);
    s->ssl_in_use = 0;
    if (s->ssl_pending_detach) {
      /* Closed from inside the call: drop this write's records (and any held
       * flight of ours they extend) and close now. */
      loop_ssl_data->ssl_write_batching = outer_batching;
      ssl_release_batch(s->group->loop, s);
      s->ssl_pending_detach = 0;
      us_socket_close(s, s->ssl_pending_close_code, NULL);
      return 0;
    }
    if (last_ssl_written <= 0) break;
    total += last_ssl_written;
    part_offset += (size_t)last_ssl_written;
    /* A batching allocation failure marks the socket fatal from inside the BIO;
     * stop sealing records for a connection that is being torn down. */
    if (s->ssl_fatal_error) break;
    if (batching && loop_ssl_data->ssl_write_batch_len >= 131072) {
      if (!ssl_flush_write_batch(loop_ssl_data, s)) break; /* wire blocked: stop consuming */
      if (s->ssl_fatal_error) break;
    }
  }
  loop_ssl_data->ssl_write_batching = outer_batching;
  if (batching) {
    ssl_flush_write_batch(loop_ssl_data, s);
  }
  if (s->ssl_fatal_error) return 0;
  if (total > 0) return total;
  if (last_ssl_written <= 0) {
    int err = SSL_get_error(s_ssl(s), last_ssl_written);
    if (err == SSL_ERROR_WANT_READ) {
      s->ssl_write_wants_read = 1;
      s->ssl_write_parked = 1;
    } else if (err == SSL_ERROR_SSL || err == SSL_ERROR_SYSCALL) {
      /* SSL_write drives the handshake when it has not finished, so this is
       * where a handshake-configuration failure (impossible version window,
       * no shared cipher) surfaces for a caller that wrote before
       * 'secureConnect'. Park the reason: the handshake dispatch this failure
       * triggers reports it instead of a bare verification verdict. */
      ssl_park_fatal_reason(s);
    }
  }
  return 0;
}

void us_internal_ssl_shutdown(struct us_socket_t *s) {
  if (us_socket_is_closed(s) || us_internal_ssl_is_shut_down(s)) return;
  if (s->ssl_first_flight_before_fin) {
    s->ssl_shutdown_after_first_flight = 1;
    return;
  }

  /* Spilled ciphertext is data the layers above already count as written;
   * a FIN/close_notify now would cut it off. Finish the shutdown from the
   * writable event once the spill drains. A held batch (an end() issued
   * from the on_handshake callback while the final flight is still parked)
   * is the same kind of debt: flush it first so the close_notify and FIN
   * below follow the flight, not precede it. */
  {
    struct loop_ssl_data *loop_ssl_data = (struct loop_ssl_data *)s->group->loop->data.ssl_data;
    if (loop_ssl_data && loop_ssl_data->ssl_write_batch_len &&
        loop_ssl_data->ssl_write_batch_owner == s) {
      ssl_flush_write_batch(loop_ssl_data, s);
    }
    if (loop_ssl_data && loop_ssl_data->ssl_spill_owner == s) {
      if (!ssl_drain_spill(loop_ssl_data, s)) {
        s->ssl_shutdown_after_spill = 1;
        return;
      }
    }
  }

  /* Half-close (node's end()): send close_notify, then FIN, and KEEP reading.
   * BoringSSL only refuses writes after SSL_shutdown (write_shutdown); reads
   * stay open until the peer's close_notify, and the data path reads with
   * SENT_SHUTDOWN set, so a TLS 1.2 write()+end() server still receives the
   * reply the peer sends after processing our data. A bare FIN here reads as
   * truncation ("unexpected eof") to compliant peers. */
  if (!SSL_in_init(s_ssl(s)) && !(SSL_get_shutdown(s_ssl(s)) & SSL_RECEIVED_SHUTDOWN)) {
    /* ssl_handle_shutdown sends the close_notify (BoringSSL's do_tls_write
     * prepends any pending TLS 1.3 NewSessionTicket flight to the alert, so
     * tickets are still delivered) and owns the error handling. */
    ssl_handle_shutdown(s);
    us_internal_socket_raw_shutdown(s);
    return;
  }

    struct loop_ssl_data *loop_ssl_data = (struct loop_ssl_data *)s->group->loop->data.ssl_data;
  loop_ssl_data->ssl_read_input_length = 0;
  loop_ssl_data->ssl_socket = s;

  int ret = SSL_shutdown(s_ssl(s));

  if (SSL_in_init(s_ssl(s)) || SSL_get_quiet_shutdown(s_ssl(s))) {
    us_internal_socket_raw_shutdown(s);
    return;
  }
  if (ret < 0) {
    int err = SSL_get_error(s_ssl(s), ret);
    if (err == SSL_ERROR_SSL || err == SSL_ERROR_SYSCALL) {
      ERR_clear_error();
      s->ssl_fatal_error = 1;
    }
  }
  /* RECEIVED_SHUTDOWN brought us here, so the TLS shutdown is complete; FIN the
   * TCP write side so the poll type becomes SHUT_DOWN and the loop's
   * is_shut_down eof branch can close once both halves are done. */
  us_internal_socket_raw_shutdown(s);
}

/* Resume a handshake suspended by an async SNICallback. `ctx` (may be NULL =
 * fall through to the default context) carries a reference that this call
 * consumes. `error` != 0 aborts the handshake instead. No-op when the socket
 * already closed/detached (the pending JS resolution outlived it). */
void us_socket_sni_resolve(struct us_socket_t *s, struct ssl_ctx_st *ctx, int error) {
  if (!s || us_socket_is_closed(s) || !s->ssl || !s_ssl(s)) {
    if (ctx) SSL_CTX_free(ctx);
    return;
  }
  if (s->ssl_sni_pending != US_SNI_WAITING) {
    /* Not actually suspended (late/duplicate resolution). */
    if (ctx) SSL_CTX_free(ctx);
    return;
  }
  struct loop_ssl_data *loop_ssl_data = ssl_set_loop_data(s);
  SSL_CTX *outer_ctx = loop_ssl_data->ssl_sni_resolved_ctx;
  loop_ssl_data->ssl_sni_resolved_ctx = NULL;
  if (error) {
    s->ssl_sni_pending = US_SNI_ERROR;
    if (ctx) SSL_CTX_free(ctx);
    /* Match the synchronous abort path: the connection is dropped WITHOUT a
     * TLS alert (Node's behavior for SNICallback errors). Mark the socket for
     * the deferred close before re-driving the handshake, so the BIO swallows
     * the handshake_failure alert BoringSSL queues for select_cert_error and
     * the epilogue closes the socket; the client just sees the connection go
     * away ("disconnected before secure TLS connection was established"). */
    s->ssl_pending_detach = 1;
    s->ssl_pending_close_code = 0;
  } else {
    s->ssl_sni_pending = US_SNI_RESOLVED;
    loop_ssl_data->ssl_sni_resolved_ctx = ctx; /* may be NULL = default ctx */
  }
  /* Re-drive the handshake; select_cert_cb re-fires and consumes the state. */
  ssl_update_handshake(s, 1);
  if (loop_ssl_data->ssl_sni_resolved_ctx) SSL_CTX_free(loop_ssl_data->ssl_sni_resolved_ctx);
  loop_ssl_data->ssl_sni_resolved_ctx = outer_ctx;
}

/* ── Adopt-TLS (STARTTLS / Bun.connect upgrade) ──────────────────────────── */

/* Feed bytes that were already read off the wire (e.g. a ClientHello consumed
 * by the plain-TCP layer before the socket was adopted into TLS) through the
 * same decrypt path as bytes arriving from the kernel. */
struct us_socket_t *us_socket_tls_feed(struct us_socket_t *s, const char *data, int length) {
  if (us_socket_is_closed(s) || !s->ssl || length <= 0) return s;
  return us_internal_ssl_on_data(s, (char *)data, length);
}

struct us_socket_t *us_socket_adopt_tls(struct us_socket_t *s,
                                        struct us_socket_group_t *group,
                                        unsigned char kind, struct ssl_ctx_st *ssl_ctx,
                                        const char *sni, int is_client, int request_cert,
                                        int reject_unauthorized, int old_ext_size,
                                        int ext_size) {
  if (us_socket_is_closed(s)) return NULL;

  struct us_socket_t *new_s = us_socket_adopt(s, group, kind, old_ext_size, ext_size);
  if (!new_s) return NULL;

  /* is_client=0 puts the SSL in accept state (server-side upgrade, e.g.
   * `new tls.TLSSocket(acceptedSocket, { isServer: true })`); there is no
   * listener for an adopted socket, so SNI resolves from the single ssl_ctx. */
  us_internal_ssl_attach(new_s, ssl_ctx, is_client, sni, NULL);
  if (!is_client && new_s->ssl) {
    /* Node's TLSWrap::SetVerifyMode runs unconditionally on server sockets:
     * !requestCert must force SSL_VERIFY_NONE, or a shared SSL_CTX built with
     * `ca` leaks its FAIL_IF_NO_PEER_CERT mode and rejects cert-less clients. */
    SSL_set_verify(new_s->ssl,
                   request_cert
                       ? SSL_VERIFY_PEER | (reject_unauthorized
                                                ? SSL_VERIFY_FAIL_IF_NO_PEER_CERT
                                                : 0)
                       : SSL_VERIFY_NONE,
                   us_verify_callback);
  }
  us_socket_resume(new_s);
  /* Do NOT kick the handshake or dispatch on_open here — the caller hasn't
   * repointed the ext slot yet, so any dispatch (open/handshake/close) would
   * land in the old (TCP) owner. Caller stashes ext, sets kind, fires its own
   * onOpen, then calls us_socket_start_tls_handshake() to send ClientHello. */
  return new_s;
}

void us_socket_start_tls_handshake(struct us_socket_t *s) {
  if (!s->ssl || us_socket_is_closed(s)) return;
  ssl_set_loop_data(s);
  ssl_update_handshake(s, 1);
}

/* ── SNI on listen sockets ───────────────────────────────────────────────── */

static void sni_node_destructor(void *user) {
  struct sni_node_t *node = (struct sni_node_t *)user;
  if (!node) return;
  SSL_CTX_free(node->ctx);
  us_free(node);
}

static struct sni_node_t *resolve_listener_ctx(struct us_listen_socket_t *ls, const char *hostname) {
  if (!ls->sni) return NULL;
  return (struct sni_node_t *)sni_find(ls->sni, hostname);
}

#define US_SNI_POLICY_REQUEST_CERT ((uintptr_t)1)
#define US_SNI_POLICY_REJECT_UNAUTHORIZED ((uintptr_t)2)

static _Atomic uint32_t us_sni_sid_ctx_counter = 0;

/* Record the client-certificate policy of a per-serverName entry on its
 * SSL_CTX and give it a session-id context of its own: SSL_set_SSL_CTX copies
 * the certificate (with its sid_ctx) but not verify_mode, so the SNI switch
 * reapplies the policy per connection, and a session established under any
 * other context is never resumed under this one (a resumed handshake skips
 * client authentication entirely). */
void us_ssl_ctx_set_sni_policy(SSL_CTX *ctx, int request_cert, int reject_unauthorized) {
  if (!ctx) return;
  us_ex_idx_ensure();
  uintptr_t packed = (request_cert ? US_SNI_POLICY_REQUEST_CERT : 0) |
                     (reject_unauthorized ? US_SNI_POLICY_REJECT_UNAUTHORIZED : 0);
  SSL_CTX_set_ex_data(ctx, us_ctx_sni_policy_ex_idx, (void *)packed);
  uint32_t sid = atomic_fetch_add(&us_sni_sid_ctx_counter, 1) + 1;
  SSL_CTX_set_session_id_context(ctx, (const uint8_t *)&sid, sizeof(sid));
}

/* Every SNI context switch goes through here: SSL_set_SSL_CTX alone leaves
 * verify_mode as inherited from the default context at accept, so a
 * per-serverName entry's requestCert/rejectUnauthorized are added on top of
 * it (the connection's inherited requirement is kept). A context without a
 * recorded policy (node:tls SecureContext, whose policy is server-level)
 * leaves the connection's verify mode untouched.
 *
 * SSL_set_SSL_CTX also copies the context's session id context, which for
 * contexts built in Rust is the digest of their options
 * (create_ssl_context_with_digest). BoringSSL checks it after this switch, so
 * a session issued under other options is not resumed and the client is
 * authenticated again, against this context's CA. That refusal is deliberate
 * (RFC 6066 section 3; openssl/ssl.h: "partition session caches between SNI
 * hosts") and must not be relaxed for parity with another runtime. */
static void us_ssl_apply_selected_ctx(SSL *ssl, SSL_CTX *ctx) {
  SSL_set_SSL_CTX(ssl, ctx);
  if (us_ctx_sni_policy_ex_idx < 0) return;
  uintptr_t policy = (uintptr_t)SSL_CTX_get_ex_data(ctx, us_ctx_sni_policy_ex_idx);
  if (!(policy & US_SNI_POLICY_REQUEST_CERT)) return;
  int mode = SSL_get_verify_mode(ssl) | SSL_VERIFY_PEER;
  if (policy & US_SNI_POLICY_REJECT_UNAUTHORIZED) mode |= SSL_VERIFY_FAIL_IF_NO_PEER_CERT;
  SSL_set_verify(ssl, mode, us_verify_callback);
}

/* Whether the SNI-selected context of this connection demands closing on a
 * client-certificate verification error (requestCert && rejectUnauthorized
 * of the per-serverName entry). */
int us_ssl_ctx_reject_unauthorized(SSL_CTX *ctx) {
  if (!ctx || us_ctx_sni_policy_ex_idx < 0) return 0;
  uintptr_t packed = (uintptr_t)SSL_CTX_get_ex_data(ctx, us_ctx_sni_policy_ex_idx);
  return (packed & US_SNI_POLICY_REQUEST_CERT) &&
         (packed & US_SNI_POLICY_REJECT_UNAUTHORIZED);
}

int us_socket_server_name_reject_unauthorized(struct us_socket_t *s) {
  if (!s->ssl) return 0;
  return us_ssl_ctx_reject_unauthorized(SSL_get_SSL_CTX(s_ssl(s)));
}

/* Extracts the host_name from the ClientHello's server_name extension.
 * Returns the length written to `out` (NUL-terminated), or 0 if absent /
 * malformed. BoringSSL does document SSL_get_servername as usable inside
 * select_certificate_cb (extract_sni runs before the callback), but every
 * caller here reads the raw ClientHello instead so the lookup depends only
 * on the early-callback contract, not on SSL* handshake state. */
static size_t us_client_hello_servername(const SSL_CLIENT_HELLO *hello, char *out, size_t out_len) {
  const uint8_t *ext;
  size_t ext_len;
  if (!SSL_early_callback_ctx_extension_get(hello, TLSEXT_TYPE_server_name, &ext, &ext_len)) {
    return 0;
  }
  /* server_name extension: u16 list_len, then entries of (u8 type, u16 len, bytes). */
  if (ext_len < 5) return 0;
  size_t list_len = ((size_t)ext[0] << 8) | ext[1];
  if (list_len + 2 != ext_len) return 0;
  const uint8_t *p = ext + 2;
  size_t remaining = list_len;
  while (remaining >= 3) {
    uint8_t type = p[0];
    size_t name_len = ((size_t)p[1] << 8) | p[2];
    if (name_len + 3 > remaining) return 0;
    if (type == TLSEXT_NAMETYPE_host_name) {
      if (name_len == 0 || name_len >= out_len) return 0;
      memcpy(out, p + 3, name_len);
      out[name_len] = 0;
      return name_len;
    }
    p += 3 + name_len;
    remaining -= 3 + name_len;
  }
  return 0;
}

/* The async-capable certificate selector. Registered (instead of relying on
 * sni_cb alone) on listener contexts that have a dynamic JS resolver, so an
 * SNICallback that cannot answer synchronously suspends the handshake
 * (ssl_select_cert_retry -> SSL_ERROR_PENDING_CERTIFICATE) instead of falling
 * through to the default context. us_socket_sni_resolve() resumes it. */
static enum ssl_select_cert_result_t us_select_cert_cb(const SSL_CLIENT_HELLO *hello) {
  SSL *ssl = hello->ssl;
  struct us_socket_t *s = ssl ? us_ssl_socket(ssl) : NULL;
  if (!s) return ssl_select_cert_success;
  struct us_ssl_rare_t *rare = us_ssl_rare(ssl);
  struct us_listen_socket_t *ls = rare ? rare->listener : NULL;

  /* A previous suspension being resumed: consume the stored result. */
  if (s->ssl_sni_pending == US_SNI_RESOLVED) {
    s->ssl_sni_pending = US_SNI_NONE;
    struct loop_ssl_data *loop_ssl_data = (struct loop_ssl_data *)BIO_get_data(SSL_get_wbio(ssl));
    SSL_CTX *resolved_ctx = loop_ssl_data->ssl_sni_resolved_ctx;
    loop_ssl_data->ssl_sni_resolved_ctx = NULL;
    if (resolved_ctx) {
      us_ssl_apply_selected_ctx(ssl, resolved_ctx);
      SSL_CTX_free(resolved_ctx);
      return ssl_select_cert_success;
    }
    /* The asynchronous resolution selected nothing (cb(null, null)): fall
     * through to the static SNI tree below, exactly like a synchronous
     * resolver returning null - the resume must not skip the tree fallback
     * the sync path gets. */
    if (ls) {
      /* Read the servername from the raw ClientHello, same as the first-call
       * path below: that is the read the early-callback contract guarantees
       * (SSL_get_servername happens to be populated by the resume re-drive
       * today, but the raw parse does not depend on that). */
      char resumed_host[256];
      if (us_client_hello_servername(hello, resumed_host, sizeof(resumed_host))) {
        struct sni_node_t *resumed_node = resolve_listener_ctx(ls, resumed_host);
        if (resumed_node) {
          us_ssl_apply_selected_ctx(ssl, resumed_node->ctx);
        }
      }
    }
    return ssl_select_cert_success;
  }
  if (s->ssl_sni_pending == US_SNI_ERROR) {
    s->ssl_sni_pending = US_SNI_NONE;
    return ssl_select_cert_error;
  }
  if (s->ssl_sni_pending == US_SNI_WAITING) {
    /* Still waiting (a spurious re-drive); keep suspending. */
    return ssl_select_cert_retry;
  }

  /* With no listener resolver, the socket may still carry its own: a
   * server-side socket adopted into TLS with its own SNICallback. */
  const int no_listener_resolver = (!ls || !ls->on_server_name);
  if (no_listener_resolver && !s->ssl_sni_resolver) {
    return ssl_select_cert_success;
  }

  char hostname[256];
  if (!us_client_hello_servername(hello, hostname, sizeof(hostname))) {
    return ssl_select_cert_success;
  }

  /* The dynamic resolver (the user's SNICallback) runs FIRST, matching Node
   * where a user-provided SNICallback replaces the default SNI handling
   * entirely (tree-first would shadow the callback for every name that also
   * has an addContext entry). The static tree (addContext entries) is the
   * fallback when the resolver selects nothing, which is also the
   * no-user-callback path: the JS dispatch returns undefined immediately in
   * that case. */

  void *saved_loop_state[US_SSL_LOOP_STATE_SLOTS];
  us_internal_ssl_loop_state_save(ssl, saved_loop_state);
  int abort_handshake = 0;
  SSL_CTX *dyn =
      no_listener_resolver ? us_dispatch_socket_server_name(s, hostname, &abort_handshake)
                           : ls->on_server_name(ls, hostname, &abort_handshake, s);
  us_internal_ssl_loop_state_restore(saved_loop_state);

  if (abort_handshake == 1) {
    /* Error/invalid context: drop the connection without an alert (the
     * deferred-close + BIO-swallow path, same as sni_cb). */
    s->ssl_pending_detach = 1;
    s->ssl_pending_close_code = 0;
    return ssl_select_cert_error;
  }
  if (abort_handshake == 2) {
    /* The JS resolver answered "pending": suspend until us_socket_sni_resolve. */
    s->ssl_sni_pending = US_SNI_WAITING;
    return ssl_select_cert_retry;
  }
  if (dyn) {
    us_ssl_apply_selected_ctx(ssl, dyn);
    SSL_CTX_free(dyn);
    return ssl_select_cert_success;
  }

  /* No dynamic selection: fall back to the static SNI tree (the
   * addContext() entries). An adopted socket has no tree. */
  if (ls) {
    struct sni_node_t *node = resolve_listener_ctx(ls, hostname);
    if (node) {
      us_ssl_apply_selected_ctx(ssl, node->ctx);
    }
  }
  return ssl_select_cert_success;
}

static int sni_cb(SSL *ssl, int *al, void *arg) {
  (void)al; (void)arg;
  if (!ssl) return SSL_TLSEXT_ERR_NOACK;
  /* The listener is per-SSL (set at accept), not the CTX-level arg — the
   * SSL_CTX is shared and may outlive any one listener. */
  struct us_ssl_rare_t *rare = us_ssl_rare(ssl);
  struct us_listen_socket_t *ls = rare ? rare->listener : NULL;
  if (!ls) return SSL_TLSEXT_ERR_OK;
  if (ls->on_server_name) {
    /* A dynamic resolver (user SNICallback) exists: us_select_cert_cb already
     * ran it - and the static-tree fallback - at the earlier
     * select-certificate stage. Consulting the tree again here would
     * OVERWRITE the resolver's per-connection selection with the tree entry,
     * undoing the SNICallback-takes-precedence contract. */
    return SSL_TLSEXT_ERR_OK;
  }
  const char *hostname = SSL_get_servername(ssl, TLSEXT_NAMETYPE_host_name);
  if (hostname && hostname[0]) {
    /* Static SNI tree only (no dynamic resolver registered for this
     * listener). */
    struct sni_node_t *node = resolve_listener_ctx(ls, hostname);
    if (node) {
      us_ssl_apply_selected_ctx(ssl, node->ctx);
    }
  }
  return SSL_TLSEXT_ERR_OK;
}

int us_listen_socket_add_server_name(struct us_listen_socket_t *ls,
                                     const char *hostname_pattern,
                                     SSL_CTX *ctx, void *user) {
  SSL_CTX *default_ctx = ls->ssl_ctx;
  if (!default_ctx) return -1;

  if (!ls->sni) {
    ls->sni = sni_new();
    /* Idempotent across listeners sharing this SSL_CTX — the callback reads
     * the listener off the SSL, not the arg. */
    SSL_CTX_set_tlsext_servername_callback(default_ctx, sni_cb);
  }

  struct sni_node_t *node = us_malloc(sizeof(struct sni_node_t));
  node->ctx = ctx;
  node->user = user;
  SSL_CTX_up_ref(ctx);
  /* Stash userdata on the SSL_CTX too so per-socket lookup via
   * SSL_get_SSL_CTX works regardless of which ctx the SNI cb selected. */
  us_ex_idx_ensure();
  SSL_CTX_set_ex_data(ctx, us_sni_ex_idx, user);

  if (sni_add(ls->sni, hostname_pattern, node)) {
    /* Duplicate hostname — propagate so App.h's `if (result != 0)` rollback
     * (which frees the per-domain HttpRouter it just built) actually fires. */
    sni_node_destructor(node);
    return 1;
  }
  return 0;
}

void us_listen_socket_remove_server_name(struct us_listen_socket_t *ls,
                                         const char *hostname_pattern) {
  if (!ls->sni) return;
  struct sni_node_t *node = (struct sni_node_t *)sni_remove(ls->sni, hostname_pattern);
  sni_node_destructor(node);
}

void *us_listen_socket_find_server_name_userdata(struct us_listen_socket_t *ls,
                                                 const char *hostname_pattern) {
  if (!ls->sni) return NULL;
  struct sni_node_t *node = (struct sni_node_t *)sni_find(ls->sni, hostname_pattern);
  return node ? node->user : NULL;
}

/* Returns the SSL_CTX registered for `hostname_pattern` via
 * us_listen_socket_add_server_name, or NULL. Owned - the caller must release
 * the reference. The on_server_name resolvers return owned references (the
 * SNI dispatcher frees them after SSL_set_SSL_CTX takes its own), so the
 * tree's reference must not be handed out as a borrow. */
struct ssl_ctx_st *us_listen_socket_find_server_name_ctx(struct us_listen_socket_t *ls,
                                                         const char *hostname_pattern) {
  if (!ls->sni) return NULL;
  struct sni_node_t *node = (struct sni_node_t *)sni_find(ls->sni, hostname_pattern);
  if (!node || !node->ctx) return NULL;
  SSL_CTX_up_ref(node->ctx);
  return node->ctx;
}

void us_listen_socket_set_default_ssl_ctx(struct us_listen_socket_t *ls,
                                          SSL_CTX *ctx) {
  if (ls->ssl_ctx == ctx) return;
  SSL_CTX_up_ref(ctx);
  /* Carry over the listener-level callbacks registered on the old default. */
  if (ls->sni) {
    SSL_CTX_set_tlsext_servername_callback(ctx, sni_cb);
  }
  if (ls->on_server_name) {
    SSL_CTX_set_select_certificate_cb(ctx, us_select_cert_cb);
  }
  if (ls->ssl_ctx) {
    us_internal_ssl_ctx_unref(ls->ssl_ctx);
  }
  ls->ssl_ctx = ctx;
}

void us_listen_socket_on_server_name(struct us_listen_socket_t *ls,
                                     struct ssl_ctx_st *(*cb)(struct us_listen_socket_t *, const char *, int *, struct us_socket_t *)) {
  ls->on_server_name = cb;
  /* The dynamic resolver may need to suspend the handshake (async
   * SNICallback); only the early select-certificate callback supports retry,
   * so register it on the listener's default context. The servername-stage
   * sni_cb stays registered for the static SNI tree (it is a no-op when the
   * early callback already installed a context). */
  if (ls->ssl_ctx) {
    SSL_CTX_set_select_certificate_cb(ls->ssl_ctx, us_select_cert_cb);
  }
}

/* Register a socket-level SNI resolver on an already-attached server-side SSL.
 * Must run after us_socket_adopt_tls and before the handshake is driven. */
void us_socket_on_server_name(struct us_socket_t *s) {
  if (!s || !s->ssl || !s_ssl(s)) return;
  SSL *ssl = s_ssl(s);
  s->ssl_sni_resolver = 1;
  /* Only the early select-certificate stage supports retry, which an async
   * SNICallback needs. The CTX is a memoized SecureContext possibly shared
   * with a listener, and this install is permanent, so us_select_cert_cb must
   * stay a no-op on any SSL carrying neither resolver. */
  SSL_CTX *ctx = SSL_get_SSL_CTX(ssl);
  if (ctx) SSL_CTX_set_select_certificate_cb(ctx, us_select_cert_cb);
}

void *us_socket_server_name_userdata(struct us_socket_t *s) {
  if (!s->ssl || !s_ssl(s) || us_sni_ex_idx < 0) return NULL;
  return SSL_CTX_get_ex_data(SSL_get_SSL_CTX(s_ssl(s)), us_sni_ex_idx);
}

const char *us_internal_ssl_sni_servername(struct us_socket_t *s) {
  if (!s->ssl || !s_ssl(s)) return NULL;
  return SSL_get_servername(s_ssl(s), TLSEXT_NAMETYPE_host_name);
}

void us_internal_listen_socket_ssl_free(struct us_listen_socket_t *ls) {
  /* Accepted sockets carry `ls` in per-SSL ex_data so sni_cb can reach the
   * listener's SNI tree. Those sockets may outlive the listener (server.close()
   * keeps existing connections per Node semantics), so wipe the back-ref now —
   * sni_cb returns OK on NULL. Walk only sockets accepted INTO this listener's
   * group; uWS apps with multiple listeners on one group are scoped by the
   * `== ls` check. */
  if (ls->accept_group) {
    for (struct us_socket_t *s = ls->accept_group->head_sockets; s; s = s->next) {
      struct us_ssl_rare_t *rare = s->ssl ? us_ssl_rare(s_ssl(s)) : NULL;
      if (rare && rare->listener == ls) rare->listener = NULL;
    }
    /* Mid-handshake sockets (SSL_in_init → low_prio) are *unlinked* from
     * head_sockets while parked in loop->data.low_prio_head, and they're
     * exactly the population that will run sni_cb on the next tick. Miss them
     * here and sni_cb dereferences `ls` after it's freed. Same group-filter as
     * close_all's drain. */
    for (struct us_socket_t *s = ls->accept_group->loop->data.low_prio_head; s; s = s->next) {
      struct us_ssl_rare_t *rare =
          s->group == ls->accept_group && s->ssl ? us_ssl_rare(s_ssl(s)) : NULL;
      if (rare && rare->listener == ls) rare->listener = NULL;
    }
  }
  if (ls->ssl_ctx) {
    us_internal_ssl_ctx_unref(ls->ssl_ctx);
    ls->ssl_ctx = NULL;
  }
  if (ls->sni) {
    sni_free(ls->sni, sni_node_destructor);
    ls->sni = NULL;
  }
}

#endif
